% KERN toolbox
% Version 0.226		22-Jul-2011
% Copyright (c) 2011, Neil D. Lawrence
% 
, Neil D. Lawrence
% KERNREADPARAMSFROMFID Read the kernel parameters from C++ file FID.
% SDLFMKERNGRADIENTCONSTANT Gradients for constants for the SDLFM kernel
% RBFARD2KERNDIAGGRADX Gradient of RBFARD2 kernel's diagonal with respect to X.
% LFMAXRBFKERNGRADIENT Compute gradient between the LFMA and RBF kernels.
% SDRBFKERNEXTRACTPARAM Extract parameters from the SDRBF kernel structure.
% GAUSSIANKERNGRADX Gradient of gaussian kernel with respect to input locations.
% MATERN52KERNEXPANDPARAM Create kernel structure from MATERN52 kernel's parameters.
% RBFKERNGRADIENT Gradient of RBF kernel's parameters.
% SQEXPKERNDIAGCOMPUTE Compute diagonal of SQEXP kernel.
% GIBBSPERIODICKERNDIAGCOMPUTE Compute diagonal of GIBBSPERIODIC kernel.
% LFMXRBFKERNGRADIENT Compute gradient between the LFM and RBF kernels.
% POLYARDKERNDISPLAY Display parameters of the POLYARD kernel.
% RATQUADKERNEXTRACTPARAM Extract parameters from the RATQUAD kernel structure.
% TENSORKERNCOMPUTE Compute the TENSOR kernel given the parameters and X.
% RATQUADKERNDISPLAY Display parameters of the RATQUAD kernel.
% LINKERNDIAGGRADX Gradient of LIN kernel's diagonal with respect to X.
% LFMGRADIENTH Gradient of the function h_i(z) with respect to some of the
% LFMXRBFKERNCOMPUTE Compute a cross kernel between the LFM and RBF kernels.
% WHITEBLOCKKERNGRADIENT Gradient of WHITEBLOCK kernel's parameters.
% SDLFMAXSDLFMVKERNCOMPUTEBLOCK Computes SDLFM kernel matrix for block i,j
% GIBBSKERNEXPANDPARAM Create kernel structure from GIBBS kernel's parameters.
% RATQUADKERNGRADIENT Gradient of RATQUAD kernel's parameters.
% MATERN52KERNEXTRACTPARAM Extract parameters from the MATERN52 kernel structure.
% LINKERNEXPANDPARAM Create kernel structure from LIN kernel's parameters.
% KERNGRADX Compute the gradient of the kernel wrt X.
% RBFWHITEKERNEXTRACTPARAM Extract parameters from the RBF-WHITE kernel
% WHITEBLOCKKERNEXPANDPARAM Fill WHITEBLOCK kernel structure with params.
% KERNTEST Run some tests on the specified kernel.
% GGWHITEXGAUSSIANWHITEKERNGRADX Compute gradient between the GG white and
% RBFWHITEKERNGRADX Gradient of RBF-WHITE kernel with respect to a point t.
% ARDKERNDISPLAY Display parameters of the ARD kernel.
% SDLFMJMEANCOMPUTE Jolt mean for the switching dynamical LFM model.
% FILEKERNDIAGCOMPUTE Compute diagonal of FILE kernel.
% KERNFACTORS Extract factors associated with transformed optimisation space.
% SIMXSIMKERNDIAGGRADIENT Gradient for the diagonal between two SIM kernels.
% NONEKERNPARAMINIT NONE kernel parameter initialisation.  
% RBFARDKERNPARAMINIT RBFARD kernel parameter initialisation.
% DISIMXRBFKERNCOMPUTE Compute a cross kernel between the DISIM and RBF kernels.
% SQEXPKERNDISPLAY Display parameters of the SQEXP kernel.
% SIMWHITEKERNEXTRACTPARAM Extract parameters from the SIM-WHITE kernel
% RBFPERIODIC2KERNEXPANDPARAM Create kernel structure from RBFPERIODIC2 kernel's parameters.
% WHITEHKERNDIAGGRADIENT Compute the gradient of the WHITEH kernel's diagonal wrt parameters.
% LFMSAMPLE Sample from LFM kernel
% SIMKERNPARAMINIT SIM kernel parameter initialisation.
% NONEKERNDIAGCOMPUTE Compute diagonal of NONE kernel.
% HEATKERNDIAGGRADIENT Gradient of the HEAT kernel's diagonal wrt parameters.
% WHITEXNONEKERNCOMPUTE Compute a cross kernel between WHITE and NONE kernels.
% GIBBSPERIODICKERNDISPLAY Display parameters of the GIBBSPERIODIC kernel.
% LFMWHITEKERNEXPANDPARAM Create kernel structure from LFM-WHITE kernel's
% TRANSLATEKERNDIAGGRADX Gradient of TRANSLATE kernel's diagonal with respect to X.
% LFMAVCOMPUTEUPSILONMATRIX Upsilon matrix acce. vel. with t1, t2 limits
% GGKERNGRADIENT Gradient of GG kernel's parameters.
% WHITEHKERNGRADX Gradient of WHITEH kernel with respect to input locations.
% SIMWHITEKERNPARAMINIT SIM-WHITE kernel parameter initialisation.
% SDLFMAXSDLFMVKERNGRADIENTBLOCK Gradients of the parameters in block i,j
% SIMKERNDIAGGRADIENT Compute the gradient of the SIM kernel's diagonal wrt parameters.
% SDLFMAXSDLFMKERNGRADIENTBLOCKIEJ 
% RBFARDKERNGRADX Gradient of RBFARD kernel with respect to input locations.
% SHEATKERNDIAGGRADIENT Gradient of the parameters of diagonal of a SHEAT kernel.
% KERNPRIORLOGPROB Compute penalty terms associated with kernel priors.
% MATERN52KERNDISPLAY Display parameters of the MATERN52 kernel.
% SIMXRBFKERNGRADIENT Compute gradient between the SIM and RBF kernels.
% SIMXSIMKERNGRADIENT Compute a cross gradient between two SIM kernels.
% LFMAPCOMPUTEUPSILONMATRIX Upsilon matrix acce. pos. with t1, t2 limits
% RBFWHITEXWHITEKERNCOMPUTE Compute a cross kernel between the RBF-WHITE
% MLPARDKERNCOMPUTE Compute the MLPARD kernel given the parameters and X.
% CMPNDKERNSETINDEX Set the indices in the compound kernel.
% WHITEBLOCKKERNGRADX Gradient of WHITEBLOCK kernel wrt input locations.
% SIMCOMPUTEH Helper function for comptuing part of the SIM kernel.
% ARDKERNGRADX Gradient of ARD kernel with respect to a point x.
% GAUSSIANKERNCOMPUTE Compute the Gaussian kernel given the parameters and X.
% SIMXSIMCOMPUTEDIAGH Helper function for comptuing part of the SIM kernel.
% MLPARDKERNPARAMINIT MLPARD kernel parameter initialisation.
% LFMCOMPUTEH3JV Helper function for computing part of the LFMJV kernel.
% LFMWHITEXRBFWHITEKERNGRADIENT Compute a cross gradient between an LFM-WHITE
% RBFPERIODICKERNGRADIENT Gradient of RBFPERIODIC kernel's parameters.
% MULTIKERNEXTRACTPARAM Extract parameters from the MULTI kernel structure.
% MLPARDKERNGRADX Gradient of MLPARD kernel with respect to input locations.
% SDLFMXSDLFMKERNGRADIENTBLOCKIEJ 
% GGWHITEXGAUSSIANWHITEKERNGRADIENT Compute gradient between the GG white
% TRANSLATEKERNGRADIENT Gradient of TRANSLATE kernel's parameters.
% SIMXSIMCOMPUTEDIAGHSTAT Helper function for computing part of the stationary version
% MLPARDKERNDIAGGRADX Gradient of MLPARD kernel's diagonal with respect to X.
% WIENERKERNEXPANDPARAM Create kernel structure from WIENER kernel's parameters.
% RBFKERNDIAGCOMPUTE Compute diagonal of RBF kernel.
% PSKERNELOBJECTIVE Likelihood approximation for point set IVM.
% CMPNDKERNGRADX Gradient of CMPND kernel with respect to a point x.
% RBFINFWHITEXRBFINFWHITEKERNGRADIENT Compute a cross gradient between two
% MLPKERNEXPANDPARAM Create kernel structure from MLP kernel's parameters.
% RBFARDKERNEXPANDPARAM Create kernel structure from RBFARD kernel's parameters.
% SPARSEKERNDISPLAY Display parameters of the SPARSE kernel.
% MATERN52KERNCOMPUTE Compute the MATERN52 kernel given the parameters and X.
% WHITEFIXEDKERNDIAGGRADX Gradient of WHITEFIXED kernel's diagonal with respect to X.
% KERNCREATE Initialise a kernel structure.
% BIASKERNCOMPUTE Compute the BIAS kernel given the parameters and X.
% POLYARDKERNEXPANDPARAM Create kernel structure from POLYARD kernel's parameters.
% MLPKERNDIAGCOMPUTE Compute diagonal of MLP kernel.
% DISIMSAMPLE Sample from SIM kernel
% SDLFMAXSDLFMKERNCOMPUTEBLOCK Computes SDLFM kernel matrix for block i,j
% LFMWHITEXLFMWHITEKERNCOMPUTE Compute a cross kernel between two LFM-WHITE
% WHITEXNONEKERNGRADIENT Compute a cross gradient between WHITE and DUMMY kernels.
% WHITEHKERNCOMPUTE Compute the WHITEH kernel given the parameters and X.
% KERNPRIORGRADIENT Compute gradient terms associated with kernel priors.
% SQEXPKERNGRADX Gradient of SQEXP kernel with respect to a point x.
% DEXPKERNDIAGCOMPUTE Compute diagonal of the double exponential kernel.
% RBFARDKERNCOMPUTE Compute the RBFARD kernel given the parameters and X.
% GGKERNEXTRACTPARAM Extract parameters from the GG kernel structure.
% RBFPERIODICKERNGRADX Gradient of RBFPERIODIC kernel with respect to a point x.
% TENSORKERNSLASH Tensor kernel created by removing ith component.
% SIMWHITEKERNDISPLAY Display parameters of the SIM-WHITE kernel.
% WHITEBLOCKKERNEXTRACTPARAM Extract parameters from WHITEBLOCK kernel str.
% RBFPERIODICKERNPARAMINIT RBFPERIODIC kernel parameter initialisation.
% RBFARD2KERNCOMPUTE Compute the RBFARD kernel given the parameters and X.
% GIBBSPERIODICKERNEXPANDPARAM Create kernel structure from GIBBSPERIODIC kernel's parameters.
% GGXGGKERNCOMPUTE Compute a cross kernel between two GG kernels.
% RBFWHITEKERNPARAMINIT RBF-WHITE kernel parameter initialisation. The RBF-
% GIBBSPERIODICKERNGRADX Gradient of GIBBSPERIODIC kernel with respect to a point x.
% DISIMXSIMKERNGRADIENT Compute gradient between the DISIM and SIM kernels.
% LINARD2KERNGRADX Gradient of LINARD2 kernel with respect to input locations.
% MATERN52KERNDIAGGRADX Gradient of MATERN52 kernel's diagonal with respect to X.
% SIMSAMPLE Sample from SIM kernel
% SDLFMXSDLFMKERNGRADIENTICBLOCK Partial derivatives initial conditions
% DISIMKERNEXTRACTPARAM Extract parameters from the DISIM kernel structure.
% CMPNDKERNEXTRACTPARAM Extract parameters from the CMPND kernel structure.
% SQEXPKERNCOMPUTE Compute the SQEXP kernel given the parameters and X.
% WHITEXRBFKERNGRADIENT Compute a cross gradient between WHITE and RBF kernels.
% SDLFMVXSDRBFKERNCOMPUTE Cross kernel between a SDLFMV and a SDRBF kernels.
% WHITEFIXEDXWHITEFIXEDKERNGRADIENT Compute a cross gradient between two WHITEFIXED kernels.
% ARDKERNEXTRACTPARAM Extract parameters from the ARD kernel structure.
% MULTIKERNDIAGGRADIENTBLOCK
% TRANSLATEKERNCOMPUTE Compute the TRANSLATE kernel given the parameters and X.
% RATQUADKERNGRADX Gradient of RATQUAD kernel with respect to input locations.
% ARDKERNPARAMINIT ARD kernel parameter initialisation.
% LFMJXLFMVKERNCOMPUTE Jolt and velocity LFM kernel  
% RBFPERIODIC2KERNEXTRACTPARAM Extract parameters from the RBFPERIODIC2 kernel structure.
% GAUSSIANWHITEKERNDIAGGRADX Gradient of gaussian white kernel's diagonal with respect to X.
% RBFPERIODICKERNDIAGGRADX Gradient of RBFPERIODIC kernel's diagonal with respect to X.
% WHITEKERNEXPANDPARAM Create kernel structure from WHITE kernel's parameters.
% LFMEXPANDPARAM Expand the given parameters into a LFM structure.
% GIBBSKERNDIAGGRADIENT Compute the gradient of the GIBBS kernel's diagonal wrt parameters.
% CMPNDKERNDISPLAY Display parameters of the CMPND kernel.
% SDLFMVXSDLFMVKERNCOMPUTEBLOCK Computes SDLFM kernel matrix for block i,j
% SDLFMAXSDLFMVKERNGRADIENT Gradients of cross kernel between 2 SDLFM kernels.
% LFMAPGRADIENTUPSILONVECTOR Gradient upsilon vector accel. pos.
% MULTIKERNTEST Run some tests on the multiple output block kernel.
% LFMJXLFMAKERNCOMPUTE Jolt and acceleration LFM kernel  
% GAUSSIANKERNDIAGGRADIENT Compute the gradient of the gaussian kernel's diagonal wrt parameters.
% WIENERKERNCOMPUTE Compute the WIENER kernel given the parameters and X.
% RBFHKERNDIAGGRADX Gradient of RBFH kernel's diagonal with respect to X.
% GGWHITEKERNGRADIENT Gradient of GG WHITE kernel's parameters.
% RBFINFWHITEXRBFINFWHITEKERNCOMPUTE Compute a cross kernel between two
% SQEXPKERNGRADIENT Gradient of SQEXP kernel's parameters.
% LFMWHITEKERNCOMPUTE Compute the LFM-WHITE kernel given the parameters, t1
% RBFHKERNCOMPUTE Compute the RBFH kernel given the parameters and X.
% LFMGRADIENTSIGMAH Gradient of the function h_i(z) with respect \sigma.
% BIASKERNEXTRACTPARAM Extract parameters from the BIAS kernel structure.
% LFMCOMPUTEH3VV Helper function for computing part of the LFMVXLFMV kernel.
% POLYKERNGRADIENT Gradient of POLY kernel's parameters.
% RBFARDKERNGRADIENT Gradient of RBFARD kernel's parameters.
% LFMCOMPUTEH4 Helper function for computing part of the LFM kernel.
% RBFPERIODICKERNEXPANDPARAM Create kernel structure from RBFPERIODIC kernel's parameters.
% MATERN52KERNGRADX Gradient of MATERN52 kernel with respect to input locations.
% DISIMKERNDIAGGRADX Gradient of DISIM kernel's diagonal with respect to X.
% MULTIKERNGRADIENTBLOCKX
% WHITEHKERNEXPANDPARAM Create kernel structure from WHITEH kernel's parameters.
% LFMGRADIENTSIGMAH4AV Gradient of the function h_i(z) with respect \sigma.
% LINARD2KERNEXTRACTPARAM Extract parameters from the LINARD2 kernel structure.
% LFMGRADIENTUPSILON Gradient of the function \upsilon(z) with respect to
% SDLFMVKERNGRADIENT Gradient of SDLFM kernel's parameters.
% DISIMKERNPARAMINIT DISIM kernel parameter initialisation.
% LFMVVGRADIENTUPSILONMATRIX Gradient upsilon matrix vel. vel.
% FILEKERNGRADIENT Gradient of FILE kernel's parameters.
% LMCKERNDIAGCOMPUTE Compute the diagonal of the LMC kernel.
% LFMVXRBFKERNGRADIENT Compute gradient between the LFMV and RBF kernels.
% GIBBSPERIODICKERNDIAGGRADX Gradient of GIBBSPERIODIC kernel's diagonal with respect to X.
% RBFARDJITKERNDIAGGRADX Gradient of RBFARDJIT kernel's diagonal with respect to X.
% OUKERNGRADX Gradient of OU kernel with respect to a point x (see
% LFMGRADIENTH42AP Gradient of the function h_i(z) with respect to some of the
% LFMJXLFMKERNCOMPUTE Jolt and position LFM kernel  
% SDLFMKERNGRADIENTMEAN Gradients of the parameters of mean function cov.
% SIMKERNGRADIENT Gradient of SIM kernel's parameters.
% RBFARDKERNDIAGGRADIENT Compute the gradient of the RBFARD kernel's diagonal wrt parameters.
% DISIMXDISIMKERNGRADIENT Compute a cross gradient between two DISIM kernels.
% SIMXRBFKERNCOMPUTE Compute a cross kernel between the SIM and RBF kernels.
% LFMVKERNPARAMINIT LFMV kernel parameter initialisation. 
% ARDKERNCOMPUTE Compute the ARD kernel given the parameters and X.
% SDLFMAXSDRBFKERNGRADIENTBLOCK Gradients of the parameters in block i,j
% KERNDIAGCOMPUTE Compute the kernel given the parameters and X.
% RBFARD2KERNDIAGGRADIENT Compute the gradient of the RBFARD2 kernel's diagonal wrt parameters.
% LFMCOMPUTEH3JA Helper function for computing part of the LFMJA kernel.
% TENSORKERNGRADX Gradient of TENSOR kernel with respect to a point x.
% RATQUADKERNDIAGGRADX Gradient of RATQUAD kernel's diagonal with respect to X.
% WIENERKERNEXTRACTPARAM Extract parameters from the WIENER kernel structure.
% LFMWHITEKERNEXTRACTPARAM Extract parameters from the LFM-WHITE kernel
% CMPNDKERNGRADIENT Gradient of CMPND kernel's parameters.
% SDLFMXSDLFMKERNCOMPUTEBLOCK Computes SDLFM kernel matrix for block i,j
% SDLFMKERNPARAMINIT SDLFM kernel initialization
% NONEKERNDIAGGRADX Gradient of NONE kernel's diagonal with respect to X.
% SDLFMVXSDLFMKERNCOMPUTE Cross kernel between a SDLFMV and a SDLFM kernels.
% BIASKERNGRADX Gradient of BIAS kernel with respect to input locations.
% TENSORKERNPARAMINIT TENSOR kernel parameter initialisation.
% SDLFMVKERNEXPANDPARAM Pass parameters from params to SDLFMV kernel
% WIENERKERNDIAGCOMPUTE Compute diagonal of WIENER kernel.
% GIBBSPERIODICKERNEXTRACTPARAM Extract parameters from the GIBBSPERIODIC kernel structure.
% LFMLOGLIKELIHOOD Compute the log likelihood of a LFM model.
% LMCKERNCOMPUTE Compute the LMC kernel given the parameters and X.
% RBFINFWHITEKERNGRADIENT Gradient of the parameters of the RBF-WHITE kernel
% DISIMCOMPUTEH Helper function for comptuing part of the DISIM kernel.
% LFMGRADIENTH31 Gradient of the function h_i(z) with respect to some of the
% RBFARDJITKERNGRADX Gradient of RBFARDJIT kernel with respect to input locations.
% LFMKERNDIAGGRADIENT Compute the gradient of the LFM kernel's diagonal wrt parameters.
% LFMAXLFMAKERNGRADIENT Compute a cross gradient between a LFMA and a LFMA.
% POLYARDKERNGRADX Gradient of POLYARD kernel with respect to input locations.
% EXPKERNDISPLAY Display parameters of the EXP kernel.
% TENSORKERNDIAGGRADX Gradient of TENSOR kernel's diagonal with respect to X.
% RBFARDJITKERNDIAGCOMPUTE Compute diagonal of RBFARDJIT kernel.
% LFMVXLFMVKERNGRADIENT Compute a cross gradient between a LFMV and a LFMV.
% LFMVPCOMPUTEUPSILONMATRIX Upsilon matrix vel. pos. with t1, t2 limits
% RBFWHITEKERNDIAGGRADX Gradient of RBF-WHITE kernel's diagonal w.r.t. t.
% SDLFMVXSDLFMVKERNGRADIENTICBLOCK Partial derivatives initial conditions
% LFMVVCOMPUTEUPSILONMATRIX Upsilon matrix vel. vel. with t1, t2 limits
% GGWHITEXGGWHITEKERNGRADIENT Compute a cross gradient between two GG WHITE kernels.
% RBFINFWHITEKERNPARAMINIT The RBF-WHITE-INF kernel is a convolutional
% SIMKERNCOMPUTE Compute the SIM kernel given the parameters and X.
% RBFWHITEKERNEXPANDPARAM Create kernel structure from RBF-WHITE kernel's
% WHITEBLOCKKERNDIAGCOMPUTE Compute diagonal of WHITEBLOCK kernel.
% WHITEKERNPARAMINIT WHITE kernel parameter initialisation.
% LFMCOMPUTEH4VP Helper function for computing part of the LFMVXLFM kernel.
% RBFHKERNDISPLAY Display parameters of the RBFH kernel.
% MULTIKERNDIAGGRADX Gradient of MULTI kernel's diagonal with respect to X.
% SDLFMXSDRBFKERNGRADIENT Cross gradient between a SDLFM and a SDRBF kernels.
% RBFARD2KERNPARAMINIT RBFARD2 kernel parameter initialisation.
% RBFARDJITKERNDIAGGRADIENT Compute the gradient of the RBFARD2 kernel's diagonal wrt parameters.
% RBFWHITEKERNGRADIENT Gradient of RBF-WHITE kernel's parameters.
% WHITEFIXEDKERNDIAGGRADIENT Compute the gradient of the WHITEFIXED kernel's diagonal wrt parameters.
% GIBBSKERNDIAGCOMPUTE Compute diagonal of GIBBS kernel.
% SDLFMVXSDRBFKERNGRADIENT Gradients cross kernel between a SDLFM and SDRBF
% COMPUTEKERNEL Compute the kernel given the parameters and X.
% BIASKERNPARAMINIT BIAS kernel parameter initialisation.
% GGKERNDIAGCOMPUTE Compute diagonal of GG kernel.
% ARDKERNGRADIENT Gradient of ARD kernel's parameters.
% MATERN52KERNPARAMINIT MATERN52 kernel parameter initialisation.
% LFMWHITEXWHITEKERNCOMPUTE Compute a cross kernel between the LFM-WHITE
% LFMCOMPUTEH3AV Helper function for computing part of the LFMAV kernel.
% MULTIKERNGRADIENTBLOCK
% WHITEKERNEXTRACTPARAM Extract parameters from the WHITE kernel structure.
% RATQUADKERNPARAMINIT RATQUAD kernel parameter initialisation.
% POLYKERNDIAGGRADX Gradient of POLY kernel's diagonal with respect to X.
% LINKERNGRADX Gradient of LIN kernel with respect to input locations.
% EXPKERNPARAMINIT EXP kernel parameter initialisation.
% FILEKERNEXTRACTPARAM Extract parameters from the FILE kernel structure.
% POLYARDKERNPARAMINIT POLYARD kernel parameter initialisation.
% RBFARDKERNDIAGCOMPUTE Compute diagonal of RBFARD kernel.
% GIBBSPERIODICKERNCOMPUTE Compute the GIBBSPERIODIC kernel given the parameters and X.
% WIENERKERNDIAGGRADX Gradient of WIENER kernel's diagonal with respect to X.
% HEATKERNGRADIENT Gradient of HEAT kernel's parameters.
% LFMOPTIONS Creates a set of default options for a LFM model.
% SDLFMXSDLFMVKERNGRADIENTICBLOCK Partial derivatives initial conditions
% SDLFMVKERNDISPLAY Display parameters of the SDLFMV kernel.
% LFMJPCOMPUTEUPSILONVECTOR Upsilon vector jolt. pos. with t1, t2 limits
% LFMWHITEXLFMWHITEKERNGRADIENT Compute a cross gradient between two
% SDRBFKERNCOMPUTE Compute the SDRBF kernel given the parameters and t1.
% DISIMKERNCOMPUTE Compute the DISIM kernel given the parameters and X.
% TRANSLATEKERNEXTRACTPARAM Extract parameters from the TRANSLATE kernel structure.
% LMCKERNDISPLAY Display parameters of the LMC kernel.
% RBFKERNGRADX Gradient of RBF kernel with respect to input locations.
% SIMWHITEXWHITEKERNGRADIENT Compute gradient between the SIM-WHITE and WHITE kernels.
% HEATXHEATKERNGRADIENT Gradient wrt parameters between two HEAT kernels.
% RBFPERIODICKERNDIAGGRADIENT Compute the gradient of the RBFPERIODIC kernel's diagonal wrt parameters.
% LFMVXLFMKERNGRADIENT Compute a cross gradient for a LFMVXLFM.
% LFMAKERNCOMPUTE Compute the LFMA kernel given the parameters and X.
% LFMKERNDIAGCOMPUTE Compute diagonal of LFM kernel.
% LINARDKERNCOMPUTE Compute the LINARD kernel given the parameters and X.
% DEXPKERNEXPANDPARAM Create a kernel structure from the double exponential
% SDLFMXSDLFMVKERNCOMPUTEBLOCK Computes SDLFM kernel matrix for block i,j
% GGWHITEKERNEXPANDPARAM Create kernel structure from GG white kernel's parameters.
% RBFARDKERNDIAGGRADX Gradient of RBFARD kernel's diagonal with respect to X.
% WHITEBLOCKKERNDISPLAY Display parameters of the WHITEBLOCK kernel.
% HEATXRBFHKERNCOMPUTE Cross kernel between a HEAT and a RBF kernels.
% LFMWHITEKERNPARAMINIT LFM-WHITE kernel parameter initialisation.
% EXPKERNGRADIENT Gradient of EXP kernel's parameters.
% RBFINFWHITEKERNDISPLAY Display parameters of the RBF-WHITE kernel (with
% SDLFMAXSDLFMAKERNGRADIENTBLOCKIGJ 
% LINARDKERNDIAGCOMPUTE Compute diagonal of LINARD kernel.
% SDRBFKERNDISPLAY Display parameters of the SDRBF kernel.
% LFMVPGRADIENTSIGMAUPSILONMATRIX Gradient of upsilon matrix vp wrt sigma
% MATERN32KERNDIAGGRADX Gradient of MATERN32 kernel's diagonal with respect to X.
% LINKERNPARAMINIT LIN kernel parameter initialisation.
% LFMGRADIENTH41 Gradient of the function h_i(z) with respect to some of the
% WHITEFIXEDKERNGRADX Gradient of WHITEFIXED kernel with respect to a point x.
% SDLFMXSDLFMVKERNGRADIENTBLOCKIGJ 
% LINKERNCOMPUTE Compute the LIN kernel given the parameters and X.
% FILEKERNGRADX Gradient of FILE kernel with respect to a point x.
% SIMWHITEXRBFINFWHITEKERNGRADIENT Compute a cross gradient between a
% POLYARDKERNDIAGCOMPUTE Compute diagonal of POLYARD kernel.
% DISIMKERNDISPLAY Display parameters of the DISIM kernel.
% LFMJXRBFKERNCOMPUTE Compute cross kernel between the LFMJ and RBF kernels.
% WHITEHKERNDISPLAY Display parameters of the WHITEH kernel.
% DEXPKERNCOMPUTE Compute the double exponential kernel,
% MULTIKERNFIXBLOCKS
% RBFARD2KERNGRADIENT Gradient of RBFARD2 kernel's parameters.
% CMPNDKERNEXPANDPARAM Create kernel structure from CMPND kernel's parameters.
% SIMKERNGRADX Gradient of SIM kernel with respect to each time point in t1.
% SDLFMVKERNEXTRACTPARAM Extract parameters from the SDLFMV kernel structure.
% SDLFMAXSDLFMAKERNGRADIENTBLOCK Gradients of the parameters in block i,j
% TENSORKERNDISPLAY Display parameters of the TENSOR kernel.
% RBFARDJITKERNDISPLAY Display parameters of the RBFARDJIT kernel.
% POLYKERNDIAGCOMPUTE Compute diagonal of POLY kernel.
% LFMWHITEKERNGRADIENT Gradient of LFM-WHITE kernel's parameters.
% LMCKERNPARAMINIT LMC kernel parameter initialisation.
% DISIMKERNEXPANDPARAM Create kernel structure from DISIM kernel's parameters.
% SDLFMVKERNDIAGCOMPUTE Compute diagonal of a SDLFMV kernel.
% GAUSSIANKERNEXTRACTPARAM Extract parameters from the gaussian kernel structure.
% SDLFMKERNCOMPUTECONSTANT Compute constants for the SDLFM kernel
% NONEKERNCOMPUTE Compute the NONE kernel given the parameters and X.
% LFMGRADIENTSIGMAH3AA Gradient of the function h_i(z) with respect \sigma.
% WHITEXWHITEKERNGRADX
% SIMCOMPUTETEST Test the file simComputeH.
% SDLFMKERNCOMPUTE Compute the SDLFM kernel given the parameters and X.
% LFMWHITECOMPUTEGRADTHETAH1 computes a portion of the LFM-WHITE kernel's gradient w.r.t. theta.
% SDLFMXSDRBFKERNGRADIENTBLOCKIGJ 
% LFMVKERNEXPANDPARAM Create kernel structure from LFMV kernel's parameters.
% KERNSETINDEX Set the indices on a compound kernel.
% DISIMXDISIMKERNCOMPUTE Compute a cross kernel between two DISIM kernels.
% WHITEKERNCOMPUTE Compute the WHITE kernel given the parameters and X.
% LFMVPGRADIENTUPSILONVECTOR Gradient upsilon vector vel. pos.
% WHITEHKERNPARAMINIT WHITEH kernel parameter initialisation.
% GAUSSIANWHITEKERNDISPLAY Display parameters of the GAUSSIAN white kernel.
% SQEXPKERNPARAMINIT SQEXP kernel parameter initialisation.
% WHITEBLOCKKERNPARAMINIT WHITE BLOCK kernel parameter initialisation.
% LFMAACOMPUTEUPSILONDIAGVECTOR Diag. of Upsilon matrix acce. accel. 
% SIMWHITEKERNEXPANDPARAM Create kernel structure from SIM-WHITE kernel's
% SDLFMXSDLFMVKERNGRADIENTBLOCK Gradients of the parameters in block i,j
% SDLFMAXSDRBFKERNCOMPUTEBLOCK Cross kernel between SDLFM and SDRBF for i,j
% TRANSLATEKERNDISPLAY Display parameters of the TRANSLATE kernel.
% LFMAVGRADIENTUPSILONMATRIX Gradient upsilon matrix accel. vel.
% LFMCOMPUTEH4JV Helper function for computing part of the LFMJV kernel.
% KERNSETWHITE Helper function to set the white noise in a kernel if it exists.
% LFMAXLFMVKERNCOMPUTE Acceleration and velocity LFM kernel  
% RBFHKERNGRADIENT Gradient of RBFH kernel's parameters.
% RBFPERIODICKERNCOMPUTE Compute the RBFPERIODIC kernel given the parameters and X.
% FILEKERNREAD Read kernel values from file or cache.
% SIMWHITEXWHITEKERNCOMPUTE Compute a cross kernel between the SIM-WHITE
% DISIMKERNGRADIENT Gradient of DISIM kernel's parameters.
% OUKERNDISPLAY Display parameters of the OU kernel (see ouKernCompute or
% GIBBSKERNSETLENGTHSCALEFUNC Set the length scale function of the GIBBS kernel.
% NONEKERNGRADX Gradient of NONE kernel with respect to a point x.
% DISIMCOMPUTEHPRIME Helper function for comptuing part of the DISIM kernel.
% SDLFMVXSDLFMKERNGRADIENTICBLOCK Partial derivatives initial conditions
% POLYKERNCOMPUTE Compute the POLY kernel given the parameters and X.
% RBFKERNCOMPUTE Compute the RBF kernel given the parameters and X.
% LFMVXRBFVKERNCOMPUTE Compute a cross kernel between the LFMV and RBFV kernels.
% LINKERNDIAGCOMPUTE Compute diagonal of LIN kernel.
% LFMVKERNDISPLAY Display parameters of the LFMV kernel.
% LINARD2KERNEXPANDPARAM Create kernel structure from LINARD2 kernel's parameters.
% TENSORKERNGRADIENT Gradient of TENSOR kernel's parameters.
% LFMGRADIENTH32 Gradient of the function h_i(z) with respect to some of the
% LFMCOMPUTEH4JP Helper function for computing part of the LFMJP kernel.
% SDLFMXSDRBFKERNGRADIENTBLOCK Gradients of the parameters in block i,j
% POLYKERNDISPLAY Display parameters of the POLY kernel.
% GAUSSIANKERNEXPANDPARAM Create kernel structure from gaussian kernel's parameters.
% SDLFMAXSDLFMKERNGRADIENTBLOCKILJ 
% RBFXNONEKERNGRADIENT Compute a cross gradient between RBF and DUMMY
% RBFARD2KERNDISPLAY Display parameters of the RBFARD2 kernel.
% LINARD2KERNPARAMINIT LINARD2 kernel parameter initialisation.
% LMCKERNGRADIENT Gradient of LMC kernel's parameters.
% CMPNDKERNDIAGCOMPUTE Compute diagonal of CMPND kernel.
% GIBBSKERNDIAGGRADX Gradient of GIBBS kernel's diagonal with respect to X.
% SIMKERNDIAGCOMPUTE Compute diagonal of SIM kernel.
% ARDKERNDIAGCOMPUTE Compute diagonal of ARD kernel.
% WIENERKERNPARAMINIT WIENER kernel parameter initialisation.
% LFMKERNGRADX Gradient of LFM kernel with respect to a point x.
% LFMGRADIENTSIGMAH4AA Gradient of the function h_i(z) with respect \sigma.
% GIBBSKERNGRADX Gradient of GIBBS kernel with respect to input locations.
% LFMXRBFVKERNCOMPUTE Compute a cross kernel between the LFM and RBFV kernels.
% MULTIKERNGRADIENT Gradient of MULTI kernel's parameters.
% GAUSSIANKERNGRADIENT Gradient of gaussian kernel's parameters.
% LINARDKERNGRADX Gradient of LINARD kernel with respect to input locations.
% TRANSLATEKERNDIAGCOMPUTE Compute diagonal of TRANSLATE kernel.
% LFMGRADIENTSIGMAH3AV Gradient of the function h_i(z) with respect \sigma.
% LFMCOMPUTEH Helper function for computing part of the LFM kernel.
% SDLFMVXSDLFMKERNGRADIENT Gradients of cross kernel between 2 SDLFM kernels.
% SDLFMVXSDRBFKERNCOMPUTEBLOCK Cross kernel between SDLFM and SDRBF for i,j
% EXPKERNCOMPUTE Compute the EXP kernel given the parameters and X.
% OUKERNEXPANDPARAM Create kernel structure from OU kernel's parameters
% DISIMKERNDIAGCOMPUTE Compute diagonal of DISIM kernel.
% LFMVPGRADIENTSIGMAUPSILONVECTOR Gradient of upsilon vector vp wrt sigma
% RBFKERNDIAGGRADIENT Compute the gradient of the RBF kernel's diagonal wrt parameters.
% MATERN52KERNGRADIENT Gradient of MATERN52 kernel's parameters.
% TENSORKERNDIAGCOMPUTE Compute diagonal of TENSOR kernel.
% VELOTRANSKERNDIAGGRADX Gradient of VELOTRANS kernel's diagonal with respect to X.
% LFMTEST Test the gradients of the LFM model.
% SDLFMKERNDIAGCOMPUTEBLOCK Diagonal of a SDLFM kernel matrix for block i
% LFMAXLFMVKERNGRADIENT Compute a cross gradient between a LFMA and a LFMV.
% WHITEKERNDIAGCOMPUTE Compute diagonal of WHITE kernel.
% GETLOCALGRADALPHAOMEGA Gradients of parameters in alpha and omega
% HEATXHEATKERNCOMPUTE Compute a cross kernel between two HEAT kernels.
% SDLFMAXSDLFMKERNGRADIENT Gradients of cross kernel between 2 SDLFM kernels.
% GAUSSIANWHITEKERNCOMPUTE Compute the covariance of the output samples 
% GAUSSIANWHITEKERNGRADX Gradient of gaussian white kernel with respect 
% LFMCOMPUTEUPSILONDIAGVECTOR 
% RBFWHITEKERNDIAGCOMPUTE Compute diagonal of RBF-WHITE kernel.
% LFMGRADIENTSIGMAH4VV Gradient of the function h_i(z) with respect \sigma.
% SDLFMVXSDRBFKERNGRADIENTBLOCK Gradients of the parameters in block i,j
% VELOTRANSKERNDISPLAY Display parameters of the VELOTRANS kernel.
% GAUSSIANKERNPARAMINIT Gaussian kernel parameter initialisation.
% RBFARD2KERNDIAGCOMPUTE Compute diagonal of RBFARD2 kernel.
% LFMVXLFMVKERNCOMPUTE Velocity and velocity LFM kernel  
% WHITEKERNGRADIENT Gradient of WHITE kernel's parameters.
% DEXPKERNEXTRACTPARAM Extract parameters from the double exponential's
% DISIMXSIMKERNCOMPUTE Compute a cross kernel between DISIM and SIM kernels.
% RBFKERNEXTRACTPARAM Extract parameters from the RBF kernel structure.
% EXPKERNEXTRACTPARAM Extract parameters from the EXP kernel structure.
% GAUSSIANWHITEKERNPARAMINIT Gaussian white kernel parameter initialisation.
% MLPKERNGRADIENT Gradient of MLP kernel's parameters.
% RBFHKERNEXPANDPARAM Create kernel structure from RBFH kernel's parameters.
% POLYARDKERNGRADIENT Gradient of POLYARD kernel's parameters.
% SDLFMXSDLFMKERNGRADIENTBLOCKILJ 
% KERNCORRELATION Compute the correlation matrix kernel given the parameters and X.
% DEXPKERNDIAGGRADX Gradient of the double exponential kernel's diagonal
% SRBFHKERNCOMPUTE Compute an SRBFH kernel.
% MULTIKERNDIAGGRADIENT Compute the gradient of the MULTI kernel's diagonal wrt parameters.
% LFMWHITEKERNDISPLAY Display parameters of the LFM-WHITE kernel.
% LFMGRADIENTSIGMAH3AP Gradient of the function h_i(z) with respect \sigma.
% NONEKERNEXTRACTPARAM Extract parameters from the NONE kernel structure.
% LFMCOMPUTEH3AP Helper function for computing part of the LFMAP kernel.
% LFMAAGRADIENTUPSILONMATRIX Gradient upsilon matrix accel. accel.
% GGXGAUSSIANKERNGRADIENT Compute gradient between the GG and GAUSSIAN kernels.
% FILEKERNEXPANDPARAM Create kernel structure from FILE kernel's parameters.
% RBFINFWHITEKERNDIAGCOMPUTE Compute diagonal of RBF-WHITE kernel (with
% POLYKERNEXTRACTPARAM Extract parameters from the POLY kernel structure.
% LINARDKERNDISPLAY Display parameters of the LINARD kernel.
% SIMXSIMKERNCOMPUTE Compute a cross kernel between two SIM kernels.
% BIASKERNDIAGGRADIENT Compute the gradient of the BIAS kernel's diagonal wrt parameters.
% MLPKERNEXTRACTPARAM Extract parameters from the MLP kernel structure.
% LFMCOMPUTEH4VV Helper function for computing part of the LFMVXLFMV kernel.
% LINARD2KERNGRADIENT Gradient of LINARD2 kernel's parameters.
% MULTIKERNDISPLAY Display parameters of the MULTI kernel.
% DISIMKERNGRADX Gradient of DISIM kernel with respect to a point x.
% GIBBSKERNGRADIENT Gradient of GIBBS kernel's parameters.
% MLPKERNCOMPUTE Compute the MLP kernel given the parameters and X.
% MATERN32KERNPARAMINIT MATERN32 kernel parameter initialisation.
% SDLFMVXSDLFMVKERNCOMPUTE Compute a cross kernel between two SDLFMV kernels.
% SDLFMVXSDLFMVKERNGRADIENT Gradients of cross kernel between 2 SDLFM kernels.
% LFMVPCOMPUTEUPSILONDIAGVECTOR Upsilon diag vector vel. pos. with t1, t2 limits
% RBFHKERNPARAMINIT RBFH kernel parameter initialisation.
% SDLFMVKERNCOMPUTE Compute the SDLFMV kernel given the parameters and X.
% NONEKERNGRADIENT Gradient of NONE kernel's parameters.
% LFMKERNPARAMINIT LFM kernel parameter initialisation. The latent force
% RATQUADKERNDIAGCOMPUTE Compute diagonal of RATQUAD kernel.
% LFMWHITEXWHITEKERNGRADIENT Compute gradient between the LFM-WHITE and
% SIMWHITEKERNGRADX Gradient of SIM-WHITE kernel with respect to a point t.
% SHEATKERNCOMPUTE Compute a cross kernel between two SHEAT kernels.
% MATERN32KERNDIAGCOMPUTE Compute diagonal of MATERN32 kernel.
% LINARD2KERNDIAGGRADX Gradient of LINARD2 kernel's diagonal with respect to X.
% LFMCOMPUTEH4AA Helper function for computing part of the LFMAA kernel.
% POLYARDKERNDIAGGRADX Gradient of POLYARD kernel's diagonal with respect to X.
% RATQUADKERNDIAGGRADIENT Compute the gradient of the RATQUAD kernel's diagonal wrt parameters.
% SDLFMXSDLFMKERNGRADIENTBLOCKIGJ 
% EXPKERNDIAGCOMPUTE Compute diagonal of EXP kernel.
% RBFARD2KERNGRADX Gradient of RBFARD2 kernel with respect to input locations.
% MLPKERNGRADX Gradient of MLP kernel with respect to input locations.
% RBFARDJITKERNPARAMINIT RBFARD2 kernel parameter initialisation.
% RBFINFWHITEKERNGRADX Gradient of RBF-WHITE kernel (with integration limits
% SDLFMXSDRBFKERNCOMPUTE Cross kernel between a SDLFM and a SDRBF kernels.
% SDLFMVXSDLFMVKERNGRADIENTBLOCK Gradients of the parameters in block i,j
% POLYARDKERNCOMPUTE Compute the POLYARD kernel given the parameters and X.
% SDLFMAXSDLFMAKERNCOMPUTE Cross kernel between a SDLFMA and a SDLFMA kernels.
% HEATXRBFHKERNGRADIENT Gradient wrt parameters between a HEAT and a RBFH.
% RBFWHITEXRBFWHITEKERNCOMPUTE Compute a cross kernel between two RBF-WHITE
% RBFARDJITKERNCOMPUTE Compute the RBFARD kernel given the parameters and X.
% LFMGRADIENTH41VP Gradient of the function h_i(z) with respect to some of the
% LFMVVGRADIENTSIGMAUPSILONMATRIX Gradient of upsilon matrix vv wrt sigma
% SDLFMXSDLFMKERNGRADIENT Gradients of cross kernel between 2 SDLFM kernels.
% LFMAXLFMKERNCOMPUTE Acceleration and position LFM kernel  
% SIMWHITEXRBFWHITEKERNGRADIENT Compute a cross gradient between a SIM-WHITE
% LINARDKERNGRADIENT Gradient of LINARD kernel's parameters.
% WHITEBLOCKKERNDIAGGRADX Gradient of WHITEBLOCK kernel's diagonal wrt X.
% SDLFMVKERNDIAGCOMPUTEBLOCK Diagonal of a SDLFM kernel matrix for block i
% MULTIKERNCOMPUTEBLOCK
% TENSORKERNEXPANDPARAM Create kernel structure from TENSOR kernel's parameters.
% LFMVXRBFKERNCOMPUTE Compute a cross kernel between the LFMV and RBF kernels.
% LFMGRADIENTH42VP Gradient of the function h_i(z) with respect to some of the
% LFMCOMPUTEH3VP Helper function for computing part of the LFMVXLFM kernel.
% GGKERNEXPANDPARAM Create kernel structure from GG kernel's parameters.
% EXPKERNDIAGGRADX Gradient of EXP kernel's diagonal with respect to X.
% WIENERKERNGRADIENT Gradient of WIENER kernel's parameters.
% RBFPERIODIC2KERNPARAMINIT RBFPERIODIC2 kernel parameter initialisation.
% NONEKERNEXPANDPARAM Create kernel structure from NONE kernel's parameters.
% KERNDIAGGRADIENT Compute the gradient of the kernel's parameters for the diagonal.
% RBFARDJITKERNEXTRACTPARAM Extract parameters from the RBFARD2 kernel structure.
% LFMAPGRADIENTSIGMAUPSILONVECTOR Gradient of upsilon vector ap wrt sigma
% LFMCOMPUTEH3AA Helper function for computing part of the LFMAA kernel.
% RBFHKERNEXTRACTPARAM Extract parameters from the RBFH kernel structure.
% LFMGRADIENTSIGMAH4 Gradient of the function h_i(z) with respect \sigma.
% SDLFMAXSDLFMAKERNGRADIENT Gradients of cross kernel between 2 SDLFM kernels.
% LFMJVCOMPUTEUPSILONMATRIX Upsilon matrix jolt. vel. with t1, t2 limits
% LFMKERNDIAGGRADX Gradient of LFM kernel's diagonal with respect to X.
% LFMAPCOMPUTEUPSILONVECTOR Upsilon vector for acce. pos. with t1 limit
% EXPKERNEXPANDPARAM Create kernel structure from EXP kernel's parameters.
% RBFINFWHITEKERNDIAGGRADX Gradient of RBF-WHITE kernel's (with integration
% RBFKERNEXPANDPARAM Create kernel structure from RBF kernel's parameters.
% GIBBSKERNDISPLAY Display parameters of the GIBBS kernel.
% OUKERNGRADIENT Gradient of OU kernel's parameters (see ouKernCompute or
% SDLFMKERNDIAGCOMPUTE Compute diagonal of a SDLFM kernel.
% SHEATKERNGRADIENT Gradient of the parameters of a SHEAT kernel.
% LFMWHITEXRBFWHITEKERNCOMPUTE Compute a cross kernel between an LFM-WHITE
% SDLFMAXSDLFMVKERNCOMPUTE Cross kernel between a SDLFMA and a SDLFMV kernels.
% RBFARDJITKERNEXPANDPARAM Create kernel structure from RBFARDJIT kernel's parameters.
% KERNEXTRACTPARAM Extract parameters from kernel structure.
% GGWHITEKERNEXTRACTPARAM Extract parameters from the GG WHITE kernel structure.
% SDLFMVKERNPARAMINIT SDLFMV kernel initialization
% KERNDISPLAY Display the parameters of the kernel.
% LFMVPGRADIENTUPSILONMATRIX Gradient upsilon matrix vel. pos.
% WHITEFIXEDKERNGRADIENT Gradient of WHITEFIXED kernel's parameters.
% RBFWHITEKERNCOMPUTE Compute the RBF-WHITE kernel given the parameters, t1
% VELOTRANSKERNCOMPUTE Compute the VELOTRANS kernel given the parameters and X.
% CMPNDKERNDIAGGRADIENT Compute the gradient of the CMPND kernel's diagonal wrt parameters.
% KERNPCA performs KPCA.
% LFMCOMPUTEH4AV Helper function for computing part of the LFMAV kernel.
% SDRBFKERNPARAMINIT SDRBF kernel initialization
% SIMCOMPUTEHSTAT Helper function for computing part of the stationary version
% RBFPERIODICKERNDIAGCOMPUTE Compute diagonal of RBFPERIODIC kernel.
% SDLFMXSDLFMKERNGRADIENTBLOCK Gradients of the parameters in block i,j
% GGWHITEXGAUSSIANWHITEKERNCOMPUTE Compute a cross kernel between the GG white and GAUSSIAN white kernels.
% DISIMKERNDIAGGRADIENT Compute the gradient of the DISIM kernel's diagonal wrt parameters.
% LFMVKERNEXTRACTPARAM Extract parameters from the LFMV kernel structure.
% LFMWHITECOMPUTEGRADTHETAH2 computes a portion of the LFM-WHITE kernel's gradient w.r.t. theta.
% WHITEHKERNGRADIENT Gradient of WHITEH kernel's parameters.
% KERNREADFROMFID Load from an FID written by the C++ implementation.
% SDLFMKERNMEANCOVPARTIAL Helper function for derivatives in SDLFM kernel
% VELOTRANSKERNGRADX Gradient of VELOTRANS kernel with respect to a point x.
% RBFARDJITKERNGRADIENT Gradient of RBFARD2 kernel's parameters.
% LFMWHITECOMPUTEH Helper function for computing part of the LFM-WHITE
% KERNCOMPUTE Compute the kernel given the parameters and X.
% MLPKERNPARAMINIT MLP kernel parameter initialisation.
% SIMKERNEXTRACTPARAM Extract parameters from the SIM kernel structure.
% SQEXPKERNDIAGGRADX Gradient of SQEXP kernel's diagonal with respect to X.
% HEATKERNEXTRACTPARAM Extract parameters from the HEAT kernel structure.
% RBFWHITEXRBFWHITEKERNGRADIENT Compute a cross gradient between two
% SIMWHITEKERNCOMPUTE Compute the SIM-WHITE kernel given the parameters, t1
% MLPARDKERNDISPLAY Display parameters of the MLPARD kernel.
% RBFINFWHITEXWHITEKERNGRADIENT Compute gradient between the RBF-WHITE kernel
% LFMLOGLIKEGRADIENTS Compute the gradients of the log likelihood of a LFM model.
% GIBBSKERNPARAMINIT GIBBS kernel parameter initialisation.
% SDLFMXSDLFMKERNCOMPUTE Compute a cross kernel between two SDLFM kernels.
% OUKERNEXTRACTPARAM Extract parameters from the OU kernel structure (see
% MATERN32KERNDISPLAY Display parameters of the MATERN32 kernel.
% MATERN32KERNGRADIENT Gradient of MATERN32 kernel's parameters.
% DEXPKERNPARAMINIT The double exponential kernel is usually called
% WHITEFIXEDKERNEXPANDPARAM Create kernel structure from WHITEFIXED kernel's parameters.
% SDLFMKERNDISPLAY Display parameters of the SDLFM kernel.
% LFMXLFMKERNGRADIENT Compute a cross gradient between two LFM kernels.
% MLPARDKERNGRADIENT Gradient of MLPARD kernel's parameters.
% LFMAKERNPARAMINIT LFMA kernel parameter initialisation. 
% POLYARDKERNEXTRACTPARAM Extract parameters from the POLYARD kernel structure.
% TENSORKERNSETINDEX Set the indices in the tensor kernel.
% LINARD2KERNCOMPUTE Compute the LINARD2 kernel given the parameters and X.
% SIMWHITEXRBFWHITEKERNCOMPUTE Compute a cross kernel between a SIM-WHITE
% RBFARDKERNDISPLAY Display parameters of the RBFARD kernel.
% LFMCOMPUTEH3 Helper function for computing part of the LFM kernel.
% MATERN32KERNGRADX Gradient of MATERN32 kernel with respect to input locations.
% GAUSSIANKERNDIAGCOMPUTE Compute diagonal of gaussian kernel.
% KERNDIAGGRADX Compute the gradient of the  kernel wrt X.
% LFMEXTRACTPARAM Extract the parameters of an LFM model.
% RATQUADKERNCOMPUTE Compute the RATQUAD kernel given the parameters and X.
% SQEXPKERNEXPANDPARAM Create kernel structure from SQEXP kernel's parameters.
% LFMAPGRADIENTUPSILONMATRIX Gradient upsilon matrix accel. pos.
% SIMXSIMKERNDIAGCOMPUTE Diagonal of a cross kernel between two SIM kernels.
% RBFWHITEKERNDISPLAY Display parameters of the RBF-WHITE kernel.
% GGWHITEKERNCOMPUTE Compute the GG white kernel given the parameters and X.
% WHITEFIXEDKERNEXTRACTPARAM Extract parameters from the WHITEFIXED kernel structure.
% SQEXPKERNEXTRACTPARAM Extract parameters from the SQEXP kernel structure.
% KERNGETVARIANCE Get the signal associated with a the kernel.
% LFMKERNEXPANDPARAM Create kernel structure from LFM kernel's parameters.
% VELOTRANSKERNEXPANDPARAM Create kernel structure from VELOTRANS kernel's parameters.
% LFMKERNEXTRACTPARAM Extract parameters from the LFM kernel structure.
% POLYKERNEXPANDPARAM Create kernel structure from POLY kernel's parameters.
% GAUSSIANKERNDIAGGRADX Gradient of gaussian kernel's diagonal with respect to X.
% MATERN32KERNCOMPUTE Compute the MATERN32 kernel given the parameters and X.
% BIASKERNGRADIENT Gradient of BIAS kernel's parameters.
% LFMCOMPUTEH3JP Helper function for computing part of the LFMJP kernel.
% RBFINFWHITEKERNEXPANDPARAM Create kernel structure from RBF-WHITE kernel's
% RBFPERIODIC2KERNDISPLAY Display parameters of the RBFPERIODIC2 kernel.
% RBFARDKERNEXTRACTPARAM Extract parameters from the RBFARD kernel structure.
% GIBBSKERNCOMPUTE Compute the GIBBS kernel given the parameters and X.
% VELOTRANSKERNGRADIENT Gradient of VELOTRANS kernel's parameters.
% TRANSLATEKERNGRADX Gradient of TRANSLATE kernel with respect to a point x.
% GAUSSIANWHITEKERNEXPANDPARAM Create kernel structure from gaussian white 
% RBFPERIODIC2KERNDIAGCOMPUTE Compute diagonal of RBFPERIODIC2 kernel.
% GGWHITEKERNPARAMINIT GG WHITE kernel parameter initialisation.
% SDLFMKERNGRADIENT Gradient of SDLFM kernel's parameters.
% GGKERNCOMPUTE Compute the GG kernel given the parameters and X.
% RBFKERNPARAMINIT RBF kernel parameter initialisation.
% WHITEKERNGRADX Gradient of WHITE kernel with respect to input locations.
% RBFARD2KERNEXTRACTPARAM Extract parameters from the RBFARD2 kernel structure.
% MATERN32KERNEXTRACTPARAM Extract parameters from the MATERN32 kernel structure.
% LFMWHITEKERNGRADX Gradient of LFM-WHITE kernel with respect to a point t.
% LFMKERNDISPLAY Display parameters of the LFM kernel.
% SDLFMXSDRBFKERNCOMPUTEBLOCK Cross kernel between SDLFM and SDRBF for i,j
% RBFPERIODIC2KERNDIAGGRADX Gradient of RBFPERIODIC2 kernel's diagonal with respect to X.
% LFMVKERNDIAGCOMPUTE Compute diagonal of LFMV kernel.
% MULTIKERNDIAGCOMPUTE Compute diagonal of MULTI kernel.
% WHITEKERNDIAGGRADIENT Compute the gradient of the WHITE kernel's diagonal wrt parameters.
% LFMVVCOMPUTEUPSILONDIAGVECTOR Upsilon vector vel. vel. with t1 = t2
% SIMKERNEXPANDPARAM Create kernel structure from SIM kernel's parameters.
% LFMUPDATEKERNELS Updates the kernel representations in the LFM structure.
% GGWHITEXWHITEKERNGRADIENT Compute gradient between the GGWHITE and WHITE kernels.
% LFMJACOMPUTEUPSILONMATRIX Upsilon matrix jolt. accel. with t1, t2 limits
% SDLFMKERNEXPANDPARAM Pass parameters from params to SDLFM kernel
% COMPONENTKERNWRITEPARAMSTOFID Write a component based kernel to a stream.
% GAUSSIANWHITEKERNDIAGGRADIENT Compute the gradient of the gaussian white 
% GIBBSPERIODICKERNGRADIENT Gradient of GIBBSPERIODIC kernel's parameters.
% RBFINFWHITEXWHITEKERNCOMPUTE Compute a cross kernel between the RBF-WHITE
% LFMGRADIENTSIGMAH3VP Gradient of the function h_i(z) with respect \sigma.
% WHITEHKERNDIAGGRADX Gradient of WHITEH kernel's diagonal with respect to X.
% DEXPKERNGRADX Gradient of the double exponential kernel with respect to a
% GAUSSIANWHITEKERNEXTRACTPARAM Extract parameters from the gaussian white 
% HEATKERNDIAGCOMPUTE Diagonal of a kernel matrix for a HEAT kernel.
% SDLFMAXSDRBFKERNGRADIENT Gradients cross kernel between a SDLFM and SDRBF
% SIMWHITEXRBFINFWHITEKERNCOMPUTE Compute a cross kernel between a SIM-WHITE
% LINKERNDISPLAY Display parameters of the LIN kernel.
% SDLFMAXSDLFMAKERNCOMPUTEBLOCK Computes SDLFM kernel matrix for block i,j
% LFMCOMPUTEH4JA Helper function for computing part of the LFMJA kernel.
% DEXPKERNDISPLAY Display parameters of the double exponential kernel.
% MULTIKERNCACHEBLOCK
% RBFARD2KERNEXPANDPARAM Create kernel structure from RBFARD2 kernel's parameters.
% SIMWHITEKERNGRADIENT Gradient of SIM-WHITE kernel's parameters.
% LFMAAGRADIENTSIGMAUPSILONMATRIX Gradient of upsilon matrix aa wrt sigma
% MATERN32KERNEXPANDPARAM Create kernel structure from MATERN32 kernel's parameters.
% POLYKERNPARAMINIT POLY kernel parameter initialisation.
% GGWHITEXGGWHITEKERNCOMPUTE Compute a cross kernel between two GG white kernels.
% RBFPERIODICKERNDISPLAY Display parameters of the RBFPERIODIC kernel.
% GGWHITEXWHITEKERNCOMPUTE Compute a cross kernel between a GG white and
% KERNPARAMINIT Kernel parameter initialisation.
% LFMAXRBFKERNCOMPUTE Compute cross kernel between the LFMA and RBF kernels.
% LINARDKERNEXTRACTPARAM Extract parameters from the LINARD kernel structure.
% OUKERNPARAMINIT Ornstein-Uhlenbeck (OU) kernel parameter initialisation.
% RBFPERIODIC2KERNCOMPUTE Compute the RBFPERIODIC2 kernel given the parameters and X.
% WHITEHKERNDIAGCOMPUTE Compute diagonal of WHITEH kernel.
% KERNEXPANDPARAM Expand parameters to form a kernel structure.
% GGXGGKERNGRADIENT Compute a cross gradient between two GG kernels.
% TENSORKERNEXTRACTPARAM Extract parameters from the TENSOR kernel structure.
% COMPONENTKERNREADPARAMSFROMFID Read a component based kernel from a C++ file.
% LFMJPCOMPUTEUPSILONMATRIX Upsilon matrix jolt. pos. with t1, t2 limits
% LFMXLFMKERNCOMPUTE Compute a cross kernel between two LFM kernels.
% WHITEHKERNEXTRACTPARAM Extract parameters from the WHITEH kernel structure.
% RBFPERIODICKERNEXTRACTPARAM Extract parameters from the RBFPERIODIC kernel structure.
% MLPKERNDISPLAY Display parameters of the MLP kernel.
% LFMAXLFMAKERNCOMPUTE Acceleration and acceleration LFM kernel  
% RBFHKERNDIAGGRADIENT Gradient of the RBFH kernel's diagonal wrt parameters.
% BIASKERNEXPANDPARAM Create kernel structure from BIAS kernel's parameters.
% LFMGRADIENTSIGMAH3 Gradient of the function h_i(z) with respect \sigma.
% LFMAPGRADIENTSIGMAUPSILONMATRIX Gradient of upsilon matrix ap wrt sigma
% LFMKERNCOMPUTE Compute the LFM kernel given the parameters and X.
% GGKERNPARAMINIT GG kernel parameter initialisation.
% KERNELCENTER Attempts to Center Kernel Matrix
% LFMAXLFMKERNGRADIENT Compute a cross gradient between a LFMA and a LFM.
% WHITEXWHITEKERNGRADIENT Compute a cross gradient between two WHITE kernels.
% LFMWHITECOMPUTEPSI Helper function for comptuing part of the LFM-WHITE
% LFMGRADIENTH42 Gradient of the function h_i(z) with respect to some of the
% WHITEFIXEDXWHITEFIXEDKERNCOMPUTE Compute a cross kernel between two WHITEFIXED kernels.
% SIMWHITEKERNDIAGCOMPUTE Compute the diagonal of the SIM-WHITE kernel.
% RBFINFWHITEKERNCOMPUTE Compute the RBF-WHITE kernel (with integration limits
% FILEKERNPARAMINIT FILE kernel parameter initialisation.
% OUKERNCOMPUTE Compute the Ornstein-Uhlenbeck (OU) kernel arising from the
% LFMAKERNDISPLAY Display parameters of the LFMA kernel.
% WIENERKERNDISPLAY Display parameters of the WIENER kernel.
% ARDKERNDIAGGRADIENT Compute the gradient of the ARD kernel's diagonal wrt parameters.
% OUKERNDIAGGRADX Gradient of OU kernel's diagonal with respect to t (see
% SDLFMXSDLFMKERNGRADIENTIC Computes partial derivative for init. const.
% MULTIKERNPARAMINIT MULTI kernel parameter initialisation.
% LFMCOMPUTEH4AP Helper function for computing part of the LFMAP kernel.
% GIBBSKERNEXTRACTPARAM Extract parameters from the GIBBS kernel structure.
% LFMAXRBFVKERNCOMPUTE Compute cross kernel between the LFMA and RBFV kernels.
% RBFPERIODIC2KERNGRADX Gradient of RBFPERIODIC2 kernel with respect to a point x.
% WHITEFIXEDKERNDIAGCOMPUTE Compute diagonal of WHITEFIXED kernel.
% WHITEFIXEDKERNCOMPUTE Compute the WHITEFIXED kernel given the parameters and X.
% RBFPERIODIC2KERNGRADIENT Gradient of RBFPERIODIC2 kernel's parameters.
% GAUSSIANKERNDISPLAY Display parameters of the GAUSSIAN kernel.
% TRANSLATEKERNPARAMINIT TRANSLATE kernel parameter initialisation.
% SIMKERNDISPLAY Display parameters of the SIM kernel.
% OUKERNDIAGCOMPUTE Compute diagonal of OU kernel (see ouKernCompute or
% DEXPKERNGRADIENT Gradient of the double exponential kernel's parameters.
% SDLFMVXSDLFMKERNCOMPUTEBLOCK Computes SDLFM kernel matrix for block i,j
% SDLFMVXSDLFMKERNGRADIENTBLOCK Gradients of the parameters in block i,j
% LMCKERNDIAGGRADX Gradient of LMC kernel's diagonal with respect to X.
% EXPKERNGRADX Gradient of EXP kernel with respect to a point x.
% KERNGRADIENT Compute the gradient wrt the kernel's parameters.
% LFMKERNGRADIENT Gradient of LFM kernel's parameters.
% LFMAVGRADIENTSIGMAUPSILONMATRIX Gradient of upsilon matrix av wrt sigma
% LMCKERNEXPANDPARAM Expands parameters into a LMC kernel structure.
% WIENERKERNGRADX Gradient of WIENER kernel with respect to a point x.
% WHITEXWHITEKERNCOMPUTE Compute a cross kernel between two WHITE kernels.
% LFMGRADIENTSIGMAUPSILON Gradient of the function \upsilon(z) with respect
% SDLFMXSDRBFKERNGRADIENTBLOCKIEJ 
% GGKERNDISPLAY Display parameters of the GG kernel.
% LFMWHITEKERNDIAGGRADX Gradient of LFM-WHITE kernel's diagonal w.r.t. t.
% SQEXPKERNDIAGGRADIENT Compute the gradient of the SQEXP kernel's diagonal wrt parameters.
% NONEKERNDISPLAY Display parameters of the NONE kernel.
% LFMCOMPUTEUPSILON Helper function for comptuing part of the LFM kernel.
% LINKERNEXTRACTPARAM Extract parameters from the LIN kernel structure.
% LFMWHITEKERNDIAGCOMPUTE Compute diagonal of LFM-WHITE kernel.
% CMPNDKERNDIAGGRADX Gradient of CMPND kernel's diagonal with respect to X.
% WHITEBLOCKKERNCOMPUTE Compute the WHITEBLOCK kernel. 
% GGWHITEKERNDISPLAY Display parameters of the GG WHITE kernel.
% RBFHKERNDIAGCOMPUTE Compute diagonal of RBFH kernel.
% GIBBSPERIODICKERNPARAMINIT GIBBSPERIODIC kernel parameter initialisation.
% WHITEBLOCKKERNDIAGGRADIENT WHITEBLOCK kernel's diagonal gradient wrt par.
% LFMCREATE Create a LFM model.
% RBFWHITEXWHITEKERNGRADIENT Compute gradient between the RBF-WHITE and
% SDLFMKERNEXTRACTPARAM Extract parameters from the SDLFM kernel structure.
% SIMWHITEXSIMWHITEKERNGRADIENT Compute a cross gradient between two
% LINARDKERNDIAGGRADX Gradient of LINARD kernel's diagonal with respect to X.
% LFMCOMPUTETEST Test the file lfmComputeH.
% LINARD2KERNDIAGCOMPUTE Compute diagonal of LINARD2 kernel.
% WHITEFIXEDKERNDISPLAY Display parameters of the WHITEFIXED kernel.
% LFMAACOMPUTEUPSILONMATRIX Upsilon matrix acce. accel. with t1, t2 limits
% MULTIKERNEXPANDPARAM Create kernel structure from MULTI kernel's parameters.
% TRANSLATEKERNEXPANDPARAM Create kernel structure from TRANSLATE kernel's parameters.
% HEATKERNCOMPUTE Compute a kernel matrix for a HEAT kernel.
% LFMVPCOMPUTEUPSILONVECTOR Upsilon vector for vel. pos. with t1 limit
% KERNWRITETOFID Load from an FID written by the C++ implementation.
% HEATKERNPARAMINIT HEAT kernel parameter initialisation.
% VELOTRANSKERNPARAMINIT VELOTRANS kernel parameter initialisation.
% SDLFMAXSDLFMKERNGRADIENTBLOCK Gradients of the parameters in block i,j
% BIASKERNDISPLAY Display parameters of the BIASkernel.
% LMCKERNEXTRACTPARAM Extract parameters from the LMC kernel struc.
% LFMAKERNEXTRACTPARAM Extract parameters from the LFMA kernel structure.
% GGXGAUSSIANKERNGRADX Compute gradient between the GG and GAUSSIAN
% VELOTRANSKERNDIAGCOMPUTE Compute diagonal of VELOTRANS kernel.
% RBFKERNDISPLAY Display parameters of the RBF kernel.
% MLPARDKERNEXPANDPARAM Create kernel structure from MLPARD kernel's parameters.
% BIASKERNDIAGGRADX Gradient of BIAS kernel's diagonal with respect to X.
% GGXGAUSSIANKERNCOMPUTE Compute a cross kernel between the GG and GAUSSIAN kernels.
% SRBFHKERNGRADIENT Gradient of the parameters of a SRBFH kernel.
% MATERN52KERNDIAGCOMPUTE Compute diagonal of MATERN52 kernel.
% MLPKERNDIAGGRADX Gradient of MLP kernel's diagonal with respect to X.
% GIBBSPERIODICKERNDIAGGRADIENT Compute the gradient of the GIBBSPERIODIC kernel's diagonal wrt parameters.
% SIMKERNDIAGGRADX Gradient of SIM kernel's diagonal with respect to the
% LINARDKERNEXPANDPARAM Create kernel structure from LINARD kernel's parameters.
% GGWHITEKERNDIAGCOMPUTE Compute diagonal of GG WHITE kernel.
% WHITEKERNDISPLAY Display parameters of the WHITE kernel.
% CMPNDKERNCOMPUTE Compute the CMPND kernel given the parameters and X.
% LFMAKERNDIAGCOMPUTE Compute diagonal of LFMAXLFMA kernel.
% KERNWRITEPARAMSTOFID Write the kernel parameters to a stream.
% SIMWHITEXSIMWHITEKERNCOMPUTE Compute a cross kernel between two SIM-WHITE
% LFMVXLFMKERNCOMPUTE Velocity and position LFM kernel  
% ARDKERNEXPANDPARAM Create kernel structure from ARD kernel's parameters.
% VELOTRANSKERNEXTRACTPARAM Extract parameters from the VELOTRANS kernel structure.
% LFMGRADIENTSIGMAH4VP Gradient of the function h_i(z) with respect \sigma.
% SDLFMAXSDRBFKERNCOMPUTE Cross kernel between a SDLFMA and a SDRBF kernels.
% WHITEFIXEDKERNPARAMINIT WHITEFIXED kernel parameter initialisation.
% MATERN52KERNDIAGGRADIENT Compute the gradient of the MATERN52 kernel's diagonal wrt parameters.
% LINARD2KERNDISPLAY Display parameters of the LINARD2 kernel.
% LINARDKERNPARAMINIT LINARD kernel parameter initialisation.
% MLPARDKERNDIAGCOMPUTE Compute diagonal of MLPARD kernel.
% SDLFMAMEANGRADIENT Gradients wrt parameters of the accel. mean SDLFM.
% BIASKERNDIAGCOMPUTE Compute diagonal of BIAS kernel.
% RATQUADKERNEXPANDPARAM Create kernel structure from RATQUAD kernel's parameters.
% SDRBFKERNEXPANDPARAM Pass parameters from params to SDRBF kernel
% FILEKERNDISPLAY Display parameters of the FILE kernel.
% WHITEKERNDIAGGRADX Gradient of WHITE kernel's diagonal with respect to X.
% GAUSSIANWHITEKERNDIAGCOMPUTE Compute diagonal of gaussian white kernel.
% LMCKERNDIAGGRADIENT Gradient of the LMC kernel's diagonal wrt parameters.
% LFMGRADIENTSIGMAH4AP Gradient of the function h_i(z) with respect \sigma.
% GGKERNDIAGGRADIENT Compute gradient of the diagonal of GG kernel.
% SIMWHITEKERNDIAGGRADX Gradient of SIM-WHITE kernel's diagonal w.r.t. t.
% LINKERNGRADIENT Gradient of LIN kernel's parameters.
% MATERN32KERNDIAGGRADIENT Compute the gradient of the MATERN32 kernel's diagonal wrt parameters.
% RBFINFWHITEKERNEXTRACTPARAM Extract parameters from the RBF-WHITE kernel
% GAUSSIANWHITEKERNGRADIENT Gradient of gaussian white kernel's parameters.
% HEATKERNDISPLAY Display parameters of the HEAT kernel.
% SHEATKERNDIAGCOMPUTE Compute a diagonal for the SHEAT kernel matrix.
% RBFXNONEKERNCOMPUTE Compute a cross kernel between RBF and NONE kernels.
% SDRBFKERNGRADIENT Gradient of SDRBF kernel's parameters.
% DISIMXRBFKERNGRADIENT Compute gradient between the DISIM and RBF kernels.
% LFMAKERNEXPANDPARAM Create kernel structure from LFMA kernel's parameters.
% MULTIKERNGRADX Gradient of MULTI kernel with respect to a point x.
% HEATKERNEXPANDPARAM Create kernel structure from HEAT kernel's parameters.
% KERNTOOLBOXES Load in the relevant toolboxes for kern.
% FILEKERNCOMPUTE Compute the FILE kernel given the parameters and X.
% POLYKERNGRADX Gradient of POLY kernel with respect to input locations.
% SDLFMAXSDLFMKERNCOMPUTE Cross kernel between a SDLFMA and a SDLFM kernels.
% LFMGRADIENTSIGMAH3VV Gradient of the function h_i(z) with respect \sigma.
% MULTIKERNCOMPUTE Compute the MULTI kernel given the parameters and X.
% PSKERNELGRADIENT Gradient on likelihood approximation for point set IVM.
% CMPNDKERNPARAMINIT CMPND kernel parameter initialisation.
% LMCKERNGRADX Gradient of LMC kernel with respect to input locations.
% RBFKERNDIAGGRADX Gradient of RBF kernel's diagonal with respect to X.
% MLPARDKERNEXTRACTPARAM Extract parameters from the MLPARD kernel structure.
% ARDKERNDIAGGRADX Gradient of ARD kernel's diagonal with respect to X.
