% KERN toolbox
% Version 0.162		Saturday 14 Oct 2006 at 22:35
% Copyright (c) 2006 Neil D. Lawrence
% 
% ARDKERNCOMPUTE Compute the ARD kernel given the parameters and X.
% ARDKERNDIAGCOMPUTE Compute diagonal of ARD kernel.
% ARDKERNDIAGGRADX Gradient of ARD kernel's diagonal with respect to X.
% ARDKERNDISPLAY Display parameters of the ARD kernel.
% ARDKERNEXPANDPARAM Create kernel structure from ARD kernel's parameters.
% ARDKERNEXTRACTPARAM Extract parameters from the ARD kernel structure.
% ARDKERNGRADX Gradient of ARD kernel with respect to a point x.
% ARDKERNGRADIENT Gradient of ARD kernel's parameters.
% ARDKERNPARAMINIT ARD kernel parameter initialisation.
% BIASKERNCOMPUTE Compute the BIAS kernel given the parameters and X.
% BIASKERNDIAGCOMPUTE Compute diagonal of BIAS kernel.
% BIASKERNDIAGGRADX Gradient of BIAS kernel's diagonal with respect to X.
% BIASKERNDISPLAY Display parameters of the BIASkernel.
% BIASKERNEXPANDPARAM Create kernel structure from BIAS kernel's parameters.
% BIASKERNEXTRACTPARAM Extract parameters from the BIAS kernel structure.
% BIASKERNGRADX Gradient of BIAS kernel with respect to a point x.
% COMPUTEKERNEL Compute the kernel given the parameters and X.
% BIASKERNGRADIENT Gradient of BIAS kernel's parameters.
% BIASKERNPARAMINIT BIAS kernel parameter initialisation.
% CMPNDKERNCOMPUTE Compute the CMPND kernel given the parameters and X.
% CMPNDKERNDIAGCOMPUTE Compute diagonal of CMPND kernel.
% CMPNDKERNDIAGGRADX Gradient of CMPND kernel's diagonal with respect to X.
% CMPNDKERNDISPLAY Display parameters of the CMPND kernel.
% CMPNDKERNEXPANDPARAM Create kernel structure from CMPND kernel's parameters.
% CMPNDKERNEXTRACTPARAM Extract parameters from the CMPND kernel structure.
% CMPNDKERNGRADX Gradient of CMPND kernel with respect to a point x.
% CMPNDKERNGRADIENT Gradient of CMPND kernel's parameters.
% CMPNDKERNPARAMINIT CMPND kernel parameter initialisation.
% CMPNDKERNREADPARAMSFROMFID Read a compound kernel from a C++ file.
% KERNCOMPUTE Compute the kernel given the parameters and X.
% KERNCREATE Initialise a kernel structure.
% KERNDIAGCOMPUTE Compute the kernel given the parameters and X.
% FILEKERNCOMPUTE Compute the FILE kernel given the parameters and X.
% FILEKERNDIAGCOMPUTE Compute diagonal of FILE kernel.
% KERNDIAGGRADX Compute the gradient of the  kernel wrt X.
% KERNDISPLAY Display the parameters of the kernel.
% KERNEXPANDPARAM Expand parameters to form a kernel structure.
% KERNEXTRACTPARAM Extract parameters from kernel structure.
% KERNFACTORS Extract factors associated with transformed optimisation space.
% KERNGRADX Compute the gradient of the kernel wrt X.
% KERNGRADIENT Compute the gradient wrt the kernel's parameters.
% KERNPARAMINIT Kernel parameter initialisation.
% KERNPCA performs KPCA.
% KERNPRIORGRADIENT Compute gradient terms associated with kernel priors.
% KERNPRIORLOGPROB Compute penalty terms associated with kernel priors.
% KERNREADFROMFID Load from an FID written by the C++ implementation.
% MULTIKERNDISPLAY Display parameters of the MULTI kernel.
% KERNREADPARAMSFROMFID Read the kernel parameters from C++ file FID.
% KERNTEST Run some tests on the specified kernel.
% KERNSETWHITE Helper function to set the white noise in a kernel if it exists.
% LINKERNCOMPUTE Compute the LIN kernel given the parameters and X.
% LINKERNDIAGCOMPUTE Compute diagonal of LIN kernel.
% LINKERNDIAGGRADX Gradient of LIN kernel's diagonal with respect to X.
% LINKERNDISPLAY Display parameters of the LIN kernel.
% LINKERNEXPANDPARAM Create kernel structure from LIN kernel's parameters.
% LINKERNEXTRACTPARAM Extract parameters from the LIN kernel structure.
% LINKERNGRADX Gradient of LIN kernel with respect to a point x.
% LINKERNGRADIENT Gradient of LIN kernel's parameters.
% LINKERNPARAMINIT LIN kernel parameter initialisation.
% LINARDKERNCOMPUTE Compute the LINARD kernel given the parameters and X.
% LINARDKERNDIAGCOMPUTE Compute diagonal of LINARD kernel.
% LINARDKERNDIAGGRADX Gradient of LINARD kernel's diagonal with respect to X.
% LINARDKERNDISPLAY Display parameters of the LINARD kernel.
% KERNGETVARIANCE Get the signal associated with a the kernel.
% LINARDKERNEXPANDPARAM Create kernel structure from LINARD kernel's parameters.
% LINARDKERNEXTRACTPARAM Extract parameters from the LINARD kernel structure.
% LINARDKERNGRADX Gradient of LINARD kernel with respect to a point x.
% LINARDKERNGRADIENT Gradient of LINARD kernel's parameters.
% LINARDKERNPARAMINIT LINARD kernel parameter initialisation.
% MULTIKERNDIAGCOMPUTE Compute diagonal of MULTI kernel.
% MLPKERNCOMPUTE Compute the MLP kernel given the parameters and X.
% MLPKERNDIAGCOMPUTE Compute diagonal of MLP kernel.
% MLPKERNDIAGGRADX Gradient of MLP kernel's diagonal with respect to X.
% MLPKERNDISPLAY Display parameters of the MLP kernel.
% MLPKERNEXPANDPARAM Create kernel structure from MLP kernel's parameters.
% MLPKERNEXTRACTPARAM Extract parameters from the MLP kernel structure.
% MLPKERNGRADX Gradient of MLP kernel with respect to a point x.
% MLPKERNGRADIENT Gradient of MLP kernel's parameters.
% FILEKERNDISPLAY Display parameters of the FILE kernel.
% MLPKERNPARAMINIT MLP kernel parameter initialisation.
% MLPARDKERNCOMPUTE Compute the MLPARD kernel given the parameters and X.
% MLPARDKERNDIAGCOMPUTE Compute diagonal of MLPARD kernel.
% MLPARDKERNDIAGGRADX Gradient of MLPARD kernel's diagonal with respect to X.
% MLPARDKERNDISPLAY Display parameters of the MLPARD kernel.
% MLPARDKERNEXPANDPARAM Create kernel structure from MLPARD kernel's parameters.
% MLPARDKERNEXTRACTPARAM Extract parameters from the MLPARD kernel structure.
% MLPARDKERNGRADX Gradient of MLPARD kernel with respect to a point x.
% MLPARDKERNGRADIENT Gradient of MLPARD kernel's parameters.
% MLPARDKERNPARAMINIT MLPARD kernel parameter initialisation.
% POLYKERNCOMPUTE Compute the POLY kernel given the parameters and X.
% POLYKERNDIAGCOMPUTE Compute diagonal of POLY kernel.
% POLYKERNDIAGGRADX Gradient of POLY kernel's diagonal with respect to X.
% POLYKERNDISPLAY Display parameters of the POLY kernel.
% POLYKERNEXPANDPARAM Create kernel structure from POLY kernel's parameters.
% POLYKERNEXTRACTPARAM Extract parameters from the POLY kernel structure.
% POLYKERNGRADX Gradient of POLY kernel with respect to a point x.
% POLYKERNGRADIENT Gradient of POLY kernel's parameters.
% POLYKERNPARAMINIT POLY kernel parameter initialisation.
% POLYARDKERNCOMPUTE Compute the POLYARD kernel given the parameters and X.
% POLYARDKERNDIAGCOMPUTE Compute diagonal of POLYARD kernel.
% POLYARDKERNDIAGGRADX Gradient of POLYARD kernel's diagonal with respect to X.
% POLYARDKERNDISPLAY Display parameters of the POLYARD kernel.
% POLYARDKERNEXPANDPARAM Create kernel structure from POLYARD kernel's parameters.
% POLYARDKERNEXTRACTPARAM Extract parameters from the POLYARD kernel structure.
% POLYARDKERNGRADX Gradient of POLYARD kernel with respect to a point x.
% POLYARDKERNGRADIENT Gradient of POLYARD kernel's parameters.
% POLYARDKERNPARAMINIT POLYARD kernel parameter initialisation.
% PSKERNELGRADIENT Gradient on likelihood approximation for point set IVM.
% PSKERNELOBJECTIVE Likelihood approximation for point set IVM.
% RBFKERNCOMPUTE Compute the RBF kernel given the parameters and X.
% RBFKERNDIAGCOMPUTE Compute diagonal of RBF kernel.
% RBFKERNDIAGGRADX Gradient of RBF kernel's diagonal with respect to X.
% RBFKERNDISPLAY Display parameters of the RBF kernel.
% RBFKERNEXPANDPARAM Create kernel structure from RBF kernel's parameters.
% RBFKERNEXTRACTPARAM Extract parameters from the RBF kernel structure.
% RBFKERNGRADX Gradient of RBF kernel with respect to a point x.
% RBFKERNGRADIENT Gradient of RBF kernel's parameters.
% RBFKERNPARAMINIT RBF kernel parameter initialisation.
% RBFARDKERNCOMPUTE Compute the RBFARD kernel given the parameters and X.
% RBFARDKERNDIAGCOMPUTE Compute diagonal of RBFARD kernel.
% RBFARDKERNDIAGGRADX Gradient of RBFARD kernel's diagonal with respect to X.
% RBFARDKERNDISPLAY Display parameters of the RBFARD kernel.
% RBFARDKERNEXPANDPARAM Create kernel structure from RBFARD kernel's parameters.
% RBFARDKERNEXTRACTPARAM Extract parameters from the RBFARD kernel structure.
% RBFARDKERNGRADX Gradient of RBFARD kernel with respect to a point x.
% RBFARDKERNGRADIENT Gradient of RBFARD kernel's parameters.
% FILEKERNEXPANDPARAM Create kernel structure from FILE kernel's parameters.
% FILEKERNEXTRACTPARAM Extract parameters from the FILE kernel structure.
% FILEKERNGRADX Gradient of FILE kernel with respect to a point x.
% RBFARDKERNPARAMINIT RBFARD kernel parameter initialisation.
% SQEXPKERNCOMPUTE Compute the SQEXP kernel given the parameters and X.
% SQEXPKERNDIAGCOMPUTE Compute diagonal of SQEXP kernel.
% SQEXPKERNDIAGGRADX Gradient of SQEXP kernel's diagonal with respect to X.
% SQEXPKERNDISPLAY Display parameters of the SQEXP kernel.
% SQEXPKERNEXPANDPARAM Create kernel structure from SQEXP kernel's parameters.
% SQEXPKERNEXTRACTPARAM Extract parameters from the SQEXP kernel structure.
% SQEXPKERNGRADX Gradient of SQEXP kernel with respect to a point x.
% SQEXPKERNGRADIENT Gradient of SQEXP kernel's parameters.
% SQEXPKERNPARAMINIT SQEXP kernel parameter initialisation.
% WHITEKERNCOMPUTE Compute the WHITE kernel given the parameters and X.
% WHITEKERNDIAGCOMPUTE Compute diagonal of WHITE kernel.
% WHITEKERNDIAGGRADX Gradient of WHITE kernel's diagonal with respect to X.
% WHITEKERNDISPLAY Display parameters of the WHITEkernel.
% WHITEKERNEXPANDPARAM Create kernel structure from WHITE kernel's parameters.
% WHITEKERNEXTRACTPARAM Extract parameters from the WHITE kernel structure.
% WHITEKERNGRADX Gradient of WHITE kernel with respect to a point x.
% WHITEKERNGRADIENT Gradient of WHITE kernel's parameters.
% WHITEKERNPARAMINIT WHITE kernel parameter initialisation.
% TENSORKERNCOMPUTE Compute the TENSOR kernel given the parameters and X.
% TENSORKERNPARAMINIT TENSOR kernel parameter initialisation.
% MULTIKERNCOMPUTEBLOCK
% MULTIKERNPARAMINIT MULTI kernel parameter initialisation.
% FILEKERNGRADIENT Gradient of FILE kernel's parameters.
% FILEKERNPARAMINIT FILE kernel parameter initialisation.
% FILEKERNREAD Read kernel values from file or cache.
% TENSORKERNEXPANDPARAM Create kernel structure from TENSOR kernel's parameters.
% TENSORKERNEXTRACTPARAM Extract parameters from the TENSOR kernel structure.
% TENSORKERNDIAGCOMPUTE Compute diagonal of TENSOR kernel.
% TENSORKERNDISPLAY Display parameters of the TENSOR kernel.
% LINKERNDIAGGRADIENT Compute the gradient of the LIN kernel's diagonal wrt parameters.
% TENSORKERNGRADIENT Gradient of TENSOR kernel's parameters.
% TENSORKERNGRADX Gradient of TENSOR kernel with respect to a point x.
% ARDKERNDIAGGRADIENT Compute the gradient of the ARD kernel's diagonal wrt parameters.
% LINARDKERNDIAGGRADIENT Compute the gradient of the LINARD kernel's diagonal wrt parameters.
% MLPKERNDIAGGRADIENT Compute the gradient of the MLP kernel's diagonal wrt parameters.
% MLPARDKERNDIAGGRADIENT Compute the gradient of the MLPARD kernel's diagonal wrt parameters.
% TENSORKERNDIAGGRADX Gradient of TENSOR kernel's diagonal with respect to X.
% CMPNDKERNSETINDEX Set the indices in the compound kernel.
% TENSORKERNSLASH Tensor kernel created by removing ith component.
% POLYKERNDIAGGRADIENT Compute the gradient of the POLY kernel's diagonal wrt parameters.
% WHITEFIXEDKERNCOMPUTE Compute the WHITEFIXED kernel given the parameters and X.
% TENSORKERNSETINDEX Set the indices in the tensor kernel.
% POLYARDKERNDIAGGRADIENT Compute the gradient of the POLYARD kernel's diagonal wrt parameters.
% SIMCOMPUTEH Helper function for comptuing part of the SIM kernel.
% SIMKERNCOMPUTE Compute the SIM kernel given the parameters and X.
% SIMKERNDIAGCOMPUTE Compute diagonal of SIM kernel.
% KERNSETINDEX Set the indices on a compound kernel.
% WHITEFIXEDKERNDIAGCOMPUTE Compute diagonal of WHITEFIXED kernel.
% WHITEFIXEDKERNDIAGGRADX Gradient of WHITEFIXED kernel's diagonal with respect to X.
% WHITEFIXEDKERNDISPLAY Display parameters of the WHITEFIXED kernel.
% WHITEFIXEDKERNEXPANDPARAM Create kernel structure from WHITEFIXED kernel's parameters.
% WHITEFIXEDKERNEXTRACTPARAM Extract parameters from the WHITEFIXED kernel structure.
% WHITEFIXEDKERNGRADX Gradient of WHITEFIXED kernel with respect to a point x.
% WHITEFIXEDKERNGRADIENT Gradient of WHITEFIXED kernel's parameters.
% WHITEFIXEDKERNPARAMINIT WHITEFIXED kernel parameter initialisation.
% SIMKERNDIAGGRADX Gradient of SIM kernel's diagonal with respect to X.
% SIMKERNDISPLAY Display parameters of the SIM kernel.
% SIMKERNEXPANDPARAM Create kernel structure from SIM kernel's parameters.
% CMPNDKERNDIAGGRADIENT Compute the gradient of the CMPND kernel's diagonal wrt parameters.
% KERNDIAGGRADIENT Compute the gradient of the kernel's parameters for the diagonal.
% RBFKERNDIAGGRADIENT Compute the gradient of the RBF kernel's diagonal wrt parameters.
% RBFARDKERNDIAGGRADIENT Compute the gradient of the RBFARD kernel's diagonal wrt parameters.
% WHITEKERNDIAGGRADIENT Compute the gradient of the WHITE kernel's diagonal wrt parameters.
% SIMKERNEXTRACTPARAM Extract parameters from the SIM kernel structure.
% SIMKERNGRADX Gradient of SIM kernel with respect to a point x.
% WHITEFIXEDKERNDIAGGRADIENT Compute the gradient of the WHITEFIXED kernel's diagonal wrt parameters.
% SIMKERNGRADIENT Gradient of SIM kernel's parameters.
% SIMKERNPARAMINIT SIM kernel parameter initialisation.
% SIMXRBFKERNCOMPUTE Compute a cross kernel between the SIM and RBF kernels.
% SIMXSIMKERNCOMPUTE Compute a cross kernel between two SIM kernels.
% BIASKERNDIAGGRADIENT Compute the gradient of the BIAS kernel's diagonal wrt parameters.
% SQEXPKERNDIAGGRADIENT Compute the gradient of the SQEXP kernel's diagonal wrt parameters.
% TENSORKERNDIAGGRADIENT Compute the gradient of the TENSOR kernel's diagonal wrt parameters.
% MULTIKERNGRADIENT Gradient of MULTI kernel's parameters.
% MULTIKERNEXTRACTPARAM Extract parameters from the MULTI kernel structure.
% MULTIKERNDIAGGRADIENT Compute the gradient of the MULTI kernel's diagonal wrt parameters.
% MULTIKERNEXPANDPARAM Create kernel structure from MULTI kernel's parameters.
% MULTIKERNDIAGGRADX Gradient of MULTI kernel's diagonal with respect to X.
% MULTIKERNGRADX Gradient of MULTI kernel with respect to a point x.
% MULTIKERNTEST Run some tests on the multiple output block kernel.
% MULTIKERNCOMPUTE Compute the MULTI kernel given the parameters and X.
% MULTIKERNGRADIENTBLOCK
% SIMXSIMKERNGRADIENT Compute a cross gradient between two SIM kernels.
% SIMKERNDIAGGRADIENT Compute the gradient of the SIM kernel's diagonal wrt parameters.
% SIMXRBFKERNGRADIENT Compute gradient between the SIM and RBF kernels.
% SIMCOMPUTETEST Test the file simComputeH.
% WHITEXWHITEKERNCOMPUTE Compute a cross kernel between two WHITE kernels.
% WHITEXWHITEKERNGRADIENT Compute a cross gradient between two WHITE kernels.
% MATERN32KERNCOMPUTE Compute the MATERN32 kernel given the parameters and X.
% MATERN32KERNDIAGCOMPUTE Compute diagonal of MATERN32 kernel.
% MATERN32KERNDIAGGRADX Gradient of MATERN32 kernel's diagonal with respect to X.
% MATERN32KERNDIAGGRADIENT Compute the gradient of the MATERN32 kernel's diagonal wrt parameters.
% MATERN32KERNDISPLAY Display parameters of the MATERN32 kernel.
% MATERN32KERNEXPANDPARAM Create kernel structure from MATERN32 kernel's parameters.
% MATERN32KERNEXTRACTPARAM Extract parameters from the MATERN32 kernel structure.
% MATERN32KERNGRADX Gradient of MATERN32 kernel with respect to a point x.
% MATERN32KERNGRADIENT Gradient of MATERN32 kernel's parameters.
% MATERN32KERNPARAMINIT MATERN32 kernel parameter initialisation.
% MATERN52KERNCOMPUTE Compute the MATERN52 kernel given the parameters and X.
% MATERN52KERNDIAGCOMPUTE Compute diagonal of MATERN52 kernel.
% MATERN52KERNDIAGGRADIENT Compute the gradient of the MATERN52 kernel's diagonal wrt parameters.
% MATERN52KERNDISPLAY Display parameters of the MATERN52 kernel.
% RATQUADKERNGRADIENT Gradient of RATQUAD kernel's parameters.
% RATQUADKERNPARAMINIT RATQUAD kernel parameter initialisation.
% GIBBSKERNEXTRACTPARAM Extract parameters from the GIBBS kernel structure.
% GIBBSKERNPARAMINIT GIBBS kernel parameter initialisation.
% MATERN52KERNEXPANDPARAM Create kernel structure from MATERN52 kernel's parameters.
% MATERN52KERNEXTRACTPARAM Extract parameters from the MATERN52 kernel structure.
% MATERN52KERNGRADX Gradient of MATERN52 kernel with respect to a point x.
% MATERN52KERNGRADIENT Gradient of MATERN52 kernel's parameters.
% MATERN52KERNPARAMINIT MATERN52 kernel parameter initialisation.
% RATQUADKERNCOMPUTE Compute the RATQUAD kernel given the parameters and X.
% RATQUADKERNDIAGCOMPUTE Compute diagonal of RATQUAD kernel.
% RATQUADKERNDIAGGRADX Gradient of RATQUAD kernel's diagonal with respect to X.
% RATQUADKERNDIAGGRADIENT Compute the gradient of the RATQUAD kernel's diagonal wrt parameters.
% RATQUADKERNDISPLAY Display parameters of the RATQUAD kernel.
% RATQUADKERNEXPANDPARAM Create kernel structure from RATQUAD kernel's parameters.
% RATQUADKERNEXTRACTPARAM Extract parameters from the RATQUAD kernel structure.
% RATQUADKERNGRADX Gradient of RATQUAD kernel with respect to a point x.
% GIBBSKERNDIAGCOMPUTE Compute diagonal of GIBBS kernel.
% MATERN52KERNDIAGGRADX Gradient of MATERN52 kernel's diagonal with respect to X.
% GIBBSKERNGRADIENT Gradient of GIBBS kernel's parameters.
% GIBBSKERNDIAGGRADIENT Compute the gradient of the GIBBS kernel's diagonal wrt parameters.
% GIBBSKERNGRADX Gradient of GIBBS kernel with respect to a point x.
% GIBBSKERNEXPANDPARAM Create kernel structure from GIBBS kernel's parameters.
% GIBBSKERNDIAGGRADX Gradient of GIBBS kernel's diagonal with respect to X.
% GIBBSKERNDISPLAY Display parameters of the GIBBS kernel.
% GIBBSKERNCOMPUTE Compute the GIBBS kernel given the parameters and X.
% GIBBSKERNSETLENGTHSCALEFUNC Set the length scale function of the GIBBS kernel.
