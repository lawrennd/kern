function kern = tensorKernSetIndex(kern, component, indices)

% TENSORKERNSETINDEX Set the indices in the tensor kernel.
%
%	Description:
%	kern = tensorKernSetIndex(kern, component, indices)
%% 	tensorKernSetIndex.m version 1.1


kern = cmpndKernSetIndex(kern, component, indices);