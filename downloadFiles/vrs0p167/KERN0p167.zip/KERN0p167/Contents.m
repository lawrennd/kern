% KERN toolbox
% Version 0.167		22-May-2007
% Copyright (c) 2007 Neil D. Lawrence
% 
% SIMXRBFKERNCOMPUTE Compute a cross kernel between the SIM and RBF kernels.
% ARDKERNDIAGGRADX Gradient of ARD kernel's diagonal with respect to X.
% KERNDIAGCOMPUTE Compute the kernel given the parameters and X.
% TRANSLATEKERNGRADIENT Gradient of TRANSLATE kernel's parameters.
% LINKERNEXPANDPARAM Create kernel structure from LIN kernel's parameters.
% LINKERNDIAGGRADX Gradient of LIN kernel's diagonal with respect to X.
% RBFPERIODICKERNPARAMINIT RBFPERIODIC kernel parameter initialisation.
% POLYARDKERNEXTRACTPARAM Extract parameters from the POLYARD kernel structure.
% WHITEFIXEDKERNCOMPUTE Compute the WHITEFIXED kernel given the parameters and X.
% MATERN32KERNDIAGGRADIENT Compute the gradient of the MATERN32 kernel's diagonal wrt parameters.
% BIASKERNDISPLAY Display parameters of the BIASkernel.
% POLYKERNEXTRACTPARAM Extract parameters from the POLY kernel structure.
% KERNREADPARAMSFROMFID Read the kernel parameters from C++ file FID.
% POLYKERNDISPLAY Display parameters of the POLY kernel.
% KERNCOMPUTE Compute the kernel given the parameters and X.
% MATERN32KERNGRADX Gradient of MATERN32 kernel with respect to input locations.
% EXPKERNEXPANDPARAM Create kernel structure from EXP kernel's parameters.
% KERNCREATE Initialise a kernel structure.
% RBFPERIODICKERNEXTRACTPARAM Extract parameters from the RBFPERIODIC kernel structure.
% MATERN52KERNDISPLAY Display parameters of the MATERN52 kernel.
% RBFKERNEXTRACTPARAM Extract parameters from the RBF kernel structure.
% SIMKERNGRADX Gradient of SIM kernel with respect to a point x.
% LINARDKERNGRADX Gradient of LINARD kernel with respect to input locations.
% SIMXSIMKERNCOMPUTE Compute a cross kernel between two SIM kernels.
% ARDKERNDIAGCOMPUTE Compute diagonal of ARD kernel.
% LINKERNPARAMINIT LIN kernel parameter initialisation.
% KERNEXTRACTPARAM Extract parameters from kernel structure.
% WHITEKERNEXTRACTPARAM Extract parameters from the WHITE kernel structure.
% RBFARDKERNDIAGCOMPUTE Compute diagonal of RBFARD kernel.
% EXPKERNDISPLAY Display parameters of the EXP kernel.
% RATQUADKERNEXPANDPARAM Create kernel structure from RATQUAD kernel's parameters.
% POLYARDKERNGRADX Gradient of POLYARD kernel with respect to input locations.
% FILEKERNGRADX Gradient of FILE kernel with respect to a point x.
% MLPKERNDISPLAY Display parameters of the MLP kernel.
% GIBBSKERNDIAGGRADX Gradient of GIBBS kernel's diagonal with respect to X.
% POLYARDKERNEXPANDPARAM Create kernel structure from POLYARD kernel's parameters.
% GIBBSKERNDIAGGRADIENT Compute the gradient of the GIBBS kernel's diagonal wrt parameters.
% RBFKERNPARAMINIT RBF kernel parameter initialisation.
% POLYARDKERNPARAMINIT POLYARD kernel parameter initialisation.
% FILEKERNGRADIENT Gradient of FILE kernel's parameters.
% MATERN52KERNDIAGGRADIENT Compute the gradient of the MATERN52 kernel's diagonal wrt parameters.
% MULTIKERNEXPANDPARAM Create kernel structure from MULTI kernel's parameters.
% TENSORKERNEXTRACTPARAM Extract parameters from the TENSOR kernel structure.
% RBFPERIODICKERNEXPANDPARAM Create kernel structure from RBFPERIODIC kernel's parameters.
% BIASKERNDIAGCOMPUTE Compute diagonal of BIAS kernel.
% TENSORKERNSETINDEX Set the indices in the tensor kernel.
% MATERN32KERNDISPLAY Display parameters of the MATERN32 kernel.
% RBFARDKERNCOMPUTE Compute the RBFARD kernel given the parameters and X.
% RATQUADKERNGRADX Gradient of RATQUAD kernel with respect to input locations.
% TENSORKERNEXPANDPARAM Create kernel structure from TENSOR kernel's parameters.
% LINKERNDIAGCOMPUTE Compute diagonal of LIN kernel.
% CMPNDKERNDIAGGRADX Gradient of CMPND kernel's diagonal with respect to X.
% SIMKERNEXTRACTPARAM Extract parameters from the SIM kernel structure.
% LINKERNGRADX Gradient of LIN kernel with respect to input locations.
% MULTIKERNDISPLAY Display parameters of the MULTI kernel.
% MLPARDKERNCOMPUTE Compute the MLPARD kernel given the parameters and X.
% MATERN52KERNEXPANDPARAM Create kernel structure from MATERN52 kernel's parameters.
% POLYKERNCOMPUTE Compute the POLY kernel given the parameters and X.
% GIBBSKERNGRADX Gradient of GIBBS kernel with respect to input locations.
% POLYARDKERNCOMPUTE Compute the POLYARD kernel given the parameters and X.
% BIASKERNEXPANDPARAM Create kernel structure from BIAS kernel's parameters.
% SIMKERNCOMPUTE Compute the SIM kernel given the parameters and X.
% BIASKERNCOMPUTE Compute the BIAS kernel given the parameters and X.
% EXPKERNGRADIENT Gradient of EXP kernel's parameters.
% MLPARDKERNGRADIENT Gradient of MLPARD kernel's parameters.
% KERNGETVARIANCE Get the signal associated with a the kernel.
% EXPKERNPARAMINIT EXP kernel parameter initialisation.
% WHITEKERNGRADIENT Gradient of WHITE kernel's parameters.
% MATERN52KERNPARAMINIT MATERN52 kernel parameter initialisation.
% KERNDIAGGRADX Compute the gradient of the  kernel wrt X.
% RBFPERIODICKERNGRADIENT Gradient of RBFPERIODIC kernel's parameters.
% MLPARDKERNDIAGCOMPUTE Compute diagonal of MLPARD kernel.
% BIASKERNGRADX Gradient of BIAS kernel with respect to input locations.
% SIMKERNDIAGGRADIENT Compute the gradient of the SIM kernel's diagonal wrt parameters.
% WHITEKERNEXPANDPARAM Create kernel structure from WHITE kernel's parameters.
% LINKERNCOMPUTE Compute the LIN kernel given the parameters and X.
% GIBBSPERIODICKERNGRADIENT Gradient of GIBBSPERIODIC kernel's parameters.
% RBFKERNDISPLAY Display parameters of the RBF kernel.
% KERNDIAGGRADIENT Compute the gradient of the kernel's parameters for the diagonal.
% TENSORKERNGRADX Gradient of TENSOR kernel with respect to a point x.
% MLPKERNCOMPUTE Compute the MLP kernel given the parameters and X.
% MATERN52KERNDIAGCOMPUTE Compute diagonal of MATERN52 kernel.
% EXPKERNCOMPUTE Compute the EXP kernel given the parameters and X.
% RBFKERNGRADX Gradient of RBF kernel with respect to input locations.
% SQEXPKERNDIAGGRADX Gradient of SQEXP kernel's diagonal with respect to X.
% MATERN32KERNEXPANDPARAM Create kernel structure from MATERN32 kernel's parameters.
% MULTIKERNDIAGCOMPUTE Compute diagonal of MULTI kernel.
% WHITEKERNPARAMINIT WHITE kernel parameter initialisation.
% RATQUADKERNDIAGGRADX Gradient of RATQUAD kernel's diagonal with respect to X.
% POLYARDKERNDISPLAY Display parameters of the POLYARD kernel.
% GIBBSPERIODICKERNPARAMINIT GIBBSPERIODIC kernel parameter initialisation.
% TENSORKERNPARAMINIT TENSOR kernel parameter initialisation.
% GIBBSKERNEXPANDPARAM Create kernel structure from GIBBS kernel's parameters.
% TENSORKERNSLASH Tensor kernel created by removing ith component.
% BIASKERNEXTRACTPARAM Extract parameters from the BIAS kernel structure.
% SIMKERNEXPANDPARAM Create kernel structure from SIM kernel's parameters.
% EXPKERNGRADX Gradient of EXP kernel with respect to a point x.
% SIMKERNPARAMINIT SIM kernel parameter initialisation.
% RBFARDKERNGRADX Gradient of RBFARD kernel with respect to input locations.
% SQEXPKERNCOMPUTE Compute the SQEXP kernel given the parameters and X.
% WHITEFIXEDKERNGRADX Gradient of WHITEFIXED kernel with respect to a point x.
% MLPKERNDIAGCOMPUTE Compute diagonal of MLP kernel.
% MLPKERNPARAMINIT MLP kernel parameter initialisation.
% RBFKERNEXPANDPARAM Create kernel structure from RBF kernel's parameters.
% MLPKERNGRADIENT Gradient of MLP kernel's parameters.
% TRANSLATEKERNDISPLAY Display parameters of the TRANSLATE kernel.
% RBFPERIODICKERNGRADX Gradient of RBFPERIODIC kernel with respect to a point x.
% RBFPERIODICKERNDISPLAY Display parameters of the RBFPERIODIC kernel.
% RATQUADKERNDISPLAY Display parameters of the RATQUAD kernel.
% GIBBSPERIODICKERNEXPANDPARAM Create kernel structure from GIBBSPERIODIC kernel's parameters.
% GIBBSKERNDISPLAY Display parameters of the GIBBS kernel.
% SQEXPKERNGRADIENT Gradient of SQEXP kernel's parameters.
% MULTIKERNGRADIENT Gradient of MULTI kernel's parameters.
% KERNDISPLAY Display the parameters of the kernel.
% CMPNDKERNDIAGGRADIENT Compute the gradient of the CMPND kernel's diagonal wrt parameters.
% MULTIKERNGRADX Gradient of MULTI kernel with respect to a point x.
% KERNPRIORLOGPROB Compute penalty terms associated with kernel priors.
% WHITEXWHITEKERNCOMPUTE Compute a cross kernel between two WHITE kernels.
% KERNSETWHITE Helper function to set the white noise in a kernel if it exists.
% CMPNDKERNDISPLAY Display parameters of the CMPND kernel.
% RBFKERNCOMPUTE Compute the RBF kernel given the parameters and X.
% KERNPCA performs KPCA.
% ARDKERNPARAMINIT ARD kernel parameter initialisation.
% ARDKERNEXTRACTPARAM Extract parameters from the ARD kernel structure.
% WHITEKERNCOMPUTE Compute the WHITE kernel given the parameters and X.
% MATERN52KERNGRADIENT Gradient of MATERN52 kernel's parameters.
% ARDKERNCOMPUTE Compute the ARD kernel given the parameters and X.
% WHITEKERNDIAGCOMPUTE Compute diagonal of WHITE kernel.
% LINARDKERNPARAMINIT LINARD kernel parameter initialisation.
% RATQUADKERNGRADIENT Gradient of RATQUAD kernel's parameters.
% PSKERNELOBJECTIVE Likelihood approximation for point set IVM.
% KERNPRIORGRADIENT Compute gradient terms associated with kernel priors.
% KERNPARAMINIT Kernel parameter initialisation.
% POLYARDKERNDIAGCOMPUTE Compute diagonal of POLYARD kernel.
% SQEXPKERNGRADX Gradient of SQEXP kernel with respect to a point x.
% FILEKERNDIAGCOMPUTE Compute diagonal of FILE kernel.
% WHITEKERNGRADX Gradient of WHITE kernel with respect to input locations.
% POLYARDKERNDIAGGRADX Gradient of POLYARD kernel's diagonal with respect to X.
% MLPKERNEXTRACTPARAM Extract parameters from the MLP kernel structure.
% POLYKERNPARAMINIT POLY kernel parameter initialisation.
% KERNREADFROMFID Load from an FID written by the C++ implementation.
% GIBBSKERNEXTRACTPARAM Extract parameters from the GIBBS kernel structure.
% WHITEKERNDIAGGRADX Gradient of WHITE kernel's diagonal with respect to X.
% RBFKERNDIAGCOMPUTE Compute diagonal of RBF kernel.
% WHITEFIXEDKERNDIAGCOMPUTE Compute diagonal of WHITEFIXED kernel.
% RATQUADKERNPARAMINIT RATQUAD kernel parameter initialisation.
% RBFKERNGRADIENT Gradient of RBF kernel's parameters.
% MULTIKERNDIAGGRADIENT Compute the gradient of the MULTI kernel's diagonal wrt parameters.
% SIMKERNDISPLAY Display parameters of the SIM kernel.
% POLYKERNEXPANDPARAM Create kernel structure from POLY kernel's parameters.
% TRANSLATEKERNCOMPUTE Compute the TRANSLATE kernel given the parameters and X.
% KERNSETINDEX Set the indices on a compound kernel.
% KERNEXPANDPARAM Expand parameters to form a kernel structure.
% MATERN32KERNDIAGCOMPUTE Compute diagonal of MATERN32 kernel.
% COMPUTEKERNEL Compute the kernel given the parameters and X.
% SIMKERNGRADIENT Gradient of SIM kernel's parameters.
% SQEXPKERNDIAGGRADIENT Compute the gradient of the SQEXP kernel's diagonal wrt parameters.
% MATERN52KERNDIAGGRADX Gradient of MATERN52 kernel's diagonal with respect to X.
% GIBBSKERNGRADIENT Gradient of GIBBS kernel's parameters.
% SQEXPKERNEXTRACTPARAM Extract parameters from the SQEXP kernel structure.
% GIBBSPERIODICKERNEXTRACTPARAM Extract parameters from the GIBBSPERIODIC kernel structure.
% MATERN32KERNDIAGGRADX Gradient of MATERN32 kernel's diagonal with respect to X.
% SIMXSIMKERNGRADIENT Compute a cross gradient between two SIM kernels.
% FILEKERNEXTRACTPARAM Extract parameters from the FILE kernel structure.
% BIASKERNDIAGGRADX Gradient of BIAS kernel's diagonal with respect to X.
% KERNTEST Run some tests on the specified kernel.
% SQEXPKERNDISPLAY Display parameters of the SQEXP kernel.
% LINARDKERNCOMPUTE Compute the LINARD kernel given the parameters and X.
% SIMKERNDIAGCOMPUTE Compute diagonal of SIM kernel.
% GIBBSKERNDIAGCOMPUTE Compute diagonal of GIBBS kernel.
% PSKERNELGRADIENT Gradient on likelihood approximation for point set IVM.
% GIBBSPERIODICKERNDISPLAY Display parameters of the GIBBSPERIODIC kernel.
% WHITEXWHITEKERNGRADIENT Compute a cross gradient between two WHITE kernels.
% RBFARDKERNPARAMINIT RBFARD kernel parameter initialisation.
% SIMCOMPUTETEST Test the file simComputeH.
% MATERN32KERNGRADIENT Gradient of MATERN32 kernel's parameters.
% LINARDKERNGRADIENT Gradient of LINARD kernel's parameters.
% WHITEFIXEDKERNPARAMINIT WHITEFIXED kernel parameter initialisation.
% MLPKERNDIAGGRADX Gradient of MLP kernel's diagonal with respect to X.
% TENSORKERNCOMPUTE Compute the TENSOR kernel given the parameters and X.
% WHITEFIXEDKERNEXPANDPARAM Create kernel structure from WHITEFIXED kernel's parameters.
% TRANSLATEKERNGRADX Gradient of TRANSLATE kernel with respect to a point x.
% LINKERNGRADIENT Gradient of LIN kernel's parameters.
% GIBBSPERIODICKERNCOMPUTE Compute the GIBBSPERIODIC kernel given the parameters and X.
% MLPKERNEXPANDPARAM Create kernel structure from MLP kernel's parameters.
% CMPNDKERNCOMPUTE Compute the CMPND kernel given the parameters and X.
% TRANSLATEKERNEXPANDPARAM Create kernel structure from TRANSLATE kernel's parameters.
% MULTIKERNCOMPUTE Compute the MULTI kernel given the parameters and X.
% TRANSLATEKERNEXTRACTPARAM Extract parameters from the TRANSLATE kernel structure.
% KERNFACTORS Extract factors associated with transformed optimisation space.
% POLYKERNDIAGGRADX Gradient of POLY kernel's diagonal with respect to X.
% RBFARDKERNGRADIENT Gradient of RBFARD kernel's parameters.
% WHITEFIXEDKERNDISPLAY Display parameters of the WHITEFIXED kernel.
% BIASKERNPARAMINIT BIAS kernel parameter initialisation.
% SIMKERNDIAGGRADX Gradient of SIM kernel's diagonal with respect to X.
% CMPNDKERNEXTRACTPARAM Extract parameters from the CMPND kernel structure.
% FILEKERNDISPLAY Display parameters of the FILE kernel.
% LINARDKERNDIAGCOMPUTE Compute diagonal of LINARD kernel.
% MLPARDKERNDISPLAY Display parameters of the MLPARD kernel.
% MULTIKERNDIAGGRADX Gradient of MULTI kernel's diagonal with respect to X.
% LINARDKERNEXTRACTPARAM Extract parameters from the LINARD kernel structure.
% WHITEKERNDISPLAY Display parameters of the WHITEkernel.
% TRANSLATEKERNPARAMINIT TRANSLATE kernel parameter initialisation.
% WHITEFIXEDKERNDIAGGRADIENT Compute the gradient of the WHITEFIXED kernel's diagonal wrt parameters.
% MULTIKERNGRADIENTBLOCK
% KERNTOOLBOXES Load in the relevant toolboxes for kern.
% RBFARDKERNEXTRACTPARAM Extract parameters from the RBFARD kernel structure.
% TENSORKERNDIAGGRADX Gradient of TENSOR kernel's diagonal with respect to X.
% WHITEKERNDIAGGRADIENT Compute the gradient of the WHITE kernel's diagonal wrt parameters.
% GIBBSPERIODICKERNDIAGCOMPUTE Compute diagonal of GIBBSPERIODIC kernel.
% LINKERNEXTRACTPARAM Extract parameters from the LIN kernel structure.
% LINARDKERNDIAGGRADX Gradient of LINARD kernel's diagonal with respect to X.
% GIBBSKERNSETLENGTHSCALEFUNC Set the length scale function of the GIBBS kernel.
% TENSORKERNDIAGCOMPUTE Compute diagonal of TENSOR kernel.
% MLPARDKERNPARAMINIT MLPARD kernel parameter initialisation.
% WHITEFIXEDKERNDIAGGRADX Gradient of WHITEFIXED kernel's diagonal with respect to X.
% MATERN32KERNPARAMINIT MATERN32 kernel parameter initialisation.
% RATQUADKERNCOMPUTE Compute the RATQUAD kernel given the parameters and X.
% RBFKERNDIAGGRADX Gradient of RBF kernel's diagonal with respect to X.
% RBFPERIODICKERNDIAGGRADX Gradient of RBFPERIODIC kernel's diagonal with respect to X.
% RATQUADKERNEXTRACTPARAM Extract parameters from the RATQUAD kernel structure.
% RBFPERIODICKERNDIAGCOMPUTE Compute diagonal of RBFPERIODIC kernel.
% CMPNDKERNDIAGCOMPUTE Compute diagonal of CMPND kernel.
% POLYARDKERNGRADIENT Gradient of POLYARD kernel's parameters.
% WHITEFIXEDKERNEXTRACTPARAM Extract parameters from the WHITEFIXED kernel structure.
% MULTIKERNPARAMINIT MULTI kernel parameter initialisation.
% RATQUADKERNDIAGCOMPUTE Compute diagonal of RATQUAD kernel.
% GIBBSPERIODICKERNDIAGGRADIENT Compute the gradient of the GIBBSPERIODIC kernel's diagonal wrt parameters.
% TENSORKERNGRADIENT Gradient of TENSOR kernel's parameters.
% TRANSLATEKERNDIAGCOMPUTE Compute diagonal of TRANSLATE kernel.
% MLPKERNGRADX Gradient of MLP kernel with respect to input locations.
% SQEXPKERNEXPANDPARAM Create kernel structure from SQEXP kernel's parameters.
% CMPNDKERNGRADX Gradient of CMPND kernel with respect to a point x.
% GIBBSKERNPARAMINIT GIBBS kernel parameter initialisation.
% LINKERNDISPLAY Display parameters of the LIN kernel.
% FILEKERNREAD Read kernel values from file or cache.
% WHITEFIXEDKERNGRADIENT Gradient of WHITEFIXED kernel's parameters.
% BIASKERNDIAGGRADIENT Compute the gradient of the BIAS kernel's diagonal wrt parameters.
% ARDKERNDIAGGRADIENT Compute the gradient of the ARD kernel's diagonal wrt parameters.
% FILEKERNEXPANDPARAM Create kernel structure from FILE kernel's parameters.
% CMPNDKERNEXPANDPARAM Create kernel structure from CMPND kernel's parameters.
% MULTIKERNEXTRACTPARAM Extract parameters from the MULTI kernel structure.
% RBFPERIODICKERNCOMPUTE Compute the RBFPERIODIC kernel given the parameters and X.
% RATQUADKERNDIAGGRADIENT Compute the gradient of the RATQUAD kernel's diagonal wrt parameters.
% CMPNDKERNPARAMINIT CMPND kernel parameter initialisation.
% MULTIKERNTEST Run some tests on the multiple output block kernel.
% RBFARDKERNEXPANDPARAM Create kernel structure from RBFARD kernel's parameters.
% TENSORKERNDISPLAY Display parameters of the TENSOR kernel.
% MULTIKERNCOMPUTEBLOCK
% POLYKERNDIAGCOMPUTE Compute diagonal of POLY kernel.
% SQEXPKERNDIAGCOMPUTE Compute diagonal of SQEXP kernel.
% GIBBSPERIODICKERNDIAGGRADX Gradient of GIBBSPERIODIC kernel's diagonal with respect to X.
% KERNGRADX Compute the gradient of the kernel wrt X.
% RBFARDKERNDIAGGRADX Gradient of RBFARD kernel's diagonal with respect to X.
% LINARDKERNDISPLAY Display parameters of the LINARD kernel.
% KERNGRADIENT Compute the gradient wrt the kernel's parameters.
% SIMXRBFKERNGRADIENT Compute gradient between the SIM and RBF kernels.
% RBFPERIODICKERNDIAGGRADIENT Compute the gradient of the RBFPERIODIC kernel's diagonal wrt parameters.
% MLPARDKERNDIAGGRADX Gradient of MLPARD kernel's diagonal with respect to X.
% TRANSLATEKERNDIAGGRADX Gradient of TRANSLATE kernel's diagonal with respect to X.
% EXPKERNDIAGGRADX Gradient of EXP kernel's diagonal with respect to X.
% MATERN52KERNEXTRACTPARAM Extract parameters from the MATERN52 kernel structure.
% RBFARDKERNDISPLAY Display parameters of the RBFARD kernel.
% CMPNDKERNGRADIENT Gradient of CMPND kernel's parameters.
% GIBBSKERNCOMPUTE Compute the GIBBS kernel given the parameters and X.
% MATERN32KERNEXTRACTPARAM Extract parameters from the MATERN32 kernel structure.
% FILEKERNCOMPUTE Compute the FILE kernel given the parameters and X.
% ARDKERNGRADIENT Gradient of ARD kernel's parameters.
% RBFARDKERNDIAGGRADIENT Compute the gradient of the RBFARD kernel's diagonal wrt parameters.
% MLPARDKERNEXTRACTPARAM Extract parameters from the MLPARD kernel structure.
% SIMCOMPUTEH Helper function for comptuing part of the SIM kernel.
% POLYKERNGRADIENT Gradient of POLY kernel's parameters.
% MATERN32KERNCOMPUTE Compute the MATERN32 kernel given the parameters and X.
% POLYKERNGRADX Gradient of POLY kernel with respect to input locations.
% RBFKERNDIAGGRADIENT Compute the gradient of the RBF kernel's diagonal wrt parameters.
% SQEXPKERNPARAMINIT SQEXP kernel parameter initialisation.
% CMPNDKERNSETINDEX Set the indices in the compound kernel.
% FILEKERNPARAMINIT FILE kernel parameter initialisation.
% EXPKERNEXTRACTPARAM Extract parameters from the EXP kernel structure.
% MLPARDKERNEXPANDPARAM Create kernel structure from MLPARD kernel's parameters.
% TENSORKERNDIAGGRADIENT Compute the gradient of the TENSOR kernel's diagonal wrt parameters.
% EXPKERNDIAGCOMPUTE Compute diagonal of EXP kernel.
% BIASKERNGRADIENT Gradient of BIAS kernel's parameters.
% ARDKERNGRADX Gradient of ARD kernel with respect to a point x.
% MATERN52KERNGRADX Gradient of MATERN52 kernel with respect to input locations.
% CMPNDKERNREADPARAMSFROMFID Read a compound kernel from a C++ file.
% GIBBSPERIODICKERNGRADX Gradient of GIBBSPERIODIC kernel with respect to a point x.
% ARDKERNEXPANDPARAM Create kernel structure from ARD kernel's parameters.
% ARDKERNDISPLAY Display parameters of the ARD kernel.
% LINARDKERNEXPANDPARAM Create kernel structure from LINARD kernel's parameters.
% MLPARDKERNGRADX Gradient of MLPARD kernel with respect to input locations.
% MATERN52KERNCOMPUTE Compute the MATERN52 kernel given the parameters and X.
