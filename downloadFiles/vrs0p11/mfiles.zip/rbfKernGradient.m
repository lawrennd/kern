function g = rbfKernGradient(kern, x, covGrad)

% RBFKERNGRADIENT Gradient of rbf kernel's parameters.
%
% g = rbfKernGradient(kern, x, covGrad)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 14:29:05 2004
% KERN toolbox version 0.11





[k, dist2xx] = rbfKernCompute(kern, x);
g(1) = - .5*sum(sum(covGrad.*k.*dist2xx));
g(2) =  sum(sum(covGrad.*k))/kern.variance;

