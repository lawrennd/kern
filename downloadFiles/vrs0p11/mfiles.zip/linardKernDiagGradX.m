function gX = linardKernDiagGradX(kern, x)

% LINARDKERNDIAGGRADX Gradient of linear ARD kernel's diagonal with respect to a point x.
%
% gX = linardKernDiagGradX(kern, x)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 14:29:05 2004
% KERN toolbox version 0.11






gX = 2*kern.variance*x.*kern.inputScales;
