function L = kernPriorLogProb(kern)

% KERNPRIORLOGPROB Compute penalty terms associated with kernel priors.
%
% L = kernPriorLogProb(kern)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Sat Jun 12 14:29:05 2004
% KERN toolbox version 0.11





L = 0;
switch kern.type
 case 'cmpnd'
  for i = 1:length(kern.comp)
    L = L + kernPriorLogProb(kern.comp{i});
  end
 otherwise
  if isfield(kern, 'priors')
    params = feval([kern.type 'KernExtractParam'], kern);
    for i = 1:length(kern.priors)
      index = kern.priors(i).index;
      L = L + priorLogProb(kern.priors(i), params(index));
    end
  end
end