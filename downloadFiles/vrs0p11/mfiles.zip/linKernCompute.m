function k = linKernCompute(kern, x, x2)

% LINKERNCOMPUTE Compute the kernel given the parameters and X.
%
% k = linKernCompute(kern, x, x2)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 14:29:05 2004
% KERN toolbox version 0.11





if nargin < 3
  k = x*x'*kern.variance;
else
  k = x*x2'*kern.variance;
end
if issparse(x)
  k = full(k);
end