function gX = linardKernGradX(kern, x, X2)

% LINARDKERNGRADX Gradient of linear ARD kernel with respect to a point x.
%
% gX = linardKernGradX(kern, x, X2)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 14:29:05 2004
% KERN toolbox version 0.11





scales = sparse(diag(kern.inputScales));
X2 = X2*scales;

gX = kern.variance.*X2;