function rbfKernDisplay(kern)

% RBFKERNDISPLAY Display parameters of radial basis function kernel.
%
% rbfKernDisplay(kern)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 14:29:05 2004
% KERN toolbox version 0.11





fprintf('RBF Variance: %2.4f\n', kern.variance)
fprintf('RBF inverse width: %2.4f\n', kern.inverseWidth)
