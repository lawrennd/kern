function k = linKernDiagCompute(kern, x)

% LINKERNDIAGCOMPUTE Compute diagonal of linear kernel.
%
% k = linKernDiagCompute(kern, x)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.3, Mon Jun 14 13:19:15 2004
% KERN toolbox version 0.11



k =  sum(x.*x, 2)*kern.variance;
