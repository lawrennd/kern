function gX = cmpndKernGradX(kern, x, X2)

% CMPNDKERNGRADX Gradient of compound kernel with respect to a point x.
%
% gX = cmpndKernGradX(kern, x, X2)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 14:29:05 2004
% KERN toolbox version 0.11





gX = kernGradX(kern.comp{1}, x, X2);
for i = 2:length(kern.comp)
  gX = gX + kernGradX(kern.comp{i}, x, X2);
end
