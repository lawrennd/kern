function gX = whiteKernGradX(kern, x, X2)

% WHITEKERNGRADX Gradient of white noise kernel with respect to a point x.
%
% gX = whiteKernGradX(kern, x, X2)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 14:29:05 2004
% KERN toolbox version 0.11





gX = zeros(size(X2));