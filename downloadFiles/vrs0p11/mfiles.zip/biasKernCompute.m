function k = biasKernCompute(kern, x, x2)

% BIASKERNCOMPUTE Compute the bias kernel given the parameters and X.
%
% k = biasKernCompute(kern, x, x2)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 14:29:05 2004
% KERN toolbox version 0.11





if nargin< 3
  k = repmat(kern.variance, size(x, 1), size(x, 1));
else
  k = repmat(kern.variance, size(x, 1), size(x2, 1));
end