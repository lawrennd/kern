function k = rbfardKernDiagCompute(kern, x)

% RBFARDKERNDIAGCOMPUTE Compute diagonal of radial basis function ARD kernel.
%
% k = rbfardKernDiagCompute(kern, x)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.3, Mon Jun 14 13:21:46 2004
% KERN toolbox version 0.11



k = repmat(kern.variance, size(x, 1), 1);
