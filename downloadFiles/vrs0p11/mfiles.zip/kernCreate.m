function kern = kernCreate(X, kernelType)

% KERNCREATE Initialise a kernel structure.
%
% kern = kernCreate(X, kernelType)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 14:29:05 2004
% KERN toolbox version 0.11





kern.Kstore = [];
kern.diagK = [];
if iscell(kernelType)
  % compound kernel type
  kern.type = 'cmpnd';
  for i = 1:length(kernelType)
    kern.comp{i}.type = kernelType{i};
    kern.comp{i}.inputDimension = size(X, 2);
  end
else
  kern.type = kernelType;
  kern.inputDimension = size(X, 2);
end
kern = kernParamInit(kern);
