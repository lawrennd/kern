% KERN toolbox
% Version 0.11 Thursday, June 17, 2004 at 15:43:09
% Copyright (c) 2004 Neil D. Lawrence
% $Revision: 1.3 1.0 $
% 
% ARDKERNCOMPUTE Compute the kernel given the parameters and X.
% ARDKERNDIAGCOMPUTE Compute diagonal of ard kernel.
% ARDKERNDIAGGRADX Gradient of ARD kernel's diagonal with respect to a point x.
% ARDKERNDISPLAY Display parameters of ARD kernel.
% ARDKERNEXPANDPARAM Create kernel structure from ARD parameters.
% ARDKERNEXTRACTPARAM Extract parameters from ard kernel structure.
% ARDKERNGRADX Gradient of ARD kernel with respect to a point x.
% ARDKERNGRADIENT Gradient of ard kernel's parameters.
% ARDKERNPARAMINIT ARD kernel parameter initialisation.
% BIASKERNCOMPUTE Compute the bias kernel given the parameters and X.
% BIASKERNDIAGCOMPUTE Compute diagonal of bias kernel.
% BIASKERNDIAGGRADX Gradient of bias kernel's diagonal with respect to a point x.
% BIASKERNDISPLAY Display parameters of bias kernel.
% BIASKERNEXPANDPARAM Create kernel structure from bias's parameters.
% BIASKERNEXTRACTPARAM Extract parameters from bias kernel structure.
% BIASKERNGRADX Gradient of bias kernel with respect to a point x.
% BIASKERNGRADIENT Gradient of bias kernel's parameters.
% BIASKERNPARAMINIT bias kernel parameter initialisation.
% CMPNDKERNCOMPUTE Compute the kernel given the parameters and X.
% CMPNDKERNDIAGCOMPUTE Compute diagonal of compound kernel.
% CMPNDKERNDIAGGRADX Gradient of compound kernel's diagonal with respect to a point x.
% CMPNDKERNDISPLAY Display the parameters of the compound kernel.
% CMPNDKERNEXPANDPARAM Create kernel structure from ARD parameters.
% CMPNDKERNEXTRACTPARAM Extract parameters from compound kernel structure.
% CMPNDKERNGRADX Gradient of compound kernel with respect to a point x.
% CMPNDKERNGRADIENT Gradient of compound kernel's parameters.
% CMPNDKERNPARAMINIT Compound kernel parameter initialisation.
% COMPUTEKERNEL Compute the kernel given the parameters and X.
% KERNCOMPUTE Compute the kernel given the parameters and X.
% KERNCREATE Initialise a kernel structure.
% KERNELCOMPUTE Compute the kernel given the parameters and X.
% KERNDIAGGRADX Compute the gradient of the  kernel wrt X.
% KERNDISPLAY Display the parameters of the kernel.
% KERNEXPANDPARAM Expand parameters to form a kernel structure.
% KERNEXTRACTPARAM Extract parameters from kernel structure.
% KERNGRADX Compute the gradient of the  kernel wrt X.
% KERNGRADIENT Compute the gradient of the kernel's parameters.
% KERNPARAMINIT Kernel parameter initialisation.
% KERNPRIORGRADIENT Compute gradient terms associated with kernel priors.
% KERNPRIORLOGPROB Compute penalty terms associated with kernel priors.
% KERNTEST Run some tests on the specified kernel.
% KERNEL Initialise a kernel structure.
% KERNELGRADIENT Gradient of likelihood approximation wrt kernel parameters.
% KERNELOBJECTIVE Likelihood approximation.
% LINKERNCOMPUTE Compute the kernel given the parameters and X.
% LINKERNDIAGCOMPUTE Compute diagonal of linear kernel.
% LINKERNDIAGGRADX Gradient of linear kernel's diagonal with respect to a point x.
% LINKERNDISPLAY Display parameters of linear kernel.
% LINKERNEXPANDPARAM Create kernel structure from linear kernel parameters.
% LINKERNEXTRACTPARAM Extract parameters from linear kernel structure.
% LINKERNGRADX Gradient of linear kernel with respect to a point X.
% LINKERNGRADIENT Gradient of lin kernel's parameters.
% LINKERNPARAMINIT Linear kernel parameter initialisation.
% LINARDKERNCOMPUTE Compute the linear ARD kernel given the parameters and X.
% LINARDKERNDIAGCOMPUTE Compute diagonal of linear ARD kernel.
% LINARDKERNDIAGGRADX Gradient of linear ARD kernel's diagonal with respect to a point x.
% LINARDKERNDISPLAY Display parameters of linear ARD kernel.
% LINARDKERNEXPANDPARAM Create kernel structure from linear ARD's parameters.
% LINARDKERNEXTRACTPARAM Extract parameters from linear ARD kernel structure.
% LINARDKERNGRADX Gradient of linear ARD kernel with respect to a point x.
% LINARDKERNGRADIENT Gradient of linear ARD kernel's parameters.
% LINARDKERNPARAMINIT linear ARD kernel parameter initialisation.
% LINEARKERNPARAMINIT Linear kernel parameter initialisation.
% MLPKERNCOMPUTE Compute the multi-layer perceptron kernel given the parameters and X.
% MLPKERNDIAGCOMPUTE Compute diagonal of multi-layer perceptron kernel.
% MLPKERNDIAGGRADX Gradient of  multi-layer perceptron kernel's diagonal with respect to a point x.
% MLPKERNDISPLAY Display parameters of multi-layer perceptron kernel.
% MLPKERNEXPANDPARAM Create kernel structure from multi-layer perceptron's parameters.
% MLPKERNEXTRACTPARAM Extract parameters from multi-layer perceptron kernel structure.
% MLPKERNGRADX Gradient of multi-layer perceptron kernel with respect to a point X.
% MLPKERNGRADIENT Gradient of multi-layer perceptron kernel's parameters.
% MLPKERNPARAMINIT multi-layer perceptron kernel parameter initialisation.
% MLPARDKERNCOMPUTE Compute the multi-layer perceptron ARD kernel given the parameters and X.
% MLPARDKERNDIAGCOMPUTE Compute diagonal of multi-layer perceptron ARD kernel.
% MLPARDKERNDIAGGRADX Gradient of multi-layer perceptron ARD kernel's diagonal with respect to a point x.
% MLPARDKERNDISPLAY Display parameters of multi-layer perceptron ARD kernel.
% MLPARDKERNEXPANDPARAM Create kernel structure from multi-layer perceptron ARD's parameters.
% MLPARDKERNEXTRACTPARAM Extract parameters from multi-layer perceptron ARD kernel structure.
% MLPARDKERNGRADX Gradient of multi-layer perceptron ARD kernel with respect to a point x.
% MLPARDKERNGRADIENT Gradient of multi-layer perceptron ARD kernel's parameters.
% MLPARDKERNPARAMINIT multi-layer perceptron ARD kernel parameter initialisation.
% PSKERNELGRADIENT Gradient on likelihood approximation for point set IVM.
% PSKERNELOBJECTIVE Likelihood approximation for point set IVM.
% RBFKERNCOMPUTE Compute the kernel given the parameters and X.
% RBFKERNDIAGCOMPUTE Compute diagonal of rbf kernel.
% RBFKERNDIAGGRADX Gradient of Radial basis function kernel's diagonal with respect to a point x.
% RBFKERNDISPLAY Display parameters of radial basis function kernel.
% RBFKERNEXPANDPARAM Create kernel structure from rbf parameters.
% RBFKERNEXTRACTPARAM Extract parameters from rbf kernel structure.
% RBFKERNGRADX Gradient of Radial basis function kernel with respect to a point X.
% RBFKERNGRADIENT Gradient of rbf kernel's parameters.
% RBFKERNPARAMINIT RBF kernel parameter initialisation.
% RBFARDKERNCOMPUTE Compute the radial basis function ARD kernel given the parameters and X.
% RBFARDKERNDIAGCOMPUTE Compute diagonal of radial basis function ARD kernel.
% RBFARDKERNDIAGGRADX Gradient of radial basis function ARD kernel's diagonal with respect to a point x.
% RBFARDKERNDISPLAY Display parameters of radial basis function ARD kernel.
% RBFARDKERNEXPANDPARAM Create kernel structure from radial basis function ARD's parameters.
% RBFARDKERNEXTRACTPARAM Extract parameters from radial basis function ARD kernel structure.
% RBFARDKERNGRADX Gradient of radial basis function ARD kernel with respect to a point x.
% RBFARDKERNGRADIENT Gradient of radial basis function ARD kernel's parameters.
% RBFARDKERNPARAMINIT radial basis function ARD kernel parameter initialisation.
% SQEXPKERNCOMPUTE Compute the squared exponential kernel given the parameters and X.
% SQEXPKERNDIAGCOMPUTE Compute diagonal of squared exponential kernel.
% SQEXPKERNDIAGGRADX Gradient of squared exponential kernel's diagonal with respect to a point x.
% SQEXPKERNDISPLAY Display parameters of squared exponential kernel.
% SQEXPKERNEXPANDPARAM Create kernel structure from squared exponential's parameters.
% SQEXPKERNEXTRACTPARAM Extract parameters from squared exponential kernel structure.
% SQEXPKERNGRADX Gradient of squared exponential kernel with respect to a point X.
% SQEXPKERNGRADIENT Gradient of squared exponential kernel's parameters.
% SQEXPKERNPARAMINIT squared exponential kernel parameter initialisation.
% WHITEKERNCOMPUTE Compute the white noise kernel given the parameters and X.
% WHITEKERNDIAGCOMPUTE Compute diagonal of white noise kernel.
% WHITEKERNDIAGGRADX Gradient of white noise kernel's diagonal with respect to a point x.
% WHITEKERNDISPLAY Display parameters of white noise kernel.
% WHITEKERNEXPANDPARAM Create kernel structure from white noise's parameters.
% WHITEKERNEXTRACTPARAM Extract parameters from white noise kernel structure.
% WHITEKERNGRADX Gradient of white noise kernel with respect to a point x.
% WHITEKERNGRADIENT Gradient of white noise kernel's parameters.
% WHITEKERNPARAMINIT white noise kernel parameter initialisation.
