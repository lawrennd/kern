% KERN toolbox
% Version 0.166		04-Feb-2007
% Copyright (c) 2007 Neil D. Lawrence
% 
% ARDKERNCOMPUTE Compute the ARD kernel given the parameters and X.
% ARDKERNDIAGCOMPUTE Compute diagonal of ARD kernel.
% ARDKERNDIAGGRADIENT Compute the gradient of the ARD kernel's diagonal wrt parameters.
% ARDKERNDIAGGRADX Gradient of ARD kernel's diagonal with respect to X.
% ARDKERNDISPLAY Display parameters of the ARD kernel.
% ARDKERNEXPANDPARAM Create kernel structure from ARD kernel's parameters.
% ARDKERNEXTRACTPARAM Extract parameters from the ARD kernel structure.
% ARDKERNGRADIENT Gradient of ARD kernel's parameters.
% ARDKERNGRADX Gradient of ARD kernel with respect to a point x.
% ARDKERNPARAMINIT ARD kernel parameter initialisation.
% BIASKERNCOMPUTE Compute the BIAS kernel given the parameters and X.
% BIASKERNDIAGCOMPUTE Compute diagonal of BIAS kernel.
% BIASKERNDIAGGRADIENT Compute the gradient of the BIAS kernel's diagonal wrt parameters.
% BIASKERNDIAGGRADX Gradient of BIAS kernel's diagonal with respect to X.
% BIASKERNDISPLAY Display parameters of the BIASkernel.
% BIASKERNEXPANDPARAM Create kernel structure from BIAS kernel's parameters.
% BIASKERNEXTRACTPARAM Extract parameters from the BIAS kernel structure.
% BIASKERNGRADIENT Gradient of BIAS kernel's parameters.
% BIASKERNGRADX Gradient of BIAS kernel with respect to input locations.
% BIASKERNPARAMINIT BIAS kernel parameter initialisation.
% CMPNDKERNCOMPUTE Compute the CMPND kernel given the parameters and X.
% CMPNDKERNDIAGCOMPUTE Compute diagonal of CMPND kernel.
% CMPNDKERNDIAGGRADIENT Compute the gradient of the CMPND kernel's diagonal wrt parameters.
% CMPNDKERNDIAGGRADX Gradient of CMPND kernel's diagonal with respect to X.
% CMPNDKERNDISPLAY Display parameters of the CMPND kernel.
% CMPNDKERNEXPANDPARAM Create kernel structure from CMPND kernel's parameters.
% CMPNDKERNEXTRACTPARAM Extract parameters from the CMPND kernel structure.
% CMPNDKERNGRADIENT Gradient of CMPND kernel's parameters.
% CMPNDKERNGRADX Gradient of CMPND kernel with respect to a point x.
% CMPNDKERNPARAMINIT CMPND kernel parameter initialisation.
% CMPNDKERNREADPARAMSFROMFID Read a compound kernel from a C++ file.
% CMPNDKERNSETINDEX Set the indices in the compound kernel.
% COMPUTEKERNEL Compute the kernel given the parameters and X.
% EXPKERNCOMPUTE Compute the EXP kernel given the parameters and X.
% EXPKERNDIAGCOMPUTE Compute diagonal of EXP kernel.
% EXPKERNDIAGGRADX Gradient of EXP kernel's diagonal with respect to X.
% EXPKERNDISPLAY Display parameters of the EXP kernel.
% EXPKERNEXPANDPARAM Create kernel structure from EXP kernel's parameters.
% EXPKERNEXTRACTPARAM Extract parameters from the EXP kernel structure.
% EXPKERNGRADIENT Gradient of EXP kernel's parameters.
% EXPKERNGRADX Gradient of EXP kernel with respect to a point x.
% EXPKERNPARAMINIT EXP kernel parameter initialisation.
% FILEKERNCOMPUTE Compute the FILE kernel given the parameters and X.
% FILEKERNDIAGCOMPUTE Compute diagonal of FILE kernel.
% FILEKERNDISPLAY Display parameters of the FILE kernel.
% FILEKERNEXPANDPARAM Create kernel structure from FILE kernel's parameters.
% FILEKERNEXTRACTPARAM Extract parameters from the FILE kernel structure.
% FILEKERNGRADIENT Gradient of FILE kernel's parameters.
% FILEKERNGRADX Gradient of FILE kernel with respect to a point x.
% FILEKERNPARAMINIT FILE kernel parameter initialisation.
% FILEKERNREAD Read kernel values from file or cache.
% GIBBSKERNCOMPUTE Compute the GIBBS kernel given the parameters and X.
% GIBBSKERNDIAGCOMPUTE Compute diagonal of GIBBS kernel.
% GIBBSKERNDIAGGRADIENT Compute the gradient of the GIBBS kernel's diagonal wrt parameters.
% GIBBSKERNDIAGGRADX Gradient of GIBBS kernel's diagonal with respect to X.
% GIBBSKERNDISPLAY Display parameters of the GIBBS kernel.
% GIBBSKERNEXPANDPARAM Create kernel structure from GIBBS kernel's parameters.
% GIBBSKERNEXTRACTPARAM Extract parameters from the GIBBS kernel structure.
% GIBBSKERNGRADIENT Gradient of GIBBS kernel's parameters.
% GIBBSKERNGRADX Gradient of GIBBS kernel with respect to input locations.
% GIBBSKERNPARAMINIT GIBBS kernel parameter initialisation.
% GIBBSKERNSETLENGTHSCALEFUNC Set the length scale function of the GIBBS kernel.
% GIBBSPERIODICKERNCOMPUTE Compute the GIBBSPERIODIC kernel given the parameters and X.
% GIBBSPERIODICKERNDIAGCOMPUTE Compute diagonal of GIBBSPERIODIC kernel.
% GIBBSPERIODICKERNDIAGGRADIENT Compute the gradient of the GIBBSPERIODIC kernel's diagonal wrt parameters.
% GIBBSPERIODICKERNDIAGGRADX Gradient of GIBBSPERIODIC kernel's diagonal with respect to X.
% GIBBSPERIODICKERNDISPLAY Display parameters of the GIBBSPERIODIC kernel.
% GIBBSPERIODICKERNEXPANDPARAM Create kernel structure from GIBBSPERIODIC kernel's parameters.
% GIBBSPERIODICKERNEXTRACTPARAM Extract parameters from the GIBBSPERIODIC kernel structure.
% GIBBSPERIODICKERNGRADIENT Gradient of GIBBSPERIODIC kernel's parameters.
% GIBBSPERIODICKERNGRADX Gradient of GIBBSPERIODIC kernel with respect to a point x.
% GIBBSPERIODICKERNPARAMINIT GIBBSPERIODIC kernel parameter initialisation.
% KERNCOMPUTE Compute the kernel given the parameters and X.
% KERNCREATE Initialise a kernel structure.
% KERNDIAGCOMPUTE Compute the kernel given the parameters and X.
% KERNDIAGGRADIENT Compute the gradient of the kernel's parameters for the diagonal.
% KERNDIAGGRADX Compute the gradient of the  kernel wrt X.
% KERNDISPLAY Display the parameters of the kernel.
% KERNEXPANDPARAM Expand parameters to form a kernel structure.
% KERNEXTRACTPARAM Extract parameters from kernel structure.
% KERNFACTORS Extract factors associated with transformed optimisation space.
% KERNGETVARIANCE Get the signal associated with a the kernel.
% KERNGRADIENT Compute the gradient wrt the kernel's parameters.
% KERNGRADX Compute the gradient of the kernel wrt X.
% KERNPARAMINIT Kernel parameter initialisation.
% KERNPCA performs KPCA.
% KERNPRIORGRADIENT Compute gradient terms associated with kernel priors.
% KERNPRIORLOGPROB Compute penalty terms associated with kernel priors.
% KERNREADFROMFID Load from an FID written by the C++ implementation.
% KERNREADPARAMSFROMFID Read the kernel parameters from C++ file FID.
% KERNSETINDEX Set the indices on a compound kernel.
% KERNSETWHITE Helper function to set the white noise in a kernel if it exists.
% KERNTEST Run some tests on the specified kernel.
% KERNTOOLBOXES Load in the relevant toolboxes for kern.
% LINARDKERNCOMPUTE Compute the LINARD kernel given the parameters and X.
% LINARDKERNDIAGCOMPUTE Compute diagonal of LINARD kernel.
% LINARDKERNDIAGGRADX Gradient of LINARD kernel's diagonal with respect to X.
% LINARDKERNDISPLAY Display parameters of the LINARD kernel.
% LINARDKERNEXPANDPARAM Create kernel structure from LINARD kernel's parameters.
% LINARDKERNEXTRACTPARAM Extract parameters from the LINARD kernel structure.
% LINARDKERNGRADIENT Gradient of LINARD kernel's parameters.
% LINARDKERNGRADX Gradient of LINARD kernel with respect to input locations.
% LINARDKERNPARAMINIT LINARD kernel parameter initialisation.
% LINKERNCOMPUTE Compute the LIN kernel given the parameters and X.
% LINKERNDIAGCOMPUTE Compute diagonal of LIN kernel.
% LINKERNDIAGGRADX Gradient of LIN kernel's diagonal with respect to X.
% LINKERNDISPLAY Display parameters of the LIN kernel.
% LINKERNEXPANDPARAM Create kernel structure from LIN kernel's parameters.
% LINKERNEXTRACTPARAM Extract parameters from the LIN kernel structure.
% LINKERNGRADIENT Gradient of LIN kernel's parameters.
% LINKERNGRADX Gradient of LIN kernel with respect to input locations.
% LINKERNPARAMINIT LIN kernel parameter initialisation.
% MATERN32KERNCOMPUTE Compute the MATERN32 kernel given the parameters and X.
% MATERN32KERNDIAGCOMPUTE Compute diagonal of MATERN32 kernel.
% MATERN32KERNDIAGGRADIENT Compute the gradient of the MATERN32 kernel's diagonal wrt parameters.
% MATERN32KERNDIAGGRADX Gradient of MATERN32 kernel's diagonal with respect to X.
% MATERN32KERNDISPLAY Display parameters of the MATERN32 kernel.
% MATERN32KERNEXPANDPARAM Create kernel structure from MATERN32 kernel's parameters.
% MATERN32KERNEXTRACTPARAM Extract parameters from the MATERN32 kernel structure.
% MATERN32KERNGRADIENT Gradient of MATERN32 kernel's parameters.
% MATERN32KERNGRADX Gradient of MATERN32 kernel with respect to input locations.
% MATERN32KERNPARAMINIT MATERN32 kernel parameter initialisation.
% MATERN52KERNCOMPUTE Compute the MATERN52 kernel given the parameters and X.
% MATERN52KERNDIAGCOMPUTE Compute diagonal of MATERN52 kernel.
% MATERN52KERNDIAGGRADIENT Compute the gradient of the MATERN52 kernel's diagonal wrt parameters.
% MATERN52KERNDIAGGRADX Gradient of MATERN52 kernel's diagonal with respect to X.
% MATERN52KERNDISPLAY Display parameters of the MATERN52 kernel.
% MATERN52KERNEXPANDPARAM Create kernel structure from MATERN52 kernel's parameters.
% MATERN52KERNEXTRACTPARAM Extract parameters from the MATERN52 kernel structure.
% MATERN52KERNGRADIENT Gradient of MATERN52 kernel's parameters.
% MATERN52KERNGRADX Gradient of MATERN52 kernel with respect to input locations.
% MATERN52KERNPARAMINIT MATERN52 kernel parameter initialisation.
% MLPARDKERNCOMPUTE Compute the MLPARD kernel given the parameters and X.
% MLPARDKERNDIAGCOMPUTE Compute diagonal of MLPARD kernel.
% MLPARDKERNDIAGGRADX Gradient of MLPARD kernel's diagonal with respect to X.
% MLPARDKERNDISPLAY Display parameters of the MLPARD kernel.
% MLPARDKERNEXPANDPARAM Create kernel structure from MLPARD kernel's parameters.
% MLPARDKERNEXTRACTPARAM Extract parameters from the MLPARD kernel structure.
% MLPARDKERNGRADIENT Gradient of MLPARD kernel's parameters.
% MLPARDKERNGRADX Gradient of MLPARD kernel with respect to input locations.
% MLPARDKERNPARAMINIT MLPARD kernel parameter initialisation.
% MLPKERNCOMPUTE Compute the MLP kernel given the parameters and X.
% MLPKERNDIAGCOMPUTE Compute diagonal of MLP kernel.
% MLPKERNDIAGGRADX Gradient of MLP kernel's diagonal with respect to X.
% MLPKERNDISPLAY Display parameters of the MLP kernel.
% MLPKERNEXPANDPARAM Create kernel structure from MLP kernel's parameters.
% MLPKERNEXTRACTPARAM Extract parameters from the MLP kernel structure.
% MLPKERNGRADIENT Gradient of MLP kernel's parameters.
% MLPKERNGRADX Gradient of MLP kernel with respect to input locations.
% MLPKERNPARAMINIT MLP kernel parameter initialisation.
% MULTIKERNCOMPUTE Compute the MULTI kernel given the parameters and X.
% MULTIKERNCOMPUTEBLOCK
% MULTIKERNDIAGCOMPUTE Compute diagonal of MULTI kernel.
% MULTIKERNDIAGGRADIENT Compute the gradient of the MULTI kernel's diagonal wrt parameters.
% MULTIKERNDIAGGRADX Gradient of MULTI kernel's diagonal with respect to X.
% MULTIKERNDISPLAY Display parameters of the MULTI kernel.
% MULTIKERNEXPANDPARAM Create kernel structure from MULTI kernel's parameters.
% MULTIKERNEXTRACTPARAM Extract parameters from the MULTI kernel structure.
% MULTIKERNGRADIENT Gradient of MULTI kernel's parameters.
% MULTIKERNGRADIENTBLOCK
% MULTIKERNGRADX Gradient of MULTI kernel with respect to a point x.
% MULTIKERNPARAMINIT MULTI kernel parameter initialisation.
% MULTIKERNTEST Run some tests on the multiple output block kernel.
% POLYARDKERNCOMPUTE Compute the POLYARD kernel given the parameters and X.
% POLYARDKERNDIAGCOMPUTE Compute diagonal of POLYARD kernel.
% POLYARDKERNDIAGGRADX Gradient of POLYARD kernel's diagonal with respect to X.
% POLYARDKERNDISPLAY Display parameters of the POLYARD kernel.
% POLYARDKERNEXPANDPARAM Create kernel structure from POLYARD kernel's parameters.
% POLYARDKERNEXTRACTPARAM Extract parameters from the POLYARD kernel structure.
% POLYARDKERNGRADIENT Gradient of POLYARD kernel's parameters.
% POLYARDKERNGRADX Gradient of POLYARD kernel with respect to input locations.
% POLYARDKERNPARAMINIT POLYARD kernel parameter initialisation.
% POLYKERNCOMPUTE Compute the POLY kernel given the parameters and X.
% POLYKERNDIAGCOMPUTE Compute diagonal of POLY kernel.
% POLYKERNDIAGGRADX Gradient of POLY kernel's diagonal with respect to X.
% POLYKERNDISPLAY Display parameters of the POLY kernel.
% POLYKERNEXPANDPARAM Create kernel structure from POLY kernel's parameters.
% POLYKERNEXTRACTPARAM Extract parameters from the POLY kernel structure.
% POLYKERNGRADIENT Gradient of POLY kernel's parameters.
% POLYKERNGRADX Gradient of POLY kernel with respect to input locations.
% POLYKERNPARAMINIT POLY kernel parameter initialisation.
% PSKERNELGRADIENT Gradient on likelihood approximation for point set IVM.
% PSKERNELOBJECTIVE Likelihood approximation for point set IVM.
% RATQUADKERNCOMPUTE Compute the RATQUAD kernel given the parameters and X.
% RATQUADKERNDIAGCOMPUTE Compute diagonal of RATQUAD kernel.
% RATQUADKERNDIAGGRADIENT Compute the gradient of the RATQUAD kernel's diagonal wrt parameters.
% RATQUADKERNDIAGGRADX Gradient of RATQUAD kernel's diagonal with respect to X.
% RATQUADKERNDISPLAY Display parameters of the RATQUAD kernel.
% RATQUADKERNEXPANDPARAM Create kernel structure from RATQUAD kernel's parameters.
% RATQUADKERNEXTRACTPARAM Extract parameters from the RATQUAD kernel structure.
% RATQUADKERNGRADIENT Gradient of RATQUAD kernel's parameters.
% RATQUADKERNGRADX Gradient of RATQUAD kernel with respect to input locations.
% RATQUADKERNPARAMINIT RATQUAD kernel parameter initialisation.
% RBFARDKERNCOMPUTE Compute the RBFARD kernel given the parameters and X.
% RBFARDKERNDIAGCOMPUTE Compute diagonal of RBFARD kernel.
% RBFARDKERNDIAGGRADIENT Compute the gradient of the RBFARD kernel's diagonal wrt parameters.
% RBFARDKERNDIAGGRADX Gradient of RBFARD kernel's diagonal with respect to X.
% RBFARDKERNDISPLAY Display parameters of the RBFARD kernel.
% RBFARDKERNEXPANDPARAM Create kernel structure from RBFARD kernel's parameters.
% RBFARDKERNEXTRACTPARAM Extract parameters from the RBFARD kernel structure.
% RBFARDKERNGRADIENT Gradient of RBFARD kernel's parameters.
% RBFARDKERNGRADX Gradient of RBFARD kernel with respect to input locations.
% RBFARDKERNPARAMINIT RBFARD kernel parameter initialisation.
% RBFKERNCOMPUTE Compute the RBF kernel given the parameters and X.
% RBFKERNDIAGCOMPUTE Compute diagonal of RBF kernel.
% RBFKERNDIAGGRADIENT Compute the gradient of the RBF kernel's diagonal wrt parameters.
% RBFKERNDIAGGRADX Gradient of RBF kernel's diagonal with respect to X.
% RBFKERNDISPLAY Display parameters of the RBF kernel.
% RBFKERNEXPANDPARAM Create kernel structure from RBF kernel's parameters.
% RBFKERNEXTRACTPARAM Extract parameters from the RBF kernel structure.
% RBFKERNGRADIENT Gradient of RBF kernel's parameters.
% RBFKERNGRADX Gradient of RBF kernel with respect to input locations.
% RBFKERNPARAMINIT RBF kernel parameter initialisation.
% RBFPERIODICKERNCOMPUTE Compute the RBFPERIODIC kernel given the parameters and X.
% RBFPERIODICKERNDIAGCOMPUTE Compute diagonal of RBFPERIODIC kernel.
% RBFPERIODICKERNDIAGGRADIENT Compute the gradient of the RBFPERIODIC kernel's diagonal wrt parameters.
% RBFPERIODICKERNDIAGGRADX Gradient of RBFPERIODIC kernel's diagonal with respect to X.
% RBFPERIODICKERNDISPLAY Display parameters of the RBFPERIODIC kernel.
% RBFPERIODICKERNEXPANDPARAM Create kernel structure from RBFPERIODIC kernel's parameters.
% RBFPERIODICKERNEXTRACTPARAM Extract parameters from the RBFPERIODIC kernel structure.
% RBFPERIODICKERNGRADIENT Gradient of RBFPERIODIC kernel's parameters.
% RBFPERIODICKERNGRADX Gradient of RBFPERIODIC kernel with respect to a point x.
% RBFPERIODICKERNPARAMINIT RBFPERIODIC kernel parameter initialisation.
% SIMCOMPUTEH Helper function for comptuing part of the SIM kernel.
% SIMCOMPUTETEST Test the file simComputeH.
% SIMKERNCOMPUTE Compute the SIM kernel given the parameters and X.
% SIMKERNDIAGCOMPUTE Compute diagonal of SIM kernel.
% SIMKERNDIAGGRADIENT Compute the gradient of the SIM kernel's diagonal wrt parameters.
% SIMKERNDIAGGRADX Gradient of SIM kernel's diagonal with respect to X.
% SIMKERNDISPLAY Display parameters of the SIM kernel.
% SIMKERNEXPANDPARAM Create kernel structure from SIM kernel's parameters.
% SIMKERNEXTRACTPARAM Extract parameters from the SIM kernel structure.
% SIMKERNGRADIENT Gradient of SIM kernel's parameters.
% SIMKERNGRADX Gradient of SIM kernel with respect to a point x.
% SIMKERNPARAMINIT SIM kernel parameter initialisation.
% SIMXRBFKERNCOMPUTE Compute a cross kernel between the SIM and RBF kernels.
% SIMXRBFKERNGRADIENT Compute gradient between the SIM and RBF kernels.
% SIMXSIMKERNCOMPUTE Compute a cross kernel between two SIM kernels.
% SIMXSIMKERNGRADIENT Compute a cross gradient between two SIM kernels.
% SQEXPKERNCOMPUTE Compute the SQEXP kernel given the parameters and X.
% SQEXPKERNDIAGCOMPUTE Compute diagonal of SQEXP kernel.
% SQEXPKERNDIAGGRADIENT Compute the gradient of the SQEXP kernel's diagonal wrt parameters.
% SQEXPKERNDIAGGRADX Gradient of SQEXP kernel's diagonal with respect to X.
% SQEXPKERNDISPLAY Display parameters of the SQEXP kernel.
% SQEXPKERNEXPANDPARAM Create kernel structure from SQEXP kernel's parameters.
% SQEXPKERNEXTRACTPARAM Extract parameters from the SQEXP kernel structure.
% SQEXPKERNGRADIENT Gradient of SQEXP kernel's parameters.
% SQEXPKERNGRADX Gradient of SQEXP kernel with respect to a point x.
% SQEXPKERNPARAMINIT SQEXP kernel parameter initialisation.
% TENSORKERNCOMPUTE Compute the TENSOR kernel given the parameters and X.
% TENSORKERNDIAGCOMPUTE Compute diagonal of TENSOR kernel.
% TENSORKERNDIAGGRADIENT Compute the gradient of the TENSOR kernel's diagonal wrt parameters.
% TENSORKERNDIAGGRADX Gradient of TENSOR kernel's diagonal with respect to X.
% TENSORKERNDISPLAY Display parameters of the TENSOR kernel.
% TENSORKERNEXPANDPARAM Create kernel structure from TENSOR kernel's parameters.
% TENSORKERNEXTRACTPARAM Extract parameters from the TENSOR kernel structure.
% TENSORKERNGRADIENT Gradient of TENSOR kernel's parameters.
% TENSORKERNGRADX Gradient of TENSOR kernel with respect to a point x.
% TENSORKERNPARAMINIT TENSOR kernel parameter initialisation.
% TENSORKERNSETINDEX Set the indices in the tensor kernel.
% TENSORKERNSLASH Tensor kernel created by removing ith component.
% WHITEFIXEDKERNCOMPUTE Compute the WHITEFIXED kernel given the parameters and X.
% WHITEFIXEDKERNDIAGCOMPUTE Compute diagonal of WHITEFIXED kernel.
% WHITEFIXEDKERNDIAGGRADIENT Compute the gradient of the WHITEFIXED kernel's diagonal wrt parameters.
% WHITEFIXEDKERNDIAGGRADX Gradient of WHITEFIXED kernel's diagonal with respect to X.
% WHITEFIXEDKERNDISPLAY Display parameters of the WHITEFIXED kernel.
% WHITEFIXEDKERNEXPANDPARAM Create kernel structure from WHITEFIXED kernel's parameters.
% WHITEFIXEDKERNEXTRACTPARAM Extract parameters from the WHITEFIXED kernel structure.
% WHITEFIXEDKERNGRADIENT Gradient of WHITEFIXED kernel's parameters.
% WHITEFIXEDKERNGRADX Gradient of WHITEFIXED kernel with respect to a point x.
% WHITEFIXEDKERNPARAMINIT WHITEFIXED kernel parameter initialisation.
% WHITEKERNCOMPUTE Compute the WHITE kernel given the parameters and X.
% WHITEKERNDIAGCOMPUTE Compute diagonal of WHITE kernel.
% WHITEKERNDIAGGRADIENT Compute the gradient of the WHITE kernel's diagonal wrt parameters.
% WHITEKERNDIAGGRADX Gradient of WHITE kernel's diagonal with respect to X.
% WHITEKERNDISPLAY Display parameters of the WHITEkernel.
% WHITEKERNEXPANDPARAM Create kernel structure from WHITE kernel's parameters.
% WHITEKERNEXTRACTPARAM Extract parameters from the WHITE kernel structure.
% WHITEKERNGRADIENT Gradient of WHITE kernel's parameters.
% WHITEKERNGRADX Gradient of WHITE kernel with respect to input locations.
% WHITEKERNPARAMINIT WHITE kernel parameter initialisation.
% WHITEXWHITEKERNCOMPUTE Compute a cross kernel between two WHITE kernels.
% WHITEXWHITEKERNGRADIENT Compute a cross gradient between two WHITE kernels.
