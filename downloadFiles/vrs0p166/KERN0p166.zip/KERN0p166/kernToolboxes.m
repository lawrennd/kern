
% KERNTOOLBOXES Load in the relevant toolboxes for kern.
%
%	Description:
%	

%	Copyright (c) 2007 Neil D. Lawrence
% 	kernToolboxes.m version 

importLatest('optimi');
importLatest('ndlutil');
importLatest('netlab');
