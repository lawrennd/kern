function kern = tensorKernSetIndex(kern, component, indices)

% TENSORKERNSETINDEX Set the indices in the tensor kernel.
%
%	Description:
%	kern = tensorKernSetIndex(kern, component, indices)
%

%	Copyright (c) 2007 Neil D. Lawrence
% 	tensorKernSetIndex.m version 1.1


kern = cmpndKernSetIndex(kern, component, indices);