% KERN toolbox
% Version 0.163		Wednesday 25 Oct 2006 at 11:54
% Copyright (c) 2006 Neil D. Lawrence
% 
% KERNPARAMINIT Kernel parameter initialisation.
% MATERN52KERNPARAMINIT MATERN52 kernel parameter initialisation.
% RATQUADKERNDIAGGRADX Gradient of RATQUAD kernel's diagonal with respect to X.
% SIMKERNEXTRACTPARAM Extract parameters from the SIM kernel structure.
% RBFKERNEXPANDPARAM Create kernel structure from RBF kernel's parameters.
% MATERN52KERNGRADX Gradient of MATERN52 kernel with respect to input locations.
% PSKERNELGRADIENT Gradient on likelihood approximation for point set IVM.
% LINARDKERNEXTRACTPARAM Extract parameters from the LINARD kernel structure.
% MLPARDKERNEXTRACTPARAM Extract parameters from the MLPARD kernel structure.
% MLPKERNEXPANDPARAM Create kernel structure from MLP kernel's parameters.
% RBFARDKERNCOMPUTE Compute the RBFARD kernel given the parameters and X.
% MLPARDKERNCOMPUTE Compute the MLPARD kernel given the parameters and X.
% BIASKERNGRADIENT Gradient of BIAS kernel's parameters.
% TENSORKERNSETINDEX Set the indices in the tensor kernel.
% KERNGRADIENT Compute the gradient wrt the kernel's parameters.
% COMPUTEKERNEL Compute the kernel given the parameters and X.
% SQEXPKERNDIAGGRADIENT Compute the gradient of the SQEXP kernel's diagonal wrt parameters.
% WHITEFIXEDKERNEXPANDPARAM Create kernel structure from WHITEFIXED kernel's parameters.
% CMPNDKERNDISPLAY Display parameters of the CMPND kernel.
% RBFARDKERNGRADIENT Gradient of RBFARD kernel's parameters.
% MLPARDKERNGRADIENT Gradient of MLPARD kernel's parameters.
% ARDKERNCOMPUTE Compute the ARD kernel given the parameters and X.
% KERNTEST Run some tests on the specified kernel.
% FILEKERNPARAMINIT FILE kernel parameter initialisation.
% MLPKERNPARAMINIT MLP kernel parameter initialisation.
% MATERN52KERNEXPANDPARAM Create kernel structure from MATERN52 kernel's parameters.
% BIASKERNEXPANDPARAM Create kernel structure from BIAS kernel's parameters.
% KERNDIAGGRADX Compute the gradient of the  kernel wrt X.
% MATERN52KERNDIAGGRADX Gradient of MATERN52 kernel's diagonal with respect to X.
% MULTIKERNEXPANDPARAM Create kernel structure from MULTI kernel's parameters.
% POLYARDKERNGRADX Gradient of POLYARD kernel with respect to input locations.
% RBFARDKERNEXPANDPARAM Create kernel structure from RBFARD kernel's parameters.
% MULTIKERNGRADIENT Gradient of MULTI kernel's parameters.
% ARDKERNDIAGCOMPUTE Compute diagonal of ARD kernel.
% MLPKERNCOMPUTE Compute the MLP kernel given the parameters and X.
% WHITEKERNCOMPUTE Compute the WHITE kernel given the parameters and X.
% SIMXSIMKERNGRADIENT Compute a cross gradient between two SIM kernels.
% ARDKERNDIAGGRADIENT Compute the gradient of the ARD kernel's diagonal wrt parameters.
% POLYKERNDIAGCOMPUTE Compute diagonal of POLY kernel.
% SIMXRBFKERNCOMPUTE Compute a cross kernel between the SIM and RBF kernels.
% LINKERNEXPANDPARAM Create kernel structure from LIN kernel's parameters.
% MLPKERNGRADIENT Gradient of MLP kernel's parameters.
% PSKERNELOBJECTIVE Likelihood approximation for point set IVM.
% KERNGETVARIANCE Get the signal associated with a the kernel.
% MATERN32KERNEXPANDPARAM Create kernel structure from MATERN32 kernel's parameters.
% MLPARDKERNDIAGCOMPUTE Compute diagonal of MLPARD kernel.
% LINARDKERNEXPANDPARAM Create kernel structure from LINARD kernel's parameters.
% KERNSETWHITE Helper function to set the white noise in a kernel if it exists.
% CMPNDKERNGRADIENT Gradient of CMPND kernel's parameters.
% WHITEXWHITEKERNGRADIENT Compute a cross gradient between two WHITE kernels.
% MULTIKERNGRADX Gradient of MULTI kernel with respect to a point x.
% RATQUADKERNDIAGGRADIENT Compute the gradient of the RATQUAD kernel's diagonal wrt parameters.
% WHITEKERNGRADIENT Gradient of WHITE kernel's parameters.
% TENSORKERNGRADX Gradient of TENSOR kernel with respect to a point x.
% MLPKERNDIAGGRADX Gradient of MLP kernel's diagonal with respect to X.
% KERNSETINDEX Set the indices on a compound kernel.
% LINARDKERNGRADIENT Gradient of LINARD kernel's parameters.
% SIMXSIMKERNCOMPUTE Compute a cross kernel between two SIM kernels.
% RATQUADKERNGRADX Gradient of RATQUAD kernel with respect to input locations.
% CMPNDKERNCOMPUTE Compute the CMPND kernel given the parameters and X.
% GIBBSKERNGRADIENT Gradient of GIBBS kernel's parameters.
% RBFKERNGRADX Gradient of RBF kernel with respect to input locations.
% RBFARDKERNPARAMINIT RBFARD kernel parameter initialisation.
% TENSORKERNPARAMINIT TENSOR kernel parameter initialisation.
% MATERN52KERNEXTRACTPARAM Extract parameters from the MATERN52 kernel structure.
% LINARDKERNGRADX Gradient of LINARD kernel with respect to input locations.
% BIASKERNEXTRACTPARAM Extract parameters from the BIAS kernel structure.
% WHITEKERNEXPANDPARAM Create kernel structure from WHITE kernel's parameters.
% CMPNDKERNDIAGCOMPUTE Compute diagonal of CMPND kernel.
% SIMKERNEXPANDPARAM Create kernel structure from SIM kernel's parameters.
% SQEXPKERNPARAMINIT SQEXP kernel parameter initialisation.
% SQEXPKERNDIAGCOMPUTE Compute diagonal of SQEXP kernel.
% MLPARDKERNPARAMINIT MLPARD kernel parameter initialisation.
% RBFKERNDISPLAY Display parameters of the RBF kernel.
% RBFKERNEXTRACTPARAM Extract parameters from the RBF kernel structure.
% RATQUADKERNEXPANDPARAM Create kernel structure from RATQUAD kernel's parameters.
% RBFARDKERNDIAGGRADX Gradient of RBFARD kernel's diagonal with respect to X.
% TENSORKERNDIAGGRADX Gradient of TENSOR kernel's diagonal with respect to X.
% FILEKERNDISPLAY Display parameters of the FILE kernel.
% MULTIKERNEXTRACTPARAM Extract parameters from the MULTI kernel structure.
% CMPNDKERNSETINDEX Set the indices in the compound kernel.
% GIBBSKERNDIAGCOMPUTE Compute diagonal of GIBBS kernel.
% TENSORKERNEXPANDPARAM Create kernel structure from TENSOR kernel's parameters.
% KERNDIAGGRADIENT Compute the gradient of the kernel's parameters for the diagonal.
% KERNREADPARAMSFROMFID Read the kernel parameters from C++ file FID.
% RBFARDKERNEXTRACTPARAM Extract parameters from the RBFARD kernel structure.
% POLYKERNGRADIENT Gradient of POLY kernel's parameters.
% SIMKERNDISPLAY Display parameters of the SIM kernel.
% SIMCOMPUTEH Helper function for comptuing part of the SIM kernel.
% KERNGRADX Compute the gradient of the kernel wrt X.
% WHITEFIXEDKERNGRADIENT Gradient of WHITEFIXED kernel's parameters.
% SQEXPKERNDIAGGRADX Gradient of SQEXP kernel's diagonal with respect to X.
% MATERN32KERNPARAMINIT MATERN32 kernel parameter initialisation.
% MLPKERNEXTRACTPARAM Extract parameters from the MLP kernel structure.
% POLYARDKERNEXTRACTPARAM Extract parameters from the POLYARD kernel structure.
% GIBBSKERNSETLENGTHSCALEFUNC Set the length scale function of the GIBBS kernel.
% MLPARDKERNDIAGGRADX Gradient of MLPARD kernel's diagonal with respect to X.
% CMPNDKERNGRADX Gradient of CMPND kernel with respect to a point x.
% TENSORKERNDISPLAY Display parameters of the TENSOR kernel.
% MATERN32KERNDISPLAY Display parameters of the MATERN32 kernel.
% MATERN52KERNGRADIENT Gradient of MATERN52 kernel's parameters.
% CMPNDKERNPARAMINIT CMPND kernel parameter initialisation.
% SIMXRBFKERNGRADIENT Compute gradient between the SIM and RBF kernels.
% KERNEXPANDPARAM Expand parameters to form a kernel structure.
% TENSORKERNDIAGGRADIENT Compute the gradient of the TENSOR kernel's diagonal wrt parameters.
% MULTIKERNTEST Run some tests on the multiple output block kernel.
% GIBBSKERNDIAGGRADIENT Compute the gradient of the GIBBS kernel's diagonal wrt parameters.
% POLYKERNPARAMINIT POLY kernel parameter initialisation.
% KERNPCA performs KPCA.
% RBFKERNCOMPUTE Compute the RBF kernel given the parameters and X.
% SQEXPKERNEXTRACTPARAM Extract parameters from the SQEXP kernel structure.
% SIMKERNGRADIENT Gradient of SIM kernel's parameters.
% LINKERNDISPLAY Display parameters of the LIN kernel.
% ARDKERNGRADX Gradient of ARD kernel with respect to a point x.
% WHITEKERNDIAGGRADIENT Compute the gradient of the WHITE kernel's diagonal wrt parameters.
% FILEKERNCOMPUTE Compute the FILE kernel given the parameters and X.
% CMPNDKERNREADPARAMSFROMFID Read a compound kernel from a C++ file.
% POLYARDKERNDIAGCOMPUTE Compute diagonal of POLYARD kernel.
% SQEXPKERNGRADX Gradient of SQEXP kernel with respect to a point x.
% FILEKERNREAD Read kernel values from file or cache.
% POLYKERNGRADX Gradient of POLY kernel with respect to input locations.
% MATERN32KERNDIAGGRADX Gradient of MATERN32 kernel's diagonal with respect to X.
% RBFARDKERNGRADX Gradient of RBFARD kernel with respect to input locations.
% LINKERNGRADIENT Gradient of LIN kernel's parameters.
% SIMKERNGRADX Gradient of SIM kernel with respect to a point x.
% SIMKERNPARAMINIT SIM kernel parameter initialisation.
% WHITEFIXEDKERNDIAGGRADIENT Compute the gradient of the WHITEFIXED kernel's diagonal wrt parameters.
% BIASKERNDISPLAY Display parameters of the BIASkernel.
% SIMKERNCOMPUTE Compute the SIM kernel given the parameters and X.
% CMPNDKERNDIAGGRADX Gradient of CMPND kernel's diagonal with respect to X.
% MATERN32KERNGRADX Gradient of MATERN32 kernel with respect to input locations.
% FILEKERNDIAGCOMPUTE Compute diagonal of FILE kernel.
% GIBBSKERNDISPLAY Display parameters of the GIBBS kernel.
% KERNPRIORLOGPROB Compute penalty terms associated with kernel priors.
% ARDKERNEXTRACTPARAM Extract parameters from the ARD kernel structure.
% POLYKERNDISPLAY Display parameters of the POLY kernel.
% POLYKERNDIAGGRADX Gradient of POLY kernel's diagonal with respect to X.
% TENSORKERNCOMPUTE Compute the TENSOR kernel given the parameters and X.
% MATERN32KERNCOMPUTE Compute the MATERN32 kernel given the parameters and X.
% CMPNDKERNDIAGGRADIENT Compute the gradient of the CMPND kernel's diagonal wrt parameters.
% RBFKERNDIAGCOMPUTE Compute diagonal of RBF kernel.
% WHITEKERNPARAMINIT WHITE kernel parameter initialisation.
% MLPKERNDIAGCOMPUTE Compute diagonal of MLP kernel.
% MATERN32KERNDIAGGRADIENT Compute the gradient of the MATERN32 kernel's diagonal wrt parameters.
% RATQUADKERNEXTRACTPARAM Extract parameters from the RATQUAD kernel structure.
% ARDKERNEXPANDPARAM Create kernel structure from ARD kernel's parameters.
% WHITEKERNGRADX Gradient of WHITE kernel with respect to input locations.
% POLYKERNEXPANDPARAM Create kernel structure from POLY kernel's parameters.
% SIMKERNDIAGGRADX Gradient of SIM kernel's diagonal with respect to X.
% LINKERNCOMPUTE Compute the LIN kernel given the parameters and X.
% MULTIKERNDISPLAY Display parameters of the MULTI kernel.
% WHITEFIXEDKERNDIAGCOMPUTE Compute diagonal of WHITEFIXED kernel.
% ARDKERNPARAMINIT ARD kernel parameter initialisation.
% LINARDKERNDISPLAY Display parameters of the LINARD kernel.
% BIASKERNGRADX Gradient of BIAS kernel with respect to input locations.
% SIMKERNDIAGGRADIENT Compute the gradient of the SIM kernel's diagonal wrt parameters.
% MLPARDKERNEXPANDPARAM Create kernel structure from MLPARD kernel's parameters.
% LINKERNGRADX Gradient of LIN kernel with respect to input locations.
% MATERN52KERNDIAGCOMPUTE Compute diagonal of MATERN52 kernel.
% RBFKERNPARAMINIT RBF kernel parameter initialisation.
% BIASKERNDIAGCOMPUTE Compute diagonal of BIAS kernel.
% WHITEFIXEDKERNPARAMINIT WHITEFIXED kernel parameter initialisation.
% MULTIKERNDIAGCOMPUTE Compute diagonal of MULTI kernel.
% ARDKERNGRADIENT Gradient of ARD kernel's parameters.
% RBFARDKERNDIAGCOMPUTE Compute diagonal of RBFARD kernel.
% POLYARDKERNGRADIENT Gradient of POLYARD kernel's parameters.
% POLYARDKERNPARAMINIT POLYARD kernel parameter initialisation.
% BIASKERNCOMPUTE Compute the BIAS kernel given the parameters and X.
% WHITEKERNDIAGGRADX Gradient of WHITE kernel's diagonal with respect to X.
% KERNPRIORGRADIENT Compute gradient terms associated with kernel priors.
% SQEXPKERNDISPLAY Display parameters of the SQEXP kernel.
% GIBBSKERNCOMPUTE Compute the GIBBS kernel given the parameters and X.
% POLYKERNCOMPUTE Compute the POLY kernel given the parameters and X.
% LINKERNDIAGCOMPUTE Compute diagonal of LIN kernel.
% LINARDKERNPARAMINIT LINARD kernel parameter initialisation.
% MATERN32KERNDIAGCOMPUTE Compute diagonal of MATERN32 kernel.
% CMPNDKERNEXPANDPARAM Create kernel structure from CMPND kernel's parameters.
% LINARDKERNDIAGCOMPUTE Compute diagonal of LINARD kernel.
% ARDKERNDIAGGRADX Gradient of ARD kernel's diagonal with respect to X.
% MULTIKERNPARAMINIT MULTI kernel parameter initialisation.
% MATERN52KERNDISPLAY Display parameters of the MATERN52 kernel.
% RBFKERNDIAGGRADX Gradient of RBF kernel's diagonal with respect to X.
% WHITEFIXEDKERNDIAGGRADX Gradient of WHITEFIXED kernel's diagonal with respect to X.
% RBFKERNGRADIENT Gradient of RBF kernel's parameters.
% POLYKERNEXTRACTPARAM Extract parameters from the POLY kernel structure.
% KERNEXTRACTPARAM Extract parameters from kernel structure.
% POLYARDKERNDISPLAY Display parameters of the POLYARD kernel.
% SQEXPKERNEXPANDPARAM Create kernel structure from SQEXP kernel's parameters.
% MULTIKERNCOMPUTE Compute the MULTI kernel given the parameters and X.
% POLYARDKERNDIAGGRADX Gradient of POLYARD kernel's diagonal with respect to X.
% BIASKERNPARAMINIT BIAS kernel parameter initialisation.
% GIBBSKERNGRADX Gradient of GIBBS kernel with respect to input locations.
% LINARDKERNCOMPUTE Compute the LINARD kernel given the parameters and X.
% RATQUADKERNDISPLAY Display parameters of the RATQUAD kernel.
% WHITEFIXEDKERNGRADX Gradient of WHITEFIXED kernel with respect to a point x.
% LINKERNEXTRACTPARAM Extract parameters from the LIN kernel structure.
% KERNDISPLAY Display the parameters of the kernel.
% MLPKERNGRADX Gradient of MLP kernel with respect to input locations.
% WHITEKERNDIAGCOMPUTE Compute diagonal of WHITE kernel.
% GIBBSKERNEXPANDPARAM Create kernel structure from GIBBS kernel's parameters.
% LINARDKERNDIAGGRADX Gradient of LINARD kernel's diagonal with respect to X.
% SIMKERNDIAGCOMPUTE Compute diagonal of SIM kernel.
% SQEXPKERNGRADIENT Gradient of SQEXP kernel's parameters.
% WHITEFIXEDKERNDISPLAY Display parameters of the WHITEFIXED kernel.
% SQEXPKERNCOMPUTE Compute the SQEXP kernel given the parameters and X.
% MULTIKERNDIAGGRADX Gradient of MULTI kernel's diagonal with respect to X.
% TENSORKERNEXTRACTPARAM Extract parameters from the TENSOR kernel structure.
% MATERN52KERNDIAGGRADIENT Compute the gradient of the MATERN52 kernel's diagonal wrt parameters.
% GIBBSKERNEXTRACTPARAM Extract parameters from the GIBBS kernel structure.
% MULTIKERNCOMPUTEBLOCK
% BIASKERNDIAGGRADIENT Compute the gradient of the BIAS kernel's diagonal wrt parameters.
% WHITEXWHITEKERNCOMPUTE Compute a cross kernel between two WHITE kernels.
% RATQUADKERNDIAGCOMPUTE Compute diagonal of RATQUAD kernel.
% GIBBSKERNPARAMINIT GIBBS kernel parameter initialisation.
% BIASKERNDIAGGRADX Gradient of BIAS kernel's diagonal with respect to X.
% WHITEKERNEXTRACTPARAM Extract parameters from the WHITE kernel structure.
% TENSORKERNSLASH Tensor kernel created by removing ith component.
% KERNFACTORS Extract factors associated with transformed optimisation space.
% MATERN52KERNCOMPUTE Compute the MATERN52 kernel given the parameters and X.
% TENSORKERNDIAGCOMPUTE Compute diagonal of TENSOR kernel.
% RBFARDKERNDISPLAY Display parameters of the RBFARD kernel.
% MLPARDKERNDISPLAY Display parameters of the MLPARD kernel.
% MULTIKERNGRADIENTBLOCK
% TENSORKERNGRADIENT Gradient of TENSOR kernel's parameters.
% LINKERNPARAMINIT LIN kernel parameter initialisation.
% MLPARDKERNGRADX Gradient of MLPARD kernel with respect to input locations.
% POLYARDKERNCOMPUTE Compute the POLYARD kernel given the parameters and X.
% WHITEFIXEDKERNEXTRACTPARAM Extract parameters from the WHITEFIXED kernel structure.
% FILEKERNEXTRACTPARAM Extract parameters from the FILE kernel structure.
% MATERN32KERNGRADIENT Gradient of MATERN32 kernel's parameters.
% RATQUADKERNPARAMINIT RATQUAD kernel parameter initialisation.
% RBFKERNDIAGGRADIENT Compute the gradient of the RBF kernel's diagonal wrt parameters.
% SIMCOMPUTETEST Test the file simComputeH.
% KERNREADFROMFID Load from an FID written by the C++ implementation.
% RATQUADKERNCOMPUTE Compute the RATQUAD kernel given the parameters and X.
% ARDKERNDISPLAY Display parameters of the ARD kernel.
% POLYARDKERNEXPANDPARAM Create kernel structure from POLYARD kernel's parameters.
% MULTIKERNDIAGGRADIENT Compute the gradient of the MULTI kernel's diagonal wrt parameters.
% KERNCOMPUTE Compute the kernel given the parameters and X.
% KERNCREATE Initialise a kernel structure.
% CMPNDKERNEXTRACTPARAM Extract parameters from the CMPND kernel structure.
% RATQUADKERNGRADIENT Gradient of RATQUAD kernel's parameters.
% GIBBSKERNDIAGGRADX Gradient of GIBBS kernel's diagonal with respect to X.
% KERNDIAGCOMPUTE Compute the kernel given the parameters and X.
% WHITEFIXEDKERNCOMPUTE Compute the WHITEFIXED kernel given the parameters and X.
% MATERN32KERNEXTRACTPARAM Extract parameters from the MATERN32 kernel structure.
% FILEKERNGRADX Gradient of FILE kernel with respect to a point x.
% RBFARDKERNDIAGGRADIENT Compute the gradient of the RBFARD kernel's diagonal wrt parameters.
% FILEKERNGRADIENT Gradient of FILE kernel's parameters.
% MLPKERNDISPLAY Display parameters of the MLP kernel.
% FILEKERNEXPANDPARAM Create kernel structure from FILE kernel's parameters.
% WHITEKERNDISPLAY Display parameters of the WHITEkernel.
% LINKERNDIAGGRADX Gradient of LIN kernel's diagonal with respect to X.
