function g = linKernGradient(kern, x, varargin)

% LINKERNGRADIENT Gradient of lin kernel's parameters.
%
% g = linKernGradient(kern, x, varargin)
%

% Copyright (c) 2006 Neil D. Lawrence
% linKernGradient.m version 1.4



if nargin < 4
  linPart = linKernCompute(kern, x);
else
  linPart = linKernCompute(kern, x, varargin{1});
end
g(1) = sum(sum(varargin{end}.*linPart))/kern.variance;
