function k = biasKernDiagCompute(kern, x)

% BIASKERNDIAGCOMPUTE Compute diagonal of bias kernel.
%
% k = biasKernDiagCompute(kern, x)
%

% Copyright (c) 2006 Neil D. Lawrence
% biasKernDiagCompute.m version 1.2





k = repmat(kern.variance, size(x, 1), 1);