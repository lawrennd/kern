function k = mlpKernDiagCompute(kern, x)

% MLPKERNDIAGCOMPUTE Compute diagonal of multi-layer perceptron kernel.
%
% k = mlpKernDiagCompute(kern, x)
%

% Copyright (c) 2006 Neil D. Lawrence
% mlpKernDiagCompute.m version 1.3




numer = sum(x.*x, 2)*kern.weightVariance + kern.biasVariance;
denom = numer+1;
k = kern.variance*asin(numer./denom);
