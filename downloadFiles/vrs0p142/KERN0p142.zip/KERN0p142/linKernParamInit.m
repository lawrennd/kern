function kern = linKernParamInit(kern)

% LINKERNPARAMINIT Linear kernel parameter initialisation.
%
% kern = linKernParamInit(kern)
%

% Copyright (c) 2006 Neil D. Lawrence
% linKernParamInit.m version 1.3



kern.variance = 1;
kern.nParams = 1;

kern.transforms.index = 1;
kern.transforms.type = 'negLogLogit';
