function kern = whiteKernParamInit(kern)

% WHITEKERNPARAMINIT white noise kernel parameter initialisation.
%
% kern = whiteKernParamInit(kern)
%

% Copyright (c) 2006 Neil D. Lawrence
% whiteKernParamInit.m version 1.3



kern.variance = exp(-2);
kern.nParams = 1;

kern.transforms.index = 1;
kern.transforms.type = 'negLogLogit';

