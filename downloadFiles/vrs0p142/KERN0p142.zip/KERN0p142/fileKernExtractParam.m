function params = fileKernExtractParam(kern)

% FILEKERNEXTRACTPARAM Extract parameter from kernel stored in a file.
%
% params = fileKernExtractParam(kern)
%

% Copyright (c) 2006 Neil D. Lawrence
% fileKernExtractParam.m version 1.1



params = [kern.variance];
