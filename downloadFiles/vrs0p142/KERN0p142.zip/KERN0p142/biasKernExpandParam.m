function kern = biasKernExpandParam(kern, params)

% BIASKERNEXPANDPARAM Create kernel structure from bias's parameters.
%
% kern = biasKernExpandParam(kern, params)
%

% Copyright (c) 2006 Neil D. Lawrence
% biasKernExpandParam.m version 1.2





kern.variance = params(1);