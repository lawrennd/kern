function [params, names] = kernExtractParam(kern)

% KERNEXTRACTPARAM Extract parameters from kernel structure.
%
% [params, names] = kernExtractParam(kern)
%

% Copyright (c) 2006 Neil D. Lawrence
% kernExtractParam.m version 1.4



fhandle = str2func([kern.type 'KernExtractParam']);
params = fhandle(kern);
names = cell(size(params));

% Check if parameters are being optimised in a transformed space.
if ~isempty(kern.transforms)
  for i = 1:length(kern.transforms)
    index = kern.transforms(i).index;
    fhandle = str2func([kern.transforms(i).type 'Transform']);
    params(index) = fhandle(params(index), 'xtoa');
  end
end