function g = rbfKernGradient(kern, x, varargin)

% RBFKERNGRADIENT Gradient of rbf kernel's parameters.
%
% g = rbfKernGradient(kern, x, varargin)
%

% Copyright (c) 2006 Neil D. Lawrence
% rbfKernGradient.m version 1.6



% The last argument is covGrad
if nargin < 4
  [k, dist2xx] = rbfKernCompute(kern, x);
else
  [k, dist2xx] = rbfKernCompute(kern, x, varargin{1});
end
g(1) = - .5*sum(sum(varargin{end}.*k.*dist2xx));
g(2) =  sum(sum(varargin{end}.*k))/kern.variance;
