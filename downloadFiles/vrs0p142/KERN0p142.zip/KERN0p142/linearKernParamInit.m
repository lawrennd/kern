function kern = linearKernParamInit(kern)

% LINEARKERNPARAMINIT Linear kernel parameter initialisation.
%
% kern = linearKernParamInit(kern)
%

% Copyright (c) 2006 Neil D. Lawrence
% linearKernParamInit.m version 1.2





kern.variance = 1;
kern.nParams = 1;