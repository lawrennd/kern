function k = polyKernDiagCompute(kern, x)

% POLYKERNDIAGCOMPUTE Compute diagonal of polynomial kernel.
%
% k = polyKernDiagCompute(kern, x)
%

% Copyright (c) 2006 Neil D. Lawrence
% polyKernDiagCompute.m version 1.1



k =  kern.variance*(sum(x.*x, 2)*kern.weightVariance + kern.biasVariance).^kern.degree;
