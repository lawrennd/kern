function kern = polyKernExpandParam(kern, params)

% POLYKERNEXPANDPARAM Create kernel structure from polynomial kernel parameters.
%
% kern = polyKernExpandParam(kern, params)
%

% Copyright (c) 2006 Neil D. Lawrence
% polyKernExpandParam.m version 1.1



kern.weightVariance = params(1);
kern.biasVariance = params(2);
kern.variance = params(3);
