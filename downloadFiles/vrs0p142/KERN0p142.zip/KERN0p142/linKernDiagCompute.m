function k = linKernDiagCompute(kern, x)

% LINKERNDIAGCOMPUTE Compute diagonal of linear kernel.
%
% k = linKernDiagCompute(kern, x)
%

% Copyright (c) 2006 Neil D. Lawrence
% linKernDiagCompute.m version 1.3



k =  sum(x.*x, 2)*kern.variance;
