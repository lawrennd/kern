function params = whiteKernExtractParam(kern)

% WHITEKERNEXTRACTPARAM Extract parameters from white noise kernel structure.
%
% params = whiteKernExtractParam(kern)
%

% Copyright (c) 2006 Neil D. Lawrence
% whiteKernExtractParam.m version 1.2





params = kern.variance;
