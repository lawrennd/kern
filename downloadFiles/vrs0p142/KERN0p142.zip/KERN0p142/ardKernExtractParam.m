function params = ardKernExtractParam(kern)

% ARDKERNEXTRACTPARAM Extract parameters from ard kernel structure.
%
% params = ardKernExtractParam(kern)
%

% Copyright (c) 2006 Neil D. Lawrence
% ardKernExtractParam.m version 1.2





params = [kern.inverseWidth kern.rbfVariance ...
          kern.biasVariance kern.whiteVariance ...
          kern.linearVariance kern.inputScales];
