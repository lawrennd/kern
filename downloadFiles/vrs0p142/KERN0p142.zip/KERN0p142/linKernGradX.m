function gX = linKernGradX(kern, X, X2)

% LINKERNGRADX Gradient of linear kernel with respect to X.
%
% gX = linKernGradX(kern, X, X2)
%

% Copyright (c) 2006 Neil D. Lawrence
% linKernGradX.m version 1.3



gX = repmat(kern.variance.*X2, [1 1 size(X, 1)]);