function kern = whiteKernExpandParam(kern, params)

% WHITEKERNEXPANDPARAM Create kernel structure from white noise's parameters.
%
% kern = whiteKernExpandParam(kern, params)
%

% Copyright (c) 2006 Neil D. Lawrence
% whiteKernExpandParam.m version 1.3



kern.variance = params(1);