function cmpndKernDisplay(kern, varargin)

% CMPNDKERNDISPLAY Display the parameters of the compound kernel.
%
% cmpndKernDisplay(kern, varargin)
%

% Copyright (c) 2006 Neil D. Lawrence
% cmpndKernDisplay.m version 1.3



for i = 1:length(kern.comp)
  kernDisplay(kern.comp{i}, varargin{:});
end