function kern = fileKernExpandParam(kern, params)

% FILEKERNEXPANDPARAM Create kernel structure from parameter.
%
% kern = fileKernExpandParam(kern, params)
%

% Copyright (c) 2006 Neil D. Lawrence
% fileKernExpandParam.m version 1.1



kern.variance = params(1);
