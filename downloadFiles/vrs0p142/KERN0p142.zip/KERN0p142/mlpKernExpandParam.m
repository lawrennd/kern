function kern = mlpKernExpandParam(kern, params)

% MLPKERNEXPANDPARAM Create kernel structure from multi-layer perceptron's parameters.
%
% kern = mlpKernExpandParam(kern, params)
%

% Copyright (c) 2006 Neil D. Lawrence
% mlpKernExpandParam.m version 1.3




kern.weightVariance = params(1);
kern.biasVariance = params(2);
kern.variance = params(3);
