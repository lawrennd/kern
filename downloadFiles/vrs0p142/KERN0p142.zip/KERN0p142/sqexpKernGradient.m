function g = sqexpKernGradient(kern, x, covGrad)

% SQEXPKERNGRADIENT Gradient of squared exponential kernel's parameters.
%
% g = sqexpKernGradient(kern, x, covGrad)
%

% Copyright (c) 2006 Neil D. Lawrence
% sqexpKernGradient.m version 1.3



[k, rbfPart, dist2xx] = sqexpKernCompute(kern, x);
g(1) = - .5*sum(sum(covGrad.*rbfPart.*dist2xx));
g(2) =  sum(sum(covGrad.*rbfPart))/kern.rbfVariance;
g(3) =  sum(sum(covGrad));
g(4) =  trace(covGrad);

