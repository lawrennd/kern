function k = ardKernDiagCompute(kern, x)

% ARDKERNDIAGCOMPUTE Compute diagonal of ard kernel.
%
% k = ardKernDiagCompute(kern, x)
%

% Copyright (c) 2006 Neil D. Lawrence
% ardKernDiagCompute.m version 1.2





scales = sparse(diag(sqrt(kern.inputScales)));
x = x*scales;

rbfPart = ones(size(x, 1), 1);
linearPart = sum(x.*x, 2)*kern.linearVariance;
k = rbfPart*(kern.rbfVariance + kern.whiteVariance) + kern.biasVariance +linearPart;
