function whiteKernDisplay(kern, spacing)

% WHITEKERNDISPLAY Display parameters of white noise kernel.
%
% whiteKernDisplay(kern, spacing)
%

% Copyright (c) 2006 Neil D. Lawrence
% whiteKernDisplay.m version 1.4



if nargin > 1
  spacing = repmat(32, 1, spacing);
else
  spacing = [];
end
spacing = char(spacing);
fprintf(spacing);
fprintf('White Noise Variance: %2.4f\n', kern.variance)
