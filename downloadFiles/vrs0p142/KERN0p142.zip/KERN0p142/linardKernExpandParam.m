function kern = linardKernExpandParam(kern, params)

% LINARDKERNEXPANDPARAM Create kernel structure from linear ARD's parameters.
%
% kern = linardKernExpandParam(kern, params)
%

% Copyright (c) 2006 Neil D. Lawrence
% linardKernExpandParam.m version 1.2





kern.variance = params(1);
kern.inputScales = params(2:end);
