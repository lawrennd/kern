function gX = biasKernGradX(kern, X, X2)

% BIASKERNGRADX Gradient of bias kernel with respect to a point x.
%
% gX = biasKernGradX(kern, X, X2)
%

% Copyright (c) 2006 Neil D. Lawrence
% biasKernGradX.m version 1.3



gX = zeros(size(X2, 1), size(X2, 2), size(X, 1));
