function gX = rbfardKernDiagGradX(kern, X)

% RBFARDKERNDIAGGRADX Gradient of radial basis function ARD kernel's diagonal with respect to X.
%
% gX = rbfardKernDiagGradX(kern, X)
%

% Copyright (c) 2006 Neil D. Lawrence
% rbfardKernDiagGradX.m version 1.3



gX = zeros(size(X));