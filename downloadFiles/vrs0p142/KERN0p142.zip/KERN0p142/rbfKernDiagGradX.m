function gX = rbfKernDiagGradX(kern, X)

% RBFKERNDIAGGRADX Gradient of Radial basis function kernel's diagonal with respect to X.
%
% gX = rbfKernDiagGradX(kern, X)
%

% Copyright (c) 2006 Neil D. Lawrence
% rbfKernDiagGradX.m version 1.4



gX = zeros(size(X));

