function kern = rbfardKernExpandParam(kern, params)

% RBFARDKERNEXPANDPARAM Create kernel structure from radial basis function ARD's parameters.
%
% kern = rbfardKernExpandParam(kern, params)
%

% Copyright (c) 2006 Neil D. Lawrence
% rbfardKernExpandParam.m version 1.2




kern.inverseWidth = params(1);
kern.variance = params(2);
kern.inputScales = params(3:end);
