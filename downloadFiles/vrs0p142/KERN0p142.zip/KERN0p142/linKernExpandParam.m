function kern = linKernExpandParam(kern, params)

% LINKERNEXPANDPARAM Create kernel structure from linear kernel parameters.
%
% kern = linKernExpandParam(kern, params)
%

% Copyright (c) 2006 Neil D. Lawrence
% linKernExpandParam.m version 1.3



kern.variance = params(1);
