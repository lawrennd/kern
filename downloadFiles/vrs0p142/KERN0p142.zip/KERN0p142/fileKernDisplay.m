function fileKernDisplay(kern)

% FILEKERNDISPLAY Display variance of kernel stored in a file.
%
% fileKernDisplay(kern)
%

% Copyright (c) 2006 Neil D. Lawrence
% fileKernDisplay.m version 1.1




fprintf('File Kernel Variance: %2.4f\n', kern.variance)
