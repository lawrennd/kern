function kernDisplay(kern, varargin)

% KERNDISPLAY Display the parameters of the kernel.
%
% kernDisplay(kern, varargin)
%

% Copyright (c) 2006 Neil D. Lawrence
% kernDisplay.m version 1.5



fhandle = str2func([kern.type 'KernDisplay']);
fhandle(kern, varargin{:});