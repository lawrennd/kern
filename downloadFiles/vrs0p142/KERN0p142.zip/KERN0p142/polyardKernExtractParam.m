function params = polyardKernExtractParam(kern)

% POLYARDKERNEXTRACTPARAM Extract parameters from multi-layer perceptron ARD kernel structure.
%
% params = polyardKernExtractParam(kern)
%

% Copyright (c) 2006 Neil D. Lawrence
% polyardKernExtractParam.m version 1.1



params = [kern.weightVariance kern.biasVariance kern.variance kern.inputScales];
