function params = mlpardKernExtractParam(kern)

% MLPARDKERNEXTRACTPARAM Extract parameters from multi-layer perceptron ARD kernel structure.
%
% params = mlpardKernExtractParam(kern)
%

% Copyright (c) 2006 Neil D. Lawrence
% mlpardKernExtractParam.m version 1.3



params = [kern.weightVariance kern.biasVariance kern.variance kern.inputScales];
