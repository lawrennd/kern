function kern = fileKernParamInit(kern)

% FILEKERNPARAMINIT File stored kernel parameter initialisation.
%
% kern = fileKernParamInit(kern)
%

% Copyright (c) 2006 Neil D. Lawrence
% fileKernParamInit.m version 1.1



kern.variance = 1;
kern.nParams = 1;

kern.transforms.index = [1];
kern.transforms.type = 'negLogLogit';
