function k = lfmKernDiagCompute(kern, t)

% LFMKERNDIAGCOMPUTE Compute diagonal of LFM kernel.
%
%	Description:
%
%	K = LFMKERNDIAGCOMPUTE(KERN, T) computes the diagonal of the kernel
%	matrix for the single input motif kernel given a design matrix of
%	inputs.
%	 Returns:
%	  K - a vector containing the diagonal of the kernel matrix computed
%	   at the given points.
%	 Arguments:
%	  KERN - the kernel structure for which the matrix is computed.
%	  T - input data matrix in the form of a design matrix.
%	
%
%	See also
%	LFMKERNPARAMINIT, KERNDIAGCOMPUTE, KERNCREATE, LFMKERNCOMPUTE


%	Copyright (c) 2007 Neil D. Lawrence
% 	lfmKernDiagCompute.m SVN version 20
% 	last update 2008-06-06T19:39:32.000000Z

if size(t, 2) > 1 
  error('Input can only have one column');
end

k = zeros(size(t, 1), 1);
for i = 1:size(t, 1)
  k(i) = lfmXlfmKernCompute(kern, kern, t(i), t(i));
end