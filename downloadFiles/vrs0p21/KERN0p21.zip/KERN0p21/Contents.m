% KERN toolbox
% Version 0.21		11-Oct-2008
% Copyright (c) 2008, Neil D. Lawrence
% 
, Neil D. Lawrence
% RBFPERIODICKERNPARAMINIT RBFPERIODIC kernel parameter initialisation.
% DISIMXSIMKERNCOMPUTE Compute a cross kernel between DISIM and SIM kernels.
% EXPKERNEXPANDPARAM Create kernel structure from EXP kernel's parameters.
% WHITEFIXEDKERNGRADX Gradient of WHITEFIXED kernel with respect to a point x.
% DISIMXDISIMKERNGRADIENT Compute a cross gradient between two DISIM kernels.
% DISIMKERNGRADIENT Gradient of DISIM kernel's parameters.
% TRANSLATEKERNGRADX Gradient of TRANSLATE kernel with respect to a point x.
% RATQUADKERNEXPANDPARAM Create kernel structure from RATQUAD kernel's parameters.
% SQEXPKERNGRADIENT Gradient of SQEXP kernel's parameters.
% MATERN32KERNCOMPUTE Compute the MATERN32 kernel given the parameters and X.
% MLPKERNDIAGGRADX Gradient of MLP kernel's diagonal with respect to X.
% WHITEFIXEDXWHITEFIXEDKERNCOMPUTE Compute a cross kernel between two WHITEFIXED kernels.
% MLPARDKERNGRADIENT Gradient of MLPARD kernel's parameters.
% TENSORKERNDISPLAY Display parameters of the TENSOR kernel.
% DISIMKERNEXTRACTPARAM Extract parameters from the DISIM kernel structure.
% GIBBSPERIODICKERNGRADIENT Gradient of GIBBSPERIODIC kernel's parameters.
% SQEXPKERNDIAGGRADX Gradient of SQEXP kernel's diagonal with respect to X.
% GIBBSKERNDIAGCOMPUTE Compute diagonal of GIBBS kernel.
% GGKERNEXPANDPARAM Create kernel structure from GG kernel's parameters.
% LINARDKERNEXTRACTPARAM Extract parameters from the LINARD kernel structure.
% LFMGRADIENTSIGMAH3 Gradient of the function h_i(z) with respect \sigma.
% DISIMKERNPARAMINIT DISIM kernel parameter initialisation.
% KERNREADPARAMSFROMFID Read the kernel parameters from C++ file FID.
% TENSORKERNGRADX Gradient of TENSOR kernel with respect to a point x.
% RBFPERIODICKERNGRADX Gradient of RBFPERIODIC kernel with respect to a point x.
% MATERN32KERNDIAGGRADIENT Compute the gradient of the MATERN32 kernel's diagonal wrt parameters.
% MATERN32KERNEXPANDPARAM Create kernel structure from MATERN32 kernel's parameters.
% SIMKERNDIAGCOMPUTE Compute diagonal of SIM kernel.
% TRANSLATEKERNDIAGCOMPUTE Compute diagonal of TRANSLATE kernel.
% POLYKERNCOMPUTE Compute the POLY kernel given the parameters and X.
% MATERN32KERNGRADIENT Gradient of MATERN32 kernel's parameters.
% MLPKERNCOMPUTE Compute the MLP kernel given the parameters and X.
% POLYKERNEXPANDPARAM Create kernel structure from POLY kernel's parameters.
% LINKERNDISPLAY Display parameters of the LIN kernel.
% KERNCOMPUTE Compute the kernel given the parameters and X.
% TENSORKERNDIAGGRADX Gradient of TENSOR kernel's diagonal with respect to X.
% DISIMXDISIMKERNCOMPUTE Compute a cross kernel between two DISIM kernels.
% RATQUADKERNCOMPUTE Compute the RATQUAD kernel given the parameters and X.
% MLPARDKERNDIAGGRADX Gradient of MLPARD kernel's diagonal with respect to X.
% KERNPCA performs KPCA.
% TENSORKERNEXTRACTPARAM Extract parameters from the TENSOR kernel structure.
% FILEKERNDIAGCOMPUTE Compute diagonal of FILE kernel.
% EXPKERNPARAMINIT EXP kernel parameter initialisation.
% SIMKERNEXTRACTPARAM Extract parameters from the SIM kernel structure.
% MLPKERNGRADIENT Gradient of MLP kernel's parameters.
% MATERN32KERNGRADX Gradient of MATERN32 kernel with respect to input locations.
% EXPKERNCOMPUTE Compute the EXP kernel given the parameters and X.
% WHITEFIXEDKERNEXTRACTPARAM Extract parameters from the WHITEFIXED kernel structure.
% POLYARDKERNEXTRACTPARAM Extract parameters from the POLYARD kernel structure.
% GIBBSKERNSETLENGTHSCALEFUNC Set the length scale function of the GIBBS kernel.
% SQEXPKERNGRADX Gradient of SQEXP kernel with respect to a point x.
% KERNCREATE Initialise a kernel structure.
% MLPKERNDISPLAY Display parameters of the MLP kernel.
% KERNDIAGGRADIENT Compute the gradient of the kernel's parameters for the diagonal.
% RBFARDKERNGRADX Gradient of RBFARD kernel with respect to input locations.
% WHITEFIXEDKERNCOMPUTE Compute the WHITEFIXED kernel given the parameters and X.
% LFMXLFMKERNCOMPUTE Compute a cross kernel between two LFM kernels.
% POLYKERNDIAGCOMPUTE Compute diagonal of POLY kernel.
% CMPNDKERNEXTRACTPARAM Extract parameters from the CMPND kernel structure.
% BIASKERNDIAGGRADIENT Compute the gradient of the BIAS kernel's diagonal wrt parameters.
% GIBBSKERNDISPLAY Display parameters of the GIBBS kernel.
% COMPONENTKERNREADPARAMSFROMFID Read a component based kernel from a C++ file.
% LFMUPDATEKERNELS Updates the kernel representations in the LFM structure.
% POLYARDKERNEXPANDPARAM Create kernel structure from POLYARD kernel's parameters.
% RATQUADKERNDIAGGRADIENT Compute the gradient of the RATQUAD kernel's diagonal wrt parameters.
% RBFARDKERNEXTRACTPARAM Extract parameters from the RBFARD kernel structure.
% ARDKERNEXTRACTPARAM Extract parameters from the ARD kernel structure.
% TENSORKERNGRADIENT Gradient of TENSOR kernel's parameters.
% RBFKERNDIAGGRADIENT Compute the gradient of the RBF kernel's diagonal wrt parameters.
% LINKERNEXPANDPARAM Create kernel structure from LIN kernel's parameters.
% BIASKERNGRADIENT Gradient of BIAS kernel's parameters.
% RATQUADKERNPARAMINIT RATQUAD kernel parameter initialisation.
% KERNELCENTER Attempts to Center Kernel Matrix
% GGXGAUSSIANKERNCOMPUTE Compute a cross kernel between the GG and GAUSSIAN kernels.
% WHITEKERNGRADIENT Gradient of WHITE kernel's parameters.
% DISIMCOMPUTEHPRIME Helper function for comptuing part of the DISIM kernel.
% RATQUADKERNGRADIENT Gradient of RATQUAD kernel's parameters.
% LFMKERNDIAGCOMPUTE Compute diagonal of LFM kernel.
% MLPKERNEXTRACTPARAM Extract parameters from the MLP kernel structure.
% RBFKERNGRADIENT Gradient of RBF kernel's parameters.
% RATQUADKERNDIAGGRADX Gradient of RATQUAD kernel's diagonal with respect to X.
% LFMOPTIONS Creates a set of default options for a LFM model.
% LFMGRADIENTH Gradient of the function h_i(z) with respect to some of the
% LFMGRADIENTSIGMAH Gradient of the function h_i(z) with respect \sigma.
% WHITEFIXEDKERNEXPANDPARAM Create kernel structure from WHITEFIXED kernel's parameters.
% SIMXSIMKERNCOMPUTE Compute a cross kernel between two SIM kernels.
% MULTIKERNCOMPUTEBLOCK
% ARDKERNPARAMINIT ARD kernel parameter initialisation.
% SIMKERNDIAGGRADIENT Compute the gradient of the SIM kernel's diagonal wrt parameters.
% GGXGAUSSIANKERNGRADIENT Compute gradient between the GG and GAUSSIAN kernels.
% KERNSETWHITE Helper function to set the white noise in a kernel if it exists.
% RBFARDKERNGRADIENT Gradient of RBFARD kernel's parameters.
% RBFARDKERNDIAGGRADX Gradient of RBFARD kernel's diagonal with respect to X.
% GGKERNPARAMINIT GG kernel parameter initialisation.
% ARDKERNCOMPUTE Compute the ARD kernel given the parameters and X.
% BIASKERNDISPLAY Display parameters of the BIASkernel.
% GGKERNCOMPUTE Compute the GG kernel given the parameters and X.
% GIBBSKERNGRADIENT Gradient of GIBBS kernel's parameters.
% GIBBSPERIODICKERNEXPANDPARAM Create kernel structure from GIBBSPERIODIC kernel's parameters.
% POLYARDKERNDIAGGRADX Gradient of POLYARD kernel's diagonal with respect to X.
% RBFKERNGRADX Gradient of RBF kernel with respect to input locations.
% MULTIKERNCOMPUTE Compute the MULTI kernel given the parameters and X.
% TRANSLATEKERNPARAMINIT TRANSLATE kernel parameter initialisation.
% BIASKERNDIAGCOMPUTE Compute diagonal of BIAS kernel.
% LFMXRBFKERNGRADIENT Compute gradient between the LFM and RBF kernels.
% KERNDIAGGRADX Compute the gradient of the  kernel wrt X.
% DISIMKERNEXPANDPARAM Create kernel structure from DISIM kernel's parameters.
% BIASKERNPARAMINIT BIAS kernel parameter initialisation.
% BIASKERNDIAGGRADX Gradient of BIAS kernel's diagonal with respect to X.
% TENSORKERNSETINDEX Set the indices in the tensor kernel.
% MATERN52KERNEXTRACTPARAM Extract parameters from the MATERN52 kernel structure.
% WHITEFIXEDKERNPARAMINIT WHITEFIXED kernel parameter initialisation.
% SIMKERNDISPLAY Display parameters of the SIM kernel.
% LINKERNCOMPUTE Compute the LIN kernel given the parameters and X.
% WHITEKERNCOMPUTE Compute the WHITE kernel given the parameters and X.
% GGKERNEXTRACTPARAM Extract parameters from the GG kernel structure.
% LFMGRADIENTH32 Gradient of the function h_i(z) with respect to some of the
% ARDKERNDIAGGRADIENT Compute the gradient of the ARD kernel's diagonal wrt parameters.
% MLPKERNPARAMINIT MLP kernel parameter initialisation.
% LFMCOMPUTEUPSILON Helper function for comptuing part of the LFM kernel.
% LFMGRADIENTH42 Gradient of the function h_i(z) with respect to some of the
% FILEKERNEXPANDPARAM Create kernel structure from FILE kernel's parameters.
% FILEKERNPARAMINIT FILE kernel parameter initialisation.
% MLPARDKERNEXTRACTPARAM Extract parameters from the MLPARD kernel structure.
% SIMKERNCOMPUTE Compute the SIM kernel given the parameters and X.
% ARDKERNDISPLAY Display parameters of the ARD kernel.
% MATERN52KERNDISPLAY Display parameters of the MATERN52 kernel.
% CMPNDKERNDIAGCOMPUTE Compute diagonal of CMPND kernel.
% MULTIKERNEXPANDPARAM Create kernel structure from MULTI kernel's parameters.
% SQEXPKERNPARAMINIT SQEXP kernel parameter initialisation.
% KERNFACTORS Extract factors associated with transformed optimisation space.
% LFMKERNGRADX Gradient of LFM kernel with respect to a point x.
% RATQUADKERNDISPLAY Display parameters of the RATQUAD kernel.
% DISIMXRBFKERNGRADIENT Compute gradient between the DISIM and RBF kernels.
% GIBBSPERIODICKERNDIAGGRADX Gradient of GIBBSPERIODIC kernel's diagonal with respect to X.
% ARDKERNEXPANDPARAM Create kernel structure from ARD kernel's parameters.
% KERNTEST Run some tests on the specified kernel.
% WHITEKERNGRADX Gradient of WHITE kernel with respect to input locations.
% SIMCOMPUTEH Helper function for comptuing part of the SIM kernel.
% POLYARDKERNPARAMINIT POLYARD kernel parameter initialisation.
% LFMKERNEXPANDPARAM Create kernel structure from LFM kernel's parameters.
% RBFKERNEXTRACTPARAM Extract parameters from the RBF kernel structure.
% MATERN52KERNGRADX Gradient of MATERN52 kernel with respect to input locations.
% KERNWRITEPARAMSTOFID Write the kernel parameters to a stream.
% RBFPERIODICKERNDISPLAY Display parameters of the RBFPERIODIC kernel.
% DISIMKERNDIAGCOMPUTE Compute diagonal of DISIM kernel.
% POLYARDKERNDISPLAY Display parameters of the POLYARD kernel.
% SIMCOMPUTETEST Test the file simComputeH.
% POLYKERNDIAGGRADX Gradient of POLY kernel's diagonal with respect to X.
% LINARDKERNDISPLAY Display parameters of the LINARD kernel.
% TENSORKERNSLASH Tensor kernel created by removing ith component.
% RBFPERIODICKERNEXTRACTPARAM Extract parameters from the RBFPERIODIC kernel structure.
% KERNTOOLBOXES Load in the relevant toolboxes for kern.
% WHITEFIXEDKERNDIAGGRADX Gradient of WHITEFIXED kernel's diagonal with respect to X.
% LINKERNGRADIENT Gradient of LIN kernel's parameters.
% POLYKERNPARAMINIT POLY kernel parameter initialisation.
% LFMKERNGRADIENT Gradient of LFM kernel's parameters.
% SQEXPKERNDIAGGRADIENT Compute the gradient of the SQEXP kernel's diagonal wrt parameters.
% GAUSSIANKERNDIAGCOMPUTE Compute diagonal of gaussian kernel.
% MULTIKERNGRADX Gradient of MULTI kernel with respect to a point x.
% LFMGRADIENTUPSILON Gradient of the function \upsilon(z) with respect to
% RBFARDKERNDIAGGRADIENT Compute the gradient of the RBFARD kernel's diagonal wrt parameters.
% LINARDKERNCOMPUTE Compute the LINARD kernel given the parameters and X.
% SQEXPKERNCOMPUTE Compute the SQEXP kernel given the parameters and X.
% LFMKERNDISPLAY Display parameters of the LFM kernel.
% LFMCOMPUTEH Helper function for computing part of the LFM kernel.
% LFMEXTRACTPARAM Extract the parameters of an LFM model.
% FILEKERNREAD Read kernel values from file or cache.
% SIMKERNEXPANDPARAM Create kernel structure from SIM kernel's parameters.
% RBFPERIODICKERNDIAGGRADIENT Compute the gradient of the RBFPERIODIC kernel's diagonal wrt parameters.
% GGXGAUSSIANKERNGRADX Compute gradient between the GG and GAUSSIAN
% TENSORKERNCOMPUTE Compute the TENSOR kernel given the parameters and X.
% GIBBSKERNCOMPUTE Compute the GIBBS kernel given the parameters and X.
% LINKERNPARAMINIT LIN kernel parameter initialisation.
% WHITEKERNEXPANDPARAM Create kernel structure from WHITE kernel's parameters.
% RATQUADKERNDIAGCOMPUTE Compute diagonal of RATQUAD kernel.
% SQEXPKERNEXPANDPARAM Create kernel structure from SQEXP kernel's parameters.
% DISIMKERNDISPLAY Display parameters of the DISIM kernel.
% GAUSSIANKERNCOMPUTE Compute the Gaussian kernel given the parameters and X.
% MATERN32KERNDIAGGRADX Gradient of MATERN32 kernel's diagonal with respect to X.
% KERNGETVARIANCE Get the signal associated with a the kernel.
% CMPNDKERNGRADX Gradient of CMPND kernel with respect to a point x.
% GIBBSKERNEXPANDPARAM Create kernel structure from GIBBS kernel's parameters.
% SIMKERNGRADX Gradient of SIM kernel with respect to a point x.
% LFMTEST Test the gradients of the LFM model.
% POLYARDKERNGRADIENT Gradient of POLYARD kernel's parameters.
% GIBBSKERNEXTRACTPARAM Extract parameters from the GIBBS kernel structure.
% RBFPERIODICKERNGRADIENT Gradient of RBFPERIODIC kernel's parameters.
% LFMSAMPLE Sample from LFM kernel
% SQEXPKERNDIAGCOMPUTE Compute diagonal of SQEXP kernel.
% GGXGGKERNCOMPUTE Compute a cross kernel between two GG kernels.
% LINARDKERNPARAMINIT LINARD kernel parameter initialisation.
% POLYARDKERNCOMPUTE Compute the POLYARD kernel given the parameters and X.
% LFMCOMPUTEH4 Helper function for computing part of the LFM kernel.
% LFMGRADIENTSIGMAH4 Gradient of the function h_i(z) with respect \sigma.
% WHITEFIXEDKERNGRADIENT Gradient of WHITEFIXED kernel's parameters.
% WHITEKERNPARAMINIT WHITE kernel parameter initialisation.
% SIMXSIMKERNGRADIENT Compute a cross gradient between two SIM kernels.
% LFMKERNDIAGGRADX Gradient of LFM kernel's diagonal with respect to X.
% TRANSLATEKERNCOMPUTE Compute the TRANSLATE kernel given the parameters and X.
% LFMKERNDIAGGRADIENT Compute the gradient of the LFM kernel's diagonal wrt parameters.
% RBFPERIODICKERNDIAGGRADX Gradient of RBFPERIODIC kernel's diagonal with respect to X.
% ARDKERNDIAGGRADX Gradient of ARD kernel's diagonal with respect to X.
% LINARDKERNEXPANDPARAM Create kernel structure from LINARD kernel's parameters.
% WHITEFIXEDKERNDISPLAY Display parameters of the WHITEFIXED kernel.
% EXPKERNDISPLAY Display parameters of the EXP kernel.
% KERNDISPLAY Display the parameters of the kernel.
% GGKERNDIAGCOMPUTE Compute diagonal of GG kernel.
% KERNPRIORGRADIENT Compute gradient terms associated with kernel priors.
% GGXGGKERNGRADIENT Compute a cross gradient between two GG kernels.
% KERNDIAGCOMPUTE Compute the kernel given the parameters and X.
% RBFKERNDISPLAY Display parameters of the RBF kernel.
% DISIMXRBFKERNCOMPUTE Compute a cross kernel between the DISIM and RBF kernels.
% SQEXPKERNEXTRACTPARAM Extract parameters from the SQEXP kernel structure.
% MATERN32KERNDISPLAY Display parameters of the MATERN32 kernel.
% SPARSEKERNDISPLAY Display parameters of the SPARSE kernel.
% MLPARDKERNDIAGCOMPUTE Compute diagonal of MLPARD kernel.
% CMPNDKERNEXPANDPARAM Create kernel structure from CMPND kernel's parameters.
% POLYKERNGRADX Gradient of POLY kernel with respect to input locations.
% GIBBSPERIODICKERNCOMPUTE Compute the GIBBSPERIODIC kernel given the parameters and X.
% TENSORKERNDIAGCOMPUTE Compute diagonal of TENSOR kernel.
% LFMCREATE Create a LFM model.
% LFMGRADIENTH41 Gradient of the function h_i(z) with respect to some of the
% POLYKERNDISPLAY Display parameters of the POLY kernel.
% MATERN32KERNPARAMINIT MATERN32 kernel parameter initialisation.
% LFMXRBFKERNCOMPUTE Compute a cross kernel between the LFM and RBF kernels.
% WHITEFIXEDXWHITEFIXEDKERNGRADIENT Compute a cross gradient between two WHITEFIXED kernels.
% LFMLOGLIKELIHOOD Compute the log likelihood of a LFM model.
% MATERN52KERNDIAGCOMPUTE Compute diagonal of MATERN52 kernel.
% GAUSSIANKERNDIAGGRADIENT Compute the gradient of the gaussian kernel's diagonal wrt parameters.
% LFMKERNEXTRACTPARAM Extract parameters from the LFM kernel structure.
% GAUSSIANKERNDIAGGRADX Gradient of gaussian kernel's diagonal with respect to X.
% MLPARDKERNPARAMINIT MLPARD kernel parameter initialisation.
% CMPNDKERNDISPLAY Display parameters of the CMPND kernel.
% RBFPERIODICKERNDIAGCOMPUTE Compute diagonal of RBFPERIODIC kernel.
% EXPKERNEXTRACTPARAM Extract parameters from the EXP kernel structure.
% MULTIKERNDIAGGRADIENT Compute the gradient of the MULTI kernel's diagonal wrt parameters.
% LFMLOGLIKEGRADIENTS Compute the gradients of the log likelihood of a LFM model.
% ARDKERNDIAGCOMPUTE Compute diagonal of ARD kernel.
% MATERN52KERNDIAGGRADIENT Compute the gradient of the MATERN52 kernel's diagonal wrt parameters.
% ARDKERNGRADX Gradient of ARD kernel with respect to a point x.
% MATERN52KERNEXPANDPARAM Create kernel structure from MATERN52 kernel's parameters.
% COMPUTEKERNEL Compute the kernel given the parameters and X.
% MULTIKERNTEST Run some tests on the multiple output block kernel.
% POLYARDKERNDIAGCOMPUTE Compute diagonal of POLYARD kernel.
% PSKERNELGRADIENT Gradient on likelihood approximation for point set IVM.
% KERNCORRELATION Compute the correlation matrix kernel given the parameters and X.
% FILEKERNDISPLAY Display parameters of the FILE kernel.
% WHITEKERNDIAGCOMPUTE Compute diagonal of WHITE kernel.
% CMPNDKERNDIAGGRADX Gradient of CMPND kernel's diagonal with respect to X.
% MLPARDKERNEXPANDPARAM Create kernel structure from MLPARD kernel's parameters.
% LINKERNDIAGCOMPUTE Compute diagonal of LIN kernel.
% GAUSSIANKERNEXTRACTPARAM Extract parameters from the gaussian kernel structure.
% MULTIKERNDIAGCOMPUTE Compute diagonal of MULTI kernel.
% MLPARDKERNGRADX Gradient of MLPARD kernel with respect to input locations.
% MATERN52KERNGRADIENT Gradient of MATERN52 kernel's parameters.
% LFMKERNCOMPUTE Compute the LFM kernel given the parameters and X.
% TRANSLATEKERNDIAGGRADX Gradient of TRANSLATE kernel's diagonal with respect to X.
% MATERN32KERNDIAGCOMPUTE Compute diagonal of MATERN32 kernel.
% GIBBSPERIODICKERNDISPLAY Display parameters of the GIBBSPERIODIC kernel.
% BIASKERNGRADX Gradient of BIAS kernel with respect to input locations.
% FILEKERNGRADX Gradient of FILE kernel with respect to a point x.
% GAUSSIANKERNGRADX Gradient of gaussian kernel with respect to input locations.
% KERNPRIORLOGPROB Compute penalty terms associated with kernel priors.
% GIBBSPERIODICKERNGRADX Gradient of GIBBSPERIODIC kernel with respect to a point x.
% LINKERNGRADX Gradient of LIN kernel with respect to input locations.
% COMPONENTKERNWRITEPARAMSTOFID Write a component based kernel to a stream.
% LINARDKERNDIAGCOMPUTE Compute diagonal of LINARD kernel.
% RBFPERIODICKERNCOMPUTE Compute the RBFPERIODIC kernel given the parameters and X.
% TENSORKERNDIAGGRADIENT Compute the gradient of the TENSOR kernel's diagonal wrt parameters.
% MLPKERNGRADX Gradient of MLP kernel with respect to input locations.
% CMPNDKERNSETINDEX Set the indices in the compound kernel.
% EXPKERNDIAGGRADX Gradient of EXP kernel's diagonal with respect to X.
% CMPNDKERNPARAMINIT CMPND kernel parameter initialisation.
% DISIMKERNDIAGGRADX Gradient of DISIM kernel's diagonal with respect to X.
% RBFKERNCOMPUTE Compute the RBF kernel given the parameters and X.
% BIASKERNEXPANDPARAM Create kernel structure from BIAS kernel's parameters.
% MATERN32KERNEXTRACTPARAM Extract parameters from the MATERN32 kernel structure.
% RBFARDKERNDISPLAY Display parameters of the RBFARD kernel.
% POLYKERNEXTRACTPARAM Extract parameters from the POLY kernel structure.
% ARDKERNGRADIENT Gradient of ARD kernel's parameters.
% MULTIKERNGRADIENT Gradient of MULTI kernel's parameters.
% LFMKERNPARAMINIT LFM kernel parameter initialisation.
% CMPNDKERNCOMPUTE Compute the CMPND kernel given the parameters and X.
% MULTIKERNPARAMINIT MULTI kernel parameter initialisation.
% DISIMXSIMKERNGRADIENT Compute gradient between the DISIM and SIM kernels.
% WHITEFIXEDKERNDIAGGRADIENT Compute the gradient of the WHITEFIXED kernel's diagonal wrt parameters.
% SIMKERNGRADIENT Gradient of SIM kernel's parameters.
% DISIMKERNGRADX Gradient of DISIM kernel with respect to a point x.
% MLPARDKERNCOMPUTE Compute the MLPARD kernel given the parameters and X.
% WHITEFIXEDKERNDIAGCOMPUTE Compute diagonal of WHITEFIXED kernel.
% KERNWRITETOFID Load from an FID written by the C++ implementation.
% WHITEKERNEXTRACTPARAM Extract parameters from the WHITE kernel structure.
% GIBBSPERIODICKERNDIAGCOMPUTE Compute diagonal of GIBBSPERIODIC kernel.
% DISIMKERNCOMPUTE Compute the DISIM kernel given the parameters and X.
% KERNGRADIENT Compute the gradient wrt the kernel's parameters.
% RBFKERNPARAMINIT RBF kernel parameter initialisation.
% KERNEXTRACTPARAM Extract parameters from kernel structure.
% GIBBSPERIODICKERNDIAGGRADIENT Compute the gradient of the GIBBSPERIODIC kernel's diagonal wrt parameters.
% SIMXRBFKERNGRADIENT Compute gradient between the SIM and RBF kernels.
% MLPARDKERNDISPLAY Display parameters of the MLPARD kernel.
% EXPKERNGRADIENT Gradient of EXP kernel's parameters.
% LFMCOMPUTEH3 Helper function for computing part of the LFM kernel.
% TENSORKERNPARAMINIT TENSOR kernel parameter initialisation.
% GAUSSIANKERNDISPLAY Display parameters of the GAUSSIAN kernel.
% LFMGRADIENTSIGMAUPSILON Gradient of the function \upsilon(z) with respect
% WHITEXWHITEKERNGRADIENT Compute a cross gradient between two WHITE kernels.
% TENSORKERNEXPANDPARAM Create kernel structure from TENSOR kernel's parameters.
% RATQUADKERNGRADX Gradient of RATQUAD kernel with respect to input locations.
% GGKERNDISPLAY Display parameters of the GG kernel.
% RBFPERIODICKERNEXPANDPARAM Create kernel structure from RBFPERIODIC kernel's parameters.
% GIBBSKERNPARAMINIT GIBBS kernel parameter initialisation.
% KERNPARAMINIT Kernel parameter initialisation.
% TRANSLATEKERNEXPANDPARAM Create kernel structure from TRANSLATE kernel's parameters.
% GAUSSIANKERNEXPANDPARAM Create kernel structure from gaussian kernel's parameters.
% MULTIKERNGRADIENTBLOCK
% TRANSLATEKERNGRADIENT Gradient of TRANSLATE kernel's parameters.
% SIMXRBFKERNCOMPUTE Compute a cross kernel between the SIM and RBF kernels.
% MATERN52KERNPARAMINIT MATERN52 kernel parameter initialisation.
% MATERN52KERNCOMPUTE Compute the MATERN52 kernel given the parameters and X.
% BIASKERNEXTRACTPARAM Extract parameters from the BIAS kernel structure.
% MULTIKERNDIAGGRADX Gradient of MULTI kernel's diagonal with respect to X.
% WHITEKERNDIAGGRADX Gradient of WHITE kernel's diagonal with respect to X.
% TRANSLATEKERNDISPLAY Display parameters of the TRANSLATE kernel.
% SIMKERNPARAMINIT SIM kernel parameter initialisation.
% FILEKERNGRADIENT Gradient of FILE kernel's parameters.
% RBFARDKERNCOMPUTE Compute the RBFARD kernel given the parameters and X.
% KERNREADFROMFID Load from an FID written by the C++ implementation.
% DISIMKERNDIAGGRADIENT Compute the gradient of the DISIM kernel's diagonal wrt parameters.
% DISIMCOMPUTEH Helper function for comptuing part of the DISIM kernel.
% GGKERNGRADIENT Gradient of GG kernel's parameters.
% MLPKERNDIAGCOMPUTE Compute diagonal of MLP kernel.
% RBFARDKERNEXPANDPARAM Create kernel structure from RBFARD kernel's parameters.
% KERNSETINDEX Set the indices on a compound kernel.
% EXPKERNGRADX Gradient of EXP kernel with respect to a point x.
% GAUSSIANKERNGRADIENT Gradient of gaussian kernel's parameters.
% LFMEXPANDPARAM Expand the given parameters into a LFM structure.
% LINKERNDIAGGRADX Gradient of LIN kernel's diagonal with respect to X.
% LINARDKERNDIAGGRADX Gradient of LINARD kernel's diagonal with respect to X.
% SIMKERNDIAGGRADX Gradient of SIM kernel's diagonal with respect to X.
% EXPKERNDIAGCOMPUTE Compute diagonal of EXP kernel.
% LFMCOMPUTETEST Test the file lfmComputeH.
% KERNGRADX Compute the gradient of the kernel wrt X.
% FILEKERNEXTRACTPARAM Extract parameters from the FILE kernel structure.
% LINARDKERNGRADIENT Gradient of LINARD kernel's parameters.
% GAUSSIANKERNPARAMINIT Gaussian kernel parameter initialisation.
% POLYKERNGRADIENT Gradient of POLY kernel's parameters.
% RBFKERNDIAGGRADX Gradient of RBF kernel's diagonal with respect to X.
% MULTIKERNEXTRACTPARAM Extract parameters from the MULTI kernel structure.
% RBFARDKERNPARAMINIT RBFARD kernel parameter initialisation.
% WHITEXWHITEKERNCOMPUTE Compute a cross kernel between two WHITE kernels.
% RATQUADKERNEXTRACTPARAM Extract parameters from the RATQUAD kernel structure.
% GIBBSPERIODICKERNEXTRACTPARAM Extract parameters from the GIBBSPERIODIC kernel structure.
% SQEXPKERNDISPLAY Display parameters of the SQEXP kernel.
% BIASKERNCOMPUTE Compute the BIAS kernel given the parameters and X.
% CMPNDKERNGRADIENT Gradient of CMPND kernel's parameters.
% FILEKERNCOMPUTE Compute the FILE kernel given the parameters and X.
% MATERN52KERNDIAGGRADX Gradient of MATERN52 kernel's diagonal with respect to X.
% GIBBSKERNGRADX Gradient of GIBBS kernel with respect to input locations.
% CMPNDKERNDIAGGRADIENT Compute the gradient of the CMPND kernel's diagonal wrt parameters.
% GIBBSKERNDIAGGRADIENT Compute the gradient of the GIBBS kernel's diagonal wrt parameters.
% MLPKERNEXPANDPARAM Create kernel structure from MLP kernel's parameters.
% TRANSLATEKERNEXTRACTPARAM Extract parameters from the TRANSLATE kernel structure.
% GIBBSPERIODICKERNPARAMINIT GIBBSPERIODIC kernel parameter initialisation.
% LFMGRADIENTH31 Gradient of the function h_i(z) with respect to some of the
% LFMXLFMKERNGRADIENT Compute a cross gradient between two LFM kernels.
% KERNEXPANDPARAM Expand parameters to form a kernel structure.
% WHITEKERNDISPLAY Display parameters of the WHITEkernel.
% RBFKERNDIAGCOMPUTE Compute diagonal of RBF kernel.
% MULTIKERNDISPLAY Display parameters of the MULTI kernel.
% WHITEKERNDIAGGRADIENT Compute the gradient of the WHITE kernel's diagonal wrt parameters.
% GIBBSKERNDIAGGRADX Gradient of GIBBS kernel's diagonal with respect to X.
% PSKERNELOBJECTIVE Likelihood approximation for point set IVM.
% RBFARDKERNDIAGCOMPUTE Compute diagonal of RBFARD kernel.
% LINKERNEXTRACTPARAM Extract parameters from the LIN kernel structure.
% RBFKERNEXPANDPARAM Create kernel structure from RBF kernel's parameters.
% POLYARDKERNGRADX Gradient of POLYARD kernel with respect to input locations.
% LINARDKERNGRADX Gradient of LINARD kernel with respect to input locations.
