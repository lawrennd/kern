function kernDisplay(kern, varargin)

% KERNDISPLAY Display the parameters of the kernel.
%
%	Description:
%
%	KERNDISPLAY displays the parameters of the kernel and the kernel
%	type to the console.% ARG kern : the kernel to display.
%
%	KERNDISPLAY(KERN, SPACING)
%	 Arguments:
%	  KERN - the kernel to display.
%	  SPACING - how many spaces to indent the display of the kernel by.
%
%	See also
%	% SEEALSO MODELDISPLAY


%	Copyright (c) 2006 Neil D. Lawrence
% 	kernDisplay.m version 1.6


fhandle = str2func([kern.type 'KernDisplay']);
fhandle(kern, varargin{:});