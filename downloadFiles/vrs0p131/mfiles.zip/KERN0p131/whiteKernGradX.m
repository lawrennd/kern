function gX = whiteKernGradX(kern, X, X2)

% WHITEKERNGRADX Gradient of white noise kernel with respect to a point x.
%
% gX = whiteKernGradX(kern, X, X2)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.3, Sat Jan  1 11:42:12 2005
% KERN toolbox version 0.131



gX = zeros(size(X2, 1), size(X2, 2), size(X, 1));
