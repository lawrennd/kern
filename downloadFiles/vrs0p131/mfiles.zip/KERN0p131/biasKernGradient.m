function g = biasKernGradient(kern, x, covGrad)

% BIASKERNGRADIENT Gradient of bias kernel's parameters.
%
% g = biasKernGradient(kern, x, covGrad)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.3, Wed Aug 18 15:52:35 2004
% KERN toolbox version 0.131



g = sum(sum(covGrad));
