function mlpKernDisplay(kern)

% MLPKERNDISPLAY Display parameters of multi-layer perceptron kernel.
%
% mlpKernDisplay(kern)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.3, Sun May 29 10:45:32 2005
% KERN toolbox version 0.131



fprintf('MLP kernel Variance: %2.4f\n', kern.variance)
fprintf('MLP weight variance: %2.4f\n', kern.weightVariance)
fprintf('MLP bias variance: %2.4f\n', kern.biasVariance)