function kernDisplay(kern)

% KERNDISPLAY Display the parameters of the kernel.
%
% kernDisplay(kern)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.3, Tue Feb  8 21:51:45 2005
% KERN toolbox version 0.131



feval([kern.type 'KernDisplay'], kern)