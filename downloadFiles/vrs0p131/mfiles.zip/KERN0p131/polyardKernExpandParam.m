function kern = polyardKernExpandParam(kern, params)

% POLYARDKERNEXPANDPARAM Create kernel structure from polynomial ARD's parameters.
%
% kern = polyardKernExpandParam(kern, params)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.1, Sat Jul 23 05:16:36 2005
% KERN toolbox version 0.131



kern.weightVariance = params(1);
kern.biasVariance = params(2);
kern.variance = params(3);
kern.inputScales = params(4:end);
