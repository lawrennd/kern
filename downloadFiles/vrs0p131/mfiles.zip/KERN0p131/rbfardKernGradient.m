function g = rbfardKernGradient(kern, x, covGrad)

% RBFARDKERNGRADIENT Gradient of radial basis function ARD kernel's parameters.
%
% g = rbfardKernGradient(kern, x, covGrad)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.3, Sat May  7 16:03:19 2005
% KERN toolbox version 0.131



g = zeros(1, size(x, 2)+2);
[k, dist2xx] = rbfardKernCompute(kern, x);
covGradK = covGrad.*k;
g(1) = - .5*sum(sum(covGradK.*dist2xx));
g(2) =  sum(sum(covGrad.*k))/kern.variance;

for i = 1:size(x, 2)
  g(2 + i)  =  -(sum(covGradK*(x(:, i).*x(:, i))) ...
                 -x(:, i)'*covGradK*x(:, i))*kern.inverseWidth;
end
