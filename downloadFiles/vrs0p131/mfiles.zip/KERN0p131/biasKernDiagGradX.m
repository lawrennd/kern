function gX = biasKernDiagGradX(kern, X)

% BIASKERNDIAGGRADX Gradient of bias kernel's diagonal with respect to a point X.
%
% gX = biasKernDiagGradX(kern, X)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.3, Sat Jan  1 13:11:53 2005
% KERN toolbox version 0.131



gX = zeros(size(X));