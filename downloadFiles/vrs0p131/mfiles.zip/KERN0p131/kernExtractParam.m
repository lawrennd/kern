function [params, names] = kernExtractParam(kern)

% KERNEXTRACTPARAM Extract parameters from kernel structure.
%
% [params, names] = kernExtractParam(kern)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.4, Sat Jan  1 17:05:37 2005
% KERN toolbox version 0.131



fhandle = str2func([kern.type 'KernExtractParam']);
params = fhandle(kern);
names = cell(size(params));

% Check if parameters are being optimised in a transformed space.
if ~isempty(kern.transforms)
  for i = 1:length(kern.transforms)
    index = kern.transforms(i).index;
    fhandle = str2func([kern.transforms(i).type 'Transform']);
    params(index) = fhandle(params(index), 'xtoa');
  end
end