function gX = rbfardKernDiagGradX(kern, X)

% RBFARDKERNDIAGGRADX Gradient of radial basis function ARD kernel's diagonal with respect to X.
%
% gX = rbfardKernDiagGradX(kern, X)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.3, Sat Jan  1 13:12:53 2005
% KERN toolbox version 0.131



gX = zeros(size(X));