function kern = mlpKernParamInit(kern)

% MLPKERNPARAMINIT multi-layer perceptron kernel parameter initialisation.
%
% kern = mlpKernParamInit(kern)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.3, Sat Jan  1 17:06:31 2005
% KERN toolbox version 0.131



kern.weightVariance = 10;
kern.biasVariance = 10;
kern.variance = 1;
kern.nParams = 3;

kern.transforms.index = [1 2 3];
kern.transforms.type = 'negLogLogit';
