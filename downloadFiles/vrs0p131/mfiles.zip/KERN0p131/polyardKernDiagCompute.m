function k = polyardKernDiagCompute(kern, x)

% POLYARDKERNDIAGCOMPUTE Compute diagonal of multi-layer perceptron ARD kernel.
%
% k = polyardKernDiagCompute(kern, x)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.1, Sat Jul 23 05:16:36 2005
% KERN toolbox version 0.131



scales = sparse(diag(sqrt(kern.inputScales)));
x = x*scales;
arg = sum(x.*x, 2)*kern.weightVariance + kern.biasVariance;
k = kern.variance*arg.^kern.degree;
