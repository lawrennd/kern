function params = linardKernExtractParam(kern)

% LINARDKERNEXTRACTPARAM Extract parameters from linear ARD kernel structure.
%
% params = linardKernExtractParam(kern)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.3, Sat May  7 16:03:09 2005
% KERN toolbox version 0.131



params = [kern.variance kern.inputScales];
