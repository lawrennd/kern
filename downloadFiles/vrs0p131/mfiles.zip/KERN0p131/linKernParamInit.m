function kern = linKernParamInit(kern)

% LINKERNPARAMINIT Linear kernel parameter initialisation.
%
% kern = linKernParamInit(kern)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.3, Sat Jan  1 17:06:12 2005
% KERN toolbox version 0.131



kern.variance = 1;
kern.nParams = 1;

kern.transforms.index = 1;
kern.transforms.type = 'negLogLogit';
