function kern = biasKernParamInit(kern)

% BIASKERNPARAMINIT bias kernel parameter initialisation.
%
% kern = biasKernParamInit(kern)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.3, Sat Jan  1 17:04:48 2005
% KERN toolbox version 0.131



kern.variance = exp(-2);
kern.nParams = 1;

kern.transforms.index = 1;
kern.transforms.type = 'negLogLogit';
