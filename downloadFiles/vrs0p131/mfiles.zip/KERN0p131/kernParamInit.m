function kern = kernParamInit(kern)

% KERNPARAMINIT Kernel parameter initialisation.
%
% kern = kernParamInit(kern)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.4, Sat Jan  1 17:08:09 2005
% KERN toolbox version 0.131



fhandle = str2func([kern.type 'KernParamInit']);
% By default don't transform kernel parameters.
kern.transforms = [];
kern = fhandle(kern);
