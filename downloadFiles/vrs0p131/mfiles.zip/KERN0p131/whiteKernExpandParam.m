function kern = whiteKernExpandParam(kern, params)

% WHITEKERNEXPANDPARAM Create kernel structure from white noise's parameters.
%
% kern = whiteKernExpandParam(kern, params)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.3, Fri Feb 11 17:29:08 2005
% KERN toolbox version 0.131



kern.variance = params(1);