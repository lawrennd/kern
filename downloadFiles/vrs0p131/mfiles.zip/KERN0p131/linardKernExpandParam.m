function kern = linardKernExpandParam(kern, params)

% LINARDKERNEXPANDPARAM Create kernel structure from linear ARD's parameters.
%
% kern = linardKernExpandParam(kern, params)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.2, Sat Jun 12 14:29:05 2004
% KERN toolbox version 0.131





kern.variance = params(1);
kern.inputScales = params(2:end);
