function factors = kernFactors(kern, factorType)

% KERNFACTORS Extract factors associated with transformed optimisation space.
%
% factors = kernFactors(kern, factorType)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.1, Wed Jul 27 15:18:42 2005
% KERN toolbox version 0.131



factors.index = [];
factors.val = [];
if ~isempty(kern.transforms)
  fhandle = str2func([kern.type 'KernExtractParam']);
  params = fhandle(kern);
  for i = 1:length(kern.transforms)
    index = kern.transforms(i).index;
    factors.index = [factors.index index];
    fhandle = str2func([kern.transforms(i).type 'Transform']);
    factors.val = [factors.val  ...
        fhandle(params(index), factorType)];
  end
end
