function kern = polyKernExpandParam(kern, params)

% POLYKERNEXPANDPARAM Create kernel structure from polynomial kernel parameters.
%
% kern = polyKernExpandParam(kern, params)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.1, Sat Jul 23 05:16:36 2005
% KERN toolbox version 0.131



kern.weightVariance = params(1);
kern.biasVariance = params(2);
kern.variance = params(3);
