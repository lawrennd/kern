function kern = ardKernExpandParam(kern, params)

% ARDKERNEXPANDPARAM Create kernel structure from ARD parameters.
%
% kern = ardKernExpandParam(kern, params)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.2, Sat Jun 12 14:29:05 2004
% KERN toolbox version 0.131




kern.inverseWidth = params(1);
kern.rbfVariance = params(2);
kern.biasVariance = params(3);
kern.whiteVariance = params(4);
kern.linearVariance = params(5);

kern.inputScales = params(6:end);
