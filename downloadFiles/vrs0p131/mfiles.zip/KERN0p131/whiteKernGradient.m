function g = whiteKernGradient(kern, x, covGrad)

% WHITEKERNGRADIENT Gradient of white noise kernel's parameters.
%
% g = whiteKernGradient(kern, x, covGrad)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.3, Wed Aug 18 15:52:11 2004
% KERN toolbox version 0.131



g = trace(covGrad);
