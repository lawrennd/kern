function G = kernGradientK(kern, x)

% KERNGRADIENTK Compute the gradient of the kernel wrt its parameters.
%
% G = kernGradientK(kern, x)

% Copyright (c) 2005 Neil D. Lawrence
% KERN toolbox version 0.131



G = feval([kern.type 'KernGradientK'], kern, x);
