function k = kernCompute(kern, x, x2)

% KERNCOMPUTE Compute the kernel given the parameters and X.
%
% k = kernCompute(kern, x, x2)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.3, Thu Dec 30 16:45:43 2004
% KERN toolbox version 0.131



fhandle = str2func([kern.type 'KernCompute']);
if nargin < 3
  k = fhandle(kern, x);
else
  k = fhandle(kern, x, x2);
end
