function gX = sqexpKernGradX(kern, X, X2)

% SQEXPKERNGRADX Gradient of squared exponential kernel with respect to X.
%
% gX = sqexpKernGradX(kern, X, X2)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.3, Sat Jan  1 15:04:58 2005
% KERN toolbox version 0.131



gX = zeros(size(X2, 1), size(X2, 2), size(X, 1));
for i = 1:size(X, 1);
  gX(:, :, i) = sqexpKernGradXpoint(kern, X(i, :), X2);
end


function gX = sqexpKernGradXpoint(kern, x, X2)

% SQEXPKERNGRADXPOINT Gradient with respect to one point of x.

gX = zeros(size(X2));
n2 = dist2(X2, x);
wi2 = (.5 .* kern.inverseWidth);
rbfPart = kern.rbfVariance*exp(-n2*wi2);
for i = 1:size(x, 2)
  gX(:, i) = kern.inverseWidth*(X2(:, i) - x(i)).*rbfPart;
end
