function params = polyardKernExtractParam(kern)

% POLYARDKERNEXTRACTPARAM Extract parameters from multi-layer perceptron ARD kernel structure.
%
% params = polyardKernExtractParam(kern)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.1, Sat Jul 23 05:16:36 2005
% KERN toolbox version 0.131



params = [kern.weightVariance kern.biasVariance kern.variance kern.inputScales];
