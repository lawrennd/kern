function k = biasKernCompute(kern, x, x2)

% BIASKERNCOMPUTE Compute the bias kernel given the parameters and X.
%
% k = biasKernCompute(kern, x, x2)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.3, Tue Jan  4 15:19:35 2005
% KERN toolbox version 0.131



if nargin< 3
  k = repmat(kern.variance, size(x, 1), size(x, 1));
else
  k = repmat(kern.variance, size(x, 1), size(x2, 1));
end