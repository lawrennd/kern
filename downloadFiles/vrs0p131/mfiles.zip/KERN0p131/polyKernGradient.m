function g = polyKernGradient(kern, x, covGrad)

% POLYKERNGRADIENT Gradient of polynomial kernel's parameters.
%
% g = polyKernGradient(kern, x, covGrad)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.1, Sat Jul 23 05:16:36 2005
% KERN toolbox version 0.131



innerProd = x*x';
arg = kern.weightVariance*innerProd+kern.biasVariance;
base = kern.variance*kern.degree*arg.^(kern.degree-1);
baseCovGrad = base.*covGrad;


g(1) = sum(sum(innerProd.*baseCovGrad));
g(2) = sum(sum(baseCovGrad));
g(3) = sum(sum(covGrad.*arg.^kern.degree));

