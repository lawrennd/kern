function kern = mlpKernExpandParam(kern, params)

% MLPKERNEXPANDPARAM Create kernel structure from multi-layer perceptron's parameters.
%
% kern = mlpKernExpandParam(kern, params)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.3, Tue Nov 30 09:26:55 2004
% KERN toolbox version 0.131




kern.weightVariance = params(1);
kern.biasVariance = params(2);
kern.variance = params(3);
