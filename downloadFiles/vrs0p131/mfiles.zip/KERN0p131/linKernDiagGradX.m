function gX = linKernDiagGradX(kern, X)

% LINKERNDIAGGRADX Gradient of linear kernel's diagonal with respect to X.
%
% gX = linKernDiagGradX(kern, X)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.3, Sat Jan  1 13:14:39 2005
% KERN toolbox version 0.131



gX = 2*X*kern.variance;
