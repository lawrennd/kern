function params = polyKernExtractParam(kern)

% POLYKERNEXTRACTPARAM Extract parameters from polynomial kernel structure.
%
% params = polyKernExtractParam(kern)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.1, Sat Jul 23 05:16:36 2005
% KERN toolbox version 0.131



params = [kern.weightVariance kern.biasVariance kern.variance];

