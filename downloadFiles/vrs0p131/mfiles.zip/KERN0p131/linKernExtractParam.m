function params = linKernExtractParam(kern)

% LINKERNEXTRACTPARAM Extract parameters from linear kernel structure.
%
% params = linKernExtractParam(kern)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.3, Sat May 28 22:22:57 2005
% KERN toolbox version 0.131



params = kern.variance;
