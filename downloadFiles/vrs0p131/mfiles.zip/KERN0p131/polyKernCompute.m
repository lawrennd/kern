function k = polyKernCompute(kern, x, x2)

% POLYKERNCOMPUTE Compute the polynomial kernel given the parameters and X.
%
% k = polyKernCompute(kern, x, x2)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.1, Sat Jul 23 05:16:36 2005
% KERN toolbox version 0.131



if nargin < 3
  k = kern.variance*(x*x'*kern.weightVariance+kern.biasVariance).^kern.degree;
else
  k = kern.variance*(kern.weightVariance*x*x2'+kern.biasVariance).^kern.degree;
end
if issparse(x)
  k = full(k);
end