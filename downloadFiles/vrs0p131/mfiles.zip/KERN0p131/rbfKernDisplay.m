function rbfKernDisplay(kern)

% RBFKERNDISPLAY Display parameters of radial basis function kernel.
%
% rbfKernDisplay(kern)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.3, Wed Feb 16 16:50:48 2005
% KERN toolbox version 0.131




fprintf('RBF Variance: %2.4f\n', kern.variance)
fprintf('RBF inverse width: %2.4f\n', kern.inverseWidth)
