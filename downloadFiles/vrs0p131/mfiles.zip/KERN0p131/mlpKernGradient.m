function g = mlpKernGradient(kern, x, covGrad)

% MLPKERNGRADIENT Gradient of multi-layer perceptron kernel's parameters.
%
% g = mlpKernGradient(kern, x, covGrad)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.3, Wed Aug 18 15:50:32 2004
% KERN toolbox version 0.131



[k, innerProd, arg, denom, numer] = mlpKernCompute(kern, x);
denom3 = denom.*denom.*denom;
vec = diag(innerProd);
base = kern.variance./sqrt(1-arg.*arg);
baseCovGrad = base.*covGrad;


g(1) = sum(sum((innerProd./denom ...
                -.5*numer./denom3...
                .*((kern.weightVariance.*vec+kern.biasVariance+1)*vec' ...
                   + vec*(kern.weightVariance.*vec+kern.biasVariance+1)')).*baseCovGrad));
g(2) = sum(sum((1./denom ...
                -.5*numer./denom3 ...
                .*(repmat(vec, 1, size(vec, 1))*kern.weightVariance...
                   + 2*kern.biasVariance + 2 ...
                   +repmat(vec', size(vec, 1), 1)*kern.weightVariance)).*baseCovGrad));
g(3) = sum(sum(k/kern.variance.*covGrad));

