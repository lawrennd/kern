function whiteKernDisplay(kern)

% WHITEKERNDISPLAY Display parameters of white noise kernel.
%
% whiteKernDisplay(kern)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.3, Fri Feb 11 18:45:44 2005
% KERN toolbox version 0.131



fprintf('White Noise Variance: %2.4f\n', kern.variance)
