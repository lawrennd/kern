function kern = rbfKernExpandParam(kern, params)

% RBFKERNEXPANDPARAM Create kernel structure from rbf parameters.
%
% kern = rbfKernExpandParam(kern, params)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.3, Wed Feb 16 16:52:07 2005
% KERN toolbox version 0.131



kern.inverseWidth = params(1);
kern.variance = params(2);
