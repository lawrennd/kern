function gX = biasKernGradX(kern, X, X2)

% BIASKERNGRADX Gradient of bias kernel with respect to a point x.
%
% gX = biasKernGradX(kern, X, X2)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.3, Sat Jan  1 11:42:21 2005
% KERN toolbox version 0.131



gX = zeros(size(X2, 1), size(X2, 2), size(X, 1));
