function kern = polyKernParamInit(kern)

% POLYKERNPARAMINIT Polynomial kernel parameter initialisation.
%
% kern = polyKernParamInit(kern)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.1, Sat Jul 23 05:16:36 2005
% KERN toolbox version 0.131



kern.variance = 1;
kern.weightVariance = 1;
kern.biasVariance = 1;
kern.degree = 2;
kern.nParams = 3;

kern.transforms.index = [1 2 3];
kern.transforms.type = 'negLogLogit';
