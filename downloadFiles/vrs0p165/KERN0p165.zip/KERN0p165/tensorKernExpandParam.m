function kern = tensorKernExpandParam(kern, params)

% TENSORKERNEXPANDPARAM Create kernel structure from TENSOR kernel's parameters.
%
%	Description:
%
%	KERN = TENSORKERNEXPANDPARAM(KERN, PARAM) returns a tensor product
%	kernel structure filled with the parameters in the given vector.
%	This is used as a helper function to enable parameters to be
%	optimised in, for example, the NETLAB optimisation functions.
%	 Returns:
%	  KERN - kernel structure with the given parameters in the relevant
%	   locations.
%	 Arguments:
%	  KERN - the kernel structure in which the parameters are to be
%	   placed.
%	  PARAM - vector of parameters which are to be placed in the kernel
%	   structure.
%	
%
%	See also
%	TENSORKERNPARAMINIT, TENSORKERNEXTRACTPARAM, KERNEXPANDPARAM


%	Copyright (c) 2006 Neil D. Lawrence
% 	tensorKernExpandParam.m version 1.3



kern = cmpndKernExpandParam(kern, params);