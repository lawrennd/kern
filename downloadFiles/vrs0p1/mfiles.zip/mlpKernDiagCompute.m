function k = mlpKernDiagCompute(kern, x)

% MLPKERNDIAGCOMPUTE Compute diagonal of multi-layer perceptron kernel.
%
% k = mlpKernDiagCompute(kern, x)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 14:29:05 2004
% KERN toolbox version 0.1





numer = sum(x.*x, 2)*kern.weightVariance + kern.biasVariance;
denom = numer+1;
k = kern.variance*asin(numer./denom);
