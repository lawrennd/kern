function gX = ardKernDiagGradX(kern, x)

% ARDKERNDIAGGRADX Gradient of ARD kernel's diagonal with respect to a point x.
%
% gX = ardKernDiagGradX(kern, x)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 14:29:05 2004
% KERN toolbox version 0.1






gX = 2*kern.linearVariance*x.*kern.inputScales;

