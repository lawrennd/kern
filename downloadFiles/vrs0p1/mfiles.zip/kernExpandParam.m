function kern = kernExpandParam(kern, params)

% KERNEXPANDPARAM Expand parameters to form a kernel structure.
%
% kern = kernExpandParam(kern, params)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 14:29:05 2004
% KERN toolbox version 0.1





% Check if parameters are being optimised in a transformed space.
if isfield(kern, 'transforms')
  for i = 1:length(kern.transforms)
    index = kern.transforms(i).index;
    params(index) = feval([kern.transforms(i).type 'Transform'], ...
              params(index), 'atox');
  end
end

kern = feval([kern.type 'KernExpandParam'], kern, params);

