function g = linKernGradient(kern, x, covGrad)

% LINKERNGRADIENT Gradient of lin kernel's parameters.
%
% g = linKernGradient(kern, x, covGrad)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 14:29:05 2004
% KERN toolbox version 0.1





linPart = linKernCompute(kern, x);
g(1) = sum(sum(covGrad.*linPart))/kern.variance;
