function k = sqexpKernDiagCompute(kern, x)

% SQEXPKERNDIAGCOMPUTE Compute diagonal of squared exponential kernel.
%
% k = sqexpKernDiagCompute(kern, x)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 14:29:05 2004
% KERN toolbox version 0.1





rbfPart = ones(size(x, 1), 1);
k = rbfPart*(kern.rbfVariance + kern.whiteVariance) + kern.biasVariance;
