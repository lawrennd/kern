function mlpKernDisplay(kern)

% MLPKERNDISPLAY Display parameters of multi-layer perceptron kernel.
%
% mlpKernDisplay(kern)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 14:29:05 2004
% KERN toolbox version 0.1





fprintf('MLP kernel Variance: %2.4f\n', kern.variance)
fprintf('MLP weight variance: %2.4f\n', kern.weightVariance)
fprintf('MLP bias variance: %2.4f\n', kern.biasVariance)