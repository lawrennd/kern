function k = cmpndKernCompute(kern, x, x2)

% CMPNDKERNCOMPUTE Compute the kernel given the parameters and X.
%
% k = cmpndKernCompute(kern, x, x2)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 14:29:05 2004
% KERN toolbox version 0.1





if nargin > 2
  k = kernCompute(kern.comp{1}, x, x2);
  for i = 2:length(kern.comp)
    k  = k + kernCompute(kern.comp{i}, x, x2);
  end
else
  k  = kernCompute(kern.comp{1}, x);
  for i = 2:length(kern.comp)
    k  = k + kernCompute(kern.comp{i}, x);
  end
end
