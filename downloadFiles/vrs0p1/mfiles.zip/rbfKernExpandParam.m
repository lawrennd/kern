function kern = rbfKernExpandParam(kern, params)

% RBFKERNEXPANDPARAM Create kernel structure from rbf parameters.
%
% kern = rbfKernExpandParam(kern, params)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 14:29:05 2004
% KERN toolbox version 0.1





kern.inverseWidth = params(1);
kern.variance = params(2);
