function k = kernDiagCompute(kern, x, x2)

% KERNELCOMPUTE Compute the kernel given the parameters and X.
%
% k = kernDiagCompute(kern, x, x2)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 14:29:05 2004
% KERN toolbox version 0.1





if nargin < 3
  k = feval([kern.type 'KernDiagCompute'], kern, x);
else
  k = feval([kern.type 'KernDiagCompute'], kern, x, x2);
end
