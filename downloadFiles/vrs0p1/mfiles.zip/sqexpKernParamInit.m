function kern = sqexpKernParamInit(kern)

% SQEXPKERNPARAMINIT squared exponential kernel parameter initialisation.
%
% kern = sqexpKernParamInit(kern)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 14:29:05 2004
% KERN toolbox version 0.1





kern.inverseWidth = 1;
kern.rbfVariance = 1;
kern.whiteVariance = 1; 
kern.biasVariance = 1;
kern.nParams = 4;


kern.transforms(1).index = [1 2 3 4];
kern.transforms(1).type = 'negLogLogit';
