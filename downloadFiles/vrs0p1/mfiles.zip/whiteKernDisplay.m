function whiteKernDisplay(kern)

% WHITEKERNDISPLAY Display parameters of white noise kernel.
%
% whiteKernDisplay(kern)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 14:29:05 2004
% KERN toolbox version 0.1





fprintf('White Noise Variance: %2.4f\n', kern.variance)
