function g = cmpndKernGradient(kern, x, covGrad)

% CMPNDKERNGRADIENT Gradient of compound kernel's parameters.
%
% g = cmpndKernGradient(kern, x, covGrad)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 14:29:05 2004
% KERN toolbox version 0.1





g = zeros(1, kern.nParams);
startVal = 1;
endVal = 0;
for i = 1:length(kern.comp)
  endVal = endVal + kern.comp{i}.nParams;
  g(1, startVal:endVal)  = kernGradient(kern.comp{i}, x, covGrad);
  startVal = endVal + 1;
end
g = g*kern.paramGroups;