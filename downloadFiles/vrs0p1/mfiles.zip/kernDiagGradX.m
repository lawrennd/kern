function k = kernDiagGradX(kern, x, x2)

% KERNDIAGGRADX Compute the gradient of the  kernel wrt X.
%
% k = kernDiagGradX(kern, x, x2)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 14:29:05 2004
% KERN toolbox version 0.1





if nargin < 3
  k = feval([kern.type 'KernDiagGradX'], kern, x);
else
  k = feval([kern.type 'KernDiagGradX'], kern, x, x2);
end
