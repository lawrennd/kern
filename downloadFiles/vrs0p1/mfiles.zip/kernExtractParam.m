function [params, names] = kernExtractParam(kern)

% KERNEXTRACTPARAM Extract parameters from kernel structure.
%
% [params, names] = kernExtractParam(kern)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 14:29:05 2004
% KERN toolbox version 0.1





params = feval([kern.type 'KernExtractParam'], kern);
names = cell(size(params));

% Check if parameters are being optimised in a transformed space.
if isfield(kern, 'transforms')
  for i = 1:length(kern.transforms)
    index = kern.transforms(i).index;
    params(index) = feval([kern.transforms(i).type 'Transform'], ...
              params(index), 'xtoa');
  end
end