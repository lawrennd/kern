function kern = rbfardKernExpandParam(kern, params)

% RBFARDKERNEXPANDPARAM Create kernel structure from radial basis function ARD's parameters.
%
% kern = rbfardKernExpandParam(kern, params)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 14:29:05 2004
% KERN toolbox version 0.1




kern.inverseWidth = params(1);
kern.variance = params(2);
kern.inputScales = params(3:end);
