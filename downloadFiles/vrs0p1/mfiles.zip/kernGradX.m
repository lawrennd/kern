function g = kernGradX(kern, x, x2)

% KERNGRADX Compute the gradient of the  kernel wrt X.
%
% g = kernGradX(kern, x, x2)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 14:29:05 2004
% KERN toolbox version 0.1





if nargin < 3
  g = feval([kern.type 'KernGradX'], kern, x);
else
  g = feval([kern.type 'KernGradX'], kern, x, x2);
end
