function [params, transform] = sqexpKernExtractParam(kern)

% SQEXPKERNEXTRACTPARAM Extract parameters from squared exponential kernel structure.
%
% [params, transform] = sqexpKernExtractParam(kern)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 14:29:05 2004
% KERN toolbox version 0.12





params = [kern.inverseWidth kern.rbfVariance kern.biasVariance ...
          kern.whiteVariance];

