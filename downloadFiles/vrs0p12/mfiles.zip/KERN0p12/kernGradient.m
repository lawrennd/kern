function g = kernGradient(kern, x, covGrad)

% KERNGRADIENT Compute the gradient of the kernel's parameters.
%
% g = kernGradient(kern, x, covGrad)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.3, Wed Jun 23 09:29:57 2004
% KERN toolbox version 0.12



g = feval([kern.type 'KernGradient'], kern, x, covGrad);

% Check if parameters are being optimised in a transformed space.
if isfield(kern, 'transforms')
  params = feval([kern.type 'KernExtractParam'], kern);
  for i = 1:length(kern.transforms)
    index = kern.transforms(i).index;
    g(index) = g(index).* ...
        feval([kern.transforms(i).type 'Transform'], ...
              params(index), 'gradfact');
  end
end

  