function gX = rbfardKernDiagGradX(kern, x)

% RBFARDKERNDIAGGRADX Gradient of radial basis function ARD kernel's diagonal with respect to a point x.
%
% gX = rbfardKernDiagGradX(kern, x)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 14:29:05 2004
% KERN toolbox version 0.12





gX = zeros(size(x));