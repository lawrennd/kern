function k = rbfKernDiagCompute(kern, x)

% RBFKERNDIAGCOMPUTE Compute diagonal of rbf kernel.
%
% k = rbfKernDiagCompute(kern, x)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.3, Mon Jun 14 13:21:42 2004
% KERN toolbox version 0.12



k = repmat(kern.variance, size(x, 1), 1);
