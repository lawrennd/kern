function kern = mlpardKernExpandParam(kern, params)

% MLPARDKERNEXPANDPARAM Create kernel structure from multi-layer perceptron ARD's parameters.
%
% kern = mlpardKernExpandParam(kern, params)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 14:29:05 2004
% KERN toolbox version 0.12





kern.weightVariance = params(1);
kern.biasVariance = params(2);
kern.variance = params(3);
kern.inputScales = params(4:end);
