function gX = cmpndKernDiagGradX(kern, x)

% CMPNDKERNDIAGGRADX Gradient of compound kernel's diagonal with respect to a point x.
%
% gX = cmpndKernDiagGradX(kern, x)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 14:29:05 2004
% KERN toolbox version 0.12





gX = kernDiagGradX(kern.comp{1}, x);
for i = 2:length(kern.comp)
  gX = gX + kernDiagGradX(kern.comp{i}, x);
end
