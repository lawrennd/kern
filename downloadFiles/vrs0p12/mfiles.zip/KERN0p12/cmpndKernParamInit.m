function kern = cmpndKernParamInit(kern)

% CMPNDKERNPARAMINIT Compound kernel parameter initialisation.
%
% kern = cmpndKernParamInit(kern)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.3, Mon Jun 21 15:40:01 2004
% KERN toolbox version 0.12



kern.nParams = 0;
kern.transforms = [];
for i = 1:length(kern.comp)
  kern.comp{i} = kernParamInit(kern.comp{i});
  kern.nParams = kern.nParams + kern.comp{i}.nParams;
end
kern.paramGroups = speye(kern.nParams);

