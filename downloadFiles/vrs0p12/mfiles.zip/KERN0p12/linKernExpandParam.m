function kern = linKernExpandParam(kern, params)

% LINKERNEXPANDPARAM Create kernel structure from linear kernel parameters.
%
% kern = linKernExpandParam(kern, params)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 14:29:05 2004
% KERN toolbox version 0.12




kern.variance = params(1);
