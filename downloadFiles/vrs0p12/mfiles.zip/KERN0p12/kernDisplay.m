function kernDisplay(kern)

% KERNDISPLAY Display the parameters of the kernel.
%
% kernDisplay(kern)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 14:29:05 2004
% KERN toolbox version 0.12





feval([kern.type 'KernDisplay'], kern)