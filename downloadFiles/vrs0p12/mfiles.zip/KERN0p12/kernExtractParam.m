function [params, names] = kernExtractParam(kern)

% KERNEXTRACTPARAM Extract parameters from kernel structure.
%
% [params, names] = kernExtractParam(kern)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.3, Mon Jun 21 13:29:10 2004
% KERN toolbox version 0.12



params = feval([kern.type 'KernExtractParam'], kern);
names = cell(size(params));

% Check if parameters are being optimised in a transformed space.
if isfield(kern, 'transforms')
  for i = 1:length(kern.transforms)
    index = kern.transforms(i).index;
    params(index) = feval([kern.transforms(i).type 'Transform'], ...
              params(index), 'xtoa');
  end
end