function k = whiteKernCompute(kern, x, x2)

% WHITEKERNCOMPUTE Compute the white noise kernel given the parameters and X.
%
% k = whiteKernCompute(kern, x, x2)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 14:29:05 2004
% KERN toolbox version 0.12





if nargin < 3
  k = kern.variance*speye(size(x, 1));
else
  k = spalloc(size(x, 1), size(x2, 1), 0);
end
