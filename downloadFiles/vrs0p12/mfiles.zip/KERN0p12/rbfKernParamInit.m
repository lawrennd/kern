function kern = rbfKernParamInit(kern)

% RBFKERNPARAMINIT RBF kernel parameter initialisation.
%
% kern = rbfKernParamInit(kern)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.3, Thu Jun 17 09:27:51 2004
% KERN toolbox version 0.12



kern.inverseWidth = 1;
kern.variance = 1;
kern.nParams = 2;

kern.transforms.index = [1 2];
kern.transforms.type = 'negLogLogit';
