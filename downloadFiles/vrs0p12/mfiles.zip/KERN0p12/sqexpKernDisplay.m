function sqexpKernDisplay(kern)

% SQEXPKERNDISPLAY Display parameters of squared exponential kernel.
%
% sqexpKernDisplay(kern)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 14:29:05 2004
% KERN toolbox version 0.12





fprintf('RBF Variance: %2.4f\n', kern.rbfVariance)
fprintf('RBF inverse width: %2.4f\n', kern.inverseWidth)
fprintf('White noise Variance: %2.4f\n', kern.whiteVariance)
fprintf('Bias Kernel Variance: %2.4f\n', kern.biasVariance)
