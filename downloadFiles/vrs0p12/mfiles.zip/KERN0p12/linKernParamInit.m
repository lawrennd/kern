function kern = linKernParamInit(kern)

% LINKERNPARAMINIT Linear kernel parameter initialisation.
%
% kern = linKernParamInit(kern)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.3, Thu Jun 17 09:27:58 2004
% KERN toolbox version 0.12



kern.variance = 1;
kern.nParams = 1;

kern.transforms.index = 1;
kern.transforms.type = 'negLogLogit';
