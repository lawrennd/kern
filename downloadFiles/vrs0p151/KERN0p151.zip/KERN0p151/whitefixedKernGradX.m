function gX = whitefixedKernGradX(kern, X, X2)

% WHITEFIXEDKERNGRADX Gradient of white fixed noise kernel with respect to a point x.
%
% gX = whitefixedKernGradX(kern, X, X2)
%

% Copyright (c) 2006 Neil D. Lawrence and Nathaniel J. King
% whitefixedKernGradX.m version 1.1



gX = whiteKernGradX(kern, X, X2);