function k = fileKernDiagCompute(kern, x)

% FILEKERNDIAGCOMPUTE Load the diagonal of a kernel stored in a file.
%
% k = fileKernDiagCompute(kern, x)
%

% Copyright (c) 2006 Neil D. Lawrence and Nathaniel J. King
% fileKernDiagCompute.m version 1.1



k = kern.variance*fileKernRead(kern, x, 'diag');
