function f = pskernelObjective(lntheta, models, prior)

% PSKERNELOBJECTIVE Likelihood approximation for point set IVM.
%
% f = pskernelObjective(lntheta, models, prior)
%

% Copyright (c) 2006 Neil D. Lawrence and Nathaniel J. King
% pskernelObjective.m version 1.2




% PSIVM

if nargin < 3
  prior = 1;
end
f = 0;
numTasks = length(models.task);
for taskNo = 1:numTasks
  models.task(taskNo).lntheta = models.lntheta;
  f = f + kernelObjective(lntheta, models.task(taskNo), prior);
end