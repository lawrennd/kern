function g = biasKernDiagGradient(kern, x, covDiag)

% BIASKERNDIAGGRADIENT Compute the gradient of the bias kernel's diagonal wrt to parameters.
%
% g = biasKernDiagGradient(kern, x, covDiag)
%

% Copyright (c) 2006 Neil D. Lawrence and Nathaniel J. King
% biasKernDiagGradient.m version 1.1



g(1) = sum(covDiag);
