function kern = whitefixedKernParamInit(kern)

% WHITEFIXEDKERNPARAMINIT white noise kernel parameter initialisation.
%
% kern = whitefixedKernParamInit(kern)
%

% Copyright (c) 2006 Neil D. Lawrence and Nathaniel J. King
% whitefixedKernParamInit.m version 1.1



kern.variance = exp(-2);
kern.nParams = 0;

%kern.transforms.index = 0;
%kern.transforms.type = 'negLogLogit';