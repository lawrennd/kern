function [u, v] = kernPca(kern, X, numEig)

% KERNPCA Kernel PCA.
%
% [u, v] = kernPca(kern, X, numEig)
%

% Copyright (c) 2006 Neil D. Lawrence and Nathaniel J. King
% kernPca.m version 



K = kernCompute(kern, X);
[u, v] = eigs(K, numEig);