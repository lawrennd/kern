function gX = sqexpKernDiagGradX(kern, x)

% SQEXPKERNDIAGGRADX Gradient of squared exponential kernel's diagonal with respect to a point x.
%
% gX = sqexpKernDiagGradX(kern, x)
%

% Copyright (c) 2006 Neil D. Lawrence and Nathaniel J. King
% sqexpKernDiagGradX.m version 1.3



gX = zeros(size(x));
