function kern = biasKernParamInit(kern)

% BIASKERNPARAMINIT bias kernel parameter initialisation.
%
% kern = biasKernParamInit(kern)
%

% Copyright (c) 2006 Neil D. Lawrence and Nathaniel J. King
% biasKernParamInit.m version 1.3



kern.variance = exp(-2);
kern.nParams = 1;

kern.transforms.index = 1;
kern.transforms.type = 'negLogLogit';
