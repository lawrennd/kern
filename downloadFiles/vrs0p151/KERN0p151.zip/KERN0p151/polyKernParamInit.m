function kern = polyKernParamInit(kern)

% POLYKERNPARAMINIT Polynomial kernel parameter initialisation.
%
% kern = polyKernParamInit(kern)
%

% Copyright (c) 2006 Neil D. Lawrence and Nathaniel J. King
% polyKernParamInit.m version 1.1



kern.variance = 1;
kern.weightVariance = 1;
kern.biasVariance = 1;
kern.degree = 2;
kern.nParams = 3;

kern.transforms.index = [1 2 3];
kern.transforms.type = 'negLogLogit';
