function [k, n2] = fileKernCompute(kern, varargin)

% FILEKERNCOMPUTE Compute the kernel given the parameters and indices.
%
% [k, n2] = fileKernCompute(kern, varargin)
%

% Copyright (c) 2006 Neil D. Lawrence and Nathaniel J. King
% fileKernCompute.m version 1.1



k = kern.variance*fileKernRead(kern, varargin{:});
