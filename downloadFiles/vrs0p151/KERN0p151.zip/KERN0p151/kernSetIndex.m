function kern = kernSetIndex(kern, component, indices)

% KERNSETINDEX Set the indices on a compound kernel.
%
% kern = kernSetIndex(kern, component, indices)
%

% Copyright (c) 2006 Neil D. Lawrence and Nathaniel J. King
% kernSetIndex.m version 1.1



fhandle = [kern.type 'KernSetIndex'];
if exist(fhandle)==2
  fhandle = str2func(fhandle);
  kern = fhandle(kern, component, indices);
else
  warning(['Setting of indices not possible for ' kern.type ' kernels.']);
end
