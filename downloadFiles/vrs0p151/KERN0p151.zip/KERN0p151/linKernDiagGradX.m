function gX = linKernDiagGradX(kern, X)

% LINKERNDIAGGRADX Gradient of linear kernel's diagonal with respect to X.
%
% gX = linKernDiagGradX(kern, X)
%

% Copyright (c) 2006 Neil D. Lawrence and Nathaniel J. King
% linKernDiagGradX.m version 1.3



gX = 2*X*kern.variance;
