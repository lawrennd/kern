function g = kernGradX(kern, x, x2)

% KERNGRADX Compute the gradient of the  kernel wrt X.
%
% g = kernGradX(kern, x, x2)
%

% Copyright (c) 2006 Neil D. Lawrence and Nathaniel J. King
% kernGradX.m version 1.3



fhandle = str2func([kern.type 'KernGradX']);
if nargin < 3
  g = fhandle(kern, x);
else
  g = fhandle(kern, x, x2);
end
