function g = whiteKernDiagGradient(kern, x, covDiag)

% WHITEKERNDIAGGRADIENT Compute the gradient of the white kernel's diagonal wrt to parameters.
%
% g = whiteKernDiagGradient(kern, x, covDiag)
%

% Copyright (c) 2006 Neil D. Lawrence and Nathaniel J. King
% whiteKernDiagGradient.m version 1.1



g(1) = sum(covDiag);
