function g = whitefixedKernDiagGradient(kern, x, covDiag)

% WHITEFIXEDKERNDIAGGRADIENT Compute the gradient of the whitefixed kernel's diagonal wrt to parameters.
%
% g = whitefixedKernDiagGradient(kern, x, covDiag)
%

% Copyright (c) 2006 Neil D. Lawrence and Nathaniel J. King
% whitefixedKernDiagGradient.m version 1.1



g = [];
