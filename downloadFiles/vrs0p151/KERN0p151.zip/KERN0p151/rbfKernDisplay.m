function rbfKernDisplay(kern, spacing)

% RBFKERNDISPLAY Display parameters of radial basis function kernel.
%
% rbfKernDisplay(kern, spacing)
%

% Copyright (c) 2006 Neil D. Lawrence and Nathaniel J. King
% rbfKernDisplay.m version 1.4



if nargin > 1
  spacing = repmat(32, 1, spacing);
else
  spacing = [];
end
spacing = char(spacing);
fprintf(spacing);
fprintf('RBF Variance: %2.4f\n', kern.variance)
fprintf(spacing);
fprintf('RBF inverse width: %2.4f\n', kern.inverseWidth)
