function k = kernDiagGradX(kern, x)

% KERNDIAGGRADX Compute the gradient of the  kernel wrt X.
%
% k = kernDiagGradX(kern, x)
%

% Copyright (c) 2006 Neil D. Lawrence and Nathaniel J. King
% kernDiagGradX.m version 1.5



fhandle = str2func([kern.type 'KernDiagGradX']);
k = fhandle(kern, x);
