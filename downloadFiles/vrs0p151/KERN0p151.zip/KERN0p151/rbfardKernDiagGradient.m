function g = rbfardKernDiagGradient(kern, x, covDiag)

% RBFARDKERNDIAGGRADIENT Compute the gradient of the RBFARD kernel's diagonal wrt to parameters.
%
% g = rbfardKernDiagGradient(kern, x, covDiag)
%

% Copyright (c) 2006 Neil D. Lawrence and Nathaniel J. King
% rbfardKernDiagGradient.m version 1.1



g = zeros(1, size(x, 2)+2);
g(2) = sum(covDiag);