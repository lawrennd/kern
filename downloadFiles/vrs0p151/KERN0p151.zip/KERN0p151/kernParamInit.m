function kern = kernParamInit(kern)

% KERNPARAMINIT Kernel parameter initialisation.
%
% kern = kernParamInit(kern)
%

% Copyright (c) 2006 Neil D. Lawrence and Nathaniel J. King
% kernParamInit.m version 1.4



fhandle = str2func([kern.type 'KernParamInit']);
% By default don't transform kernel parameters.
kern.transforms = [];
kern = fhandle(kern);
