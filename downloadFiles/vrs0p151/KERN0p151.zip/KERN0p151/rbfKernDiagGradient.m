function g = rbfKernDiagGradient(kern, x, covDiag)

% RBFKERNDIAGGRADIENT Compute the gradient of the RBF kernel's diagonal wrt to parameters.
%
% g = rbfKernDiagGradient(kern, x, covDiag)
%

% Copyright (c) 2006 Neil D. Lawrence and Nathaniel J. King
% rbfKernDiagGradient.m version 1.1



g = zeros(1, kern.nParams);
g(1) = 0;
g(2) = sum(covDiag);
