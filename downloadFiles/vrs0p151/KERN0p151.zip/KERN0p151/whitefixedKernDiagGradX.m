function gX = whitefixedKernDiagGradX(kern, X)

% WHITEFIXEDKERNDIAGGRADX Gradient of white fixed noise kernel's diagonal with respect to a X.
%
% gX = whitefixedKernDiagGradX(kern, X)
%

% Copyright (c) 2006 Neil D. Lawrence and Nathaniel J. King
% whitefixedKernDiagGradX.m version 1.1



gX = whiteKernDiagGradX(kern, X);