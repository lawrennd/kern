function g = biasKernGradient(kern, x, varargin)

% BIASKERNGRADIENT Gradient of bias kernel's parameters.
%
% g = biasKernGradient(kern, x, varargin)
%

% Copyright (c) 2006 Neil D. Lawrence and Nathaniel J. King
% biasKernGradient.m version 1.4



g = sum(sum(varargin{end}));
