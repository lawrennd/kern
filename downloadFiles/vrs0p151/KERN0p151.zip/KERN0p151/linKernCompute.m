function k = linKernCompute(kern, x, x2)

% LINKERNCOMPUTE Compute the kernel given the parameters and X.
%
% k = linKernCompute(kern, x, x2)
%

% Copyright (c) 2006 Neil D. Lawrence and Nathaniel J. King
% linKernCompute.m version 1.3



if nargin < 3
  k = x*x'*kern.variance;
else
  k = x*x2'*kern.variance;
end
if issparse(x)
  k = full(k);
end