function params = tensorKernExtractParam(kern)

% TENSORKERNEXTRACTPARAM Extract parameters from compound kernel structure.
%
% params = tensorKernExtractParam(kern)
%

% Copyright (c) 2006 Neil D. Lawrence and Nathaniel J. King
% tensorKernExtractParam.m version 1.1



params = cmpndKernExtractParam(kern);
