function k = linKernDiagCompute(kern, x)

% LINKERNDIAGCOMPUTE Compute diagonal of linear kernel.
%
% k = linKernDiagCompute(kern, x)
%

% Copyright (c) 2006 Neil D. Lawrence and Nathaniel J. King
% linKernDiagCompute.m version 1.3



k =  sum(x.*x, 2)*kern.variance;
