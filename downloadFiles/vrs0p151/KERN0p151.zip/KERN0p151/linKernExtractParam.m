function params = linKernExtractParam(kern)

% LINKERNEXTRACTPARAM Extract parameters from linear kernel structure.
%
% params = linKernExtractParam(kern)
%

% Copyright (c) 2006 Neil D. Lawrence and Nathaniel J. King
% linKernExtractParam.m version 1.3



params = kern.variance;
