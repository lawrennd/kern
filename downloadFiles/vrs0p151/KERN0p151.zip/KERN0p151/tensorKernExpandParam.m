function kern = tensorKernExpandParam(kern, params)

% TENSORKERNEXPANDPARAM Create kernel structure from parameters.
%
% kern = tensorKernExpandParam(kern, params)
%

% Copyright (c) 2006 Neil D. Lawrence and Nathaniel J. King
% tensorKernExpandParam.m version 1.1



kern = cmpndKernExpandParam(kern, params);