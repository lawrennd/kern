function k = simKernDiagCompute(kern, t)

% SIMKERNDIAGCOMPUTE Compute diagonal of SIM kernel.
%
%	Description:
%
%	K = SIMKERNDIAGCOMPUTE(KERN, T) computes the diagonal of the kernel
%	matrix for the single input motif kernel given a design matrix of
%	inputs.
%	 Returns:
%	  K - a vector containing the diagonal of the kernel matrix computed
%	   at the given points.
%	 Arguments:
%	  KERN - the kernel structure for which the matrix is computed.
%	  T - input data matrix in the form of a design matrix.
%	
%
%	See also
%	SIMKERNPARAMINIT, KERNDIAGCOMPUTE, KERNCREATE, SIMKERNCOMPUTE


%	Copyright (c) 2006 Neil D. Lawrence
% 	simKernDiagCompute.m CVS version 1.1
% 	simKernDiagCompute.m SVN version 1
% 	last update 2007-12-19T07:05:33.000000Z

if size(t, 2) > 1 
  error('Input can only have one column');
end

sigma = sqrt(2/kern.inverseWidth);
t = t - kern.delay;
halfSigmaD = 0.5*sigma*kern.decay;

h = exp(halfSigmaD*halfSigmaD)...
    *(erf(- halfSigmaD) ...
      + erf(t/sigma + halfSigmaD)) ...
      - exp(halfSigmaD*halfSigmaD-(2*kern.decay*t)).*(erf(t/sigma - halfSigmaD) ...
                        + erf(halfSigmaD));

k = 2*h;
k = 0.5*k*sqrt(pi)*sigma;
k = kern.variance*k/(2*kern.decay);
