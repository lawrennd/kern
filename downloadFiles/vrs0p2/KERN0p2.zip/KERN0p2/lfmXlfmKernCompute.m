function K = lfmXlfmKernCompute(lfmKern1, lfmKern2, t, t2);

% LFMXLFMKERNCOMPUTE Compute a cross kernel between two LFM kernels.
%
%	Description:
%
%	K = LFMXLFMKERNCOMPUTE(LFMKERN1, LFMKERN2, T) computes cross kernel
%	terms between two LFM kernels for the multiple output kernel.
%	 Returns:
%	  K - block of values from kernel matrix.
%	 Arguments:
%	  LFMKERN1 - the kernel structure associated with the first LFM
%	   kernel.
%	  LFMKERN2 - the kernel structure associated with the second LFM
%	   kernel.
%	  T - inputs for which kernel is to be computed.
%
%	K = LFMXLFMKERNCOMPUTE(LFMKERN1, LFMKERN2, T1, T2) computes cross
%	kernel terms between two LFM kernels for the multiple output kernel.
%	 Returns:
%	  K - block of values from kernel matrix.
%	 Arguments:
%	  LFMKERN1 - the kernel structure associated with the first LFM
%	   kernel.
%	  LFMKERN2 - the kernel structure associated with the second LFM
%	   kernel.
%	  T1 - row inputs for which kernel is to be computed.
%	  T2 - column inputs for which kernel is to be computed.
%	
%	
%
%	See also
%	LFMKERNPARAMINIT, LFMKERNCOMPUTE, LFMKERNPARAMINIT


%	Copyright (c) 2007, 2008 David Luengo


%	With modifications by Neil D. Lawrence 2007, 2008
% 	lfmXlfmKernCompute.m SVN version 11
% 	last update 2008-06-05T18:41:50.000000Z
  
if nargin < 4
  t2 = t;
end
if size(t, 2) > 1 | size(t2, 2) > 1
  error('Input can only have one column');
end
if lfmKern1.inverseWidth ~= lfmKern2.inverseWidth
  error('Kernels cannot be cross combined if they have different inverse widths.')
end

% Get length scale out.
sigma2 = 2/lfmKern1.inverseWidth;
sigma = sqrt(sigma2);

% Parameters of the kernel
alpha(1) = lfmKern1.damper./(2*lfmKern1.mass);
alpha(2) = lfmKern2.damper./(2*lfmKern2.mass);
omega(1) = sqrt(lfmKern1.spring./lfmKern1.mass - alpha(1)*alpha(1));
omega(2) = sqrt(lfmKern2.spring./lfmKern2.mass - alpha(2)*alpha(2));

% NEED TO DEAL WITH CRITICALLY DAMPED OMEGA = 0!!! 
% Kernel evaluation
if isreal(omega)
  gamma1 = alpha(1) + j*omega(1);
  gamma2 = alpha(2) + j*omega(2);
  
  K = sigma*lfmKern1.sensitivity*lfmKern2.sensitivity* ...
        real(lfmComputeH(conj(gamma2),gamma1,sigma2,t,t2) + ...
             lfmComputeH(gamma1,conj(gamma2),sigma2,t2,t) - ...
             lfmComputeH(gamma2,gamma1,sigma2,t,t2) - ...
             lfmComputeH(gamma1,gamma2,sigma2,t2,t));
  K = K*sqrt(pi)/(4*lfmKern1.mass*lfmKern2.mass*prod(omega));
else
  gamma1_p = alpha(1) + j*omega(1);
  gamma1_m = alpha(1) - j*omega(1);
  gamma2_p = alpha(2) + j*omega(2);
  gamma2_m = alpha(2) - j*omega(2);

  K = sigma*lfmKern1.sensitivity*lfmKern2.sensitivity* ...
        (lfmComputeH(gamma2_m,gamma1_p,sigma2,t,t2) + ...
         lfmComputeH(gamma1_p,gamma2_m,sigma2,t2,t) + ...
         lfmComputeH(gamma2_p,gamma1_m,sigma2,t,t2) + ...
         lfmComputeH(gamma1_m,gamma2_p,sigma2,t2,t) - ...
         lfmComputeH(gamma2_m,gamma1_m,sigma2,t,t2) - ...
         lfmComputeH(gamma1_m,gamma2_m,sigma2,t2,t) - ...
         lfmComputeH(gamma2_p,gamma1_p,sigma2,t,t2) - ...
         lfmComputeH(gamma1_p,gamma2_p,sigma2,t2,t));
  K = K*sqrt(pi)/(8*lfmKern1.mass*lfmKern2.mass*prod(omega));
end

K = real(K); % introduced MA 2008

