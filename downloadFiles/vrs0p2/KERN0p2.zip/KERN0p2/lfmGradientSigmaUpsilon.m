function    g = lfmGradientSigmaUpsilon(gamma, sigma2, Tt1, Tt2);

% LFMGRADIENTSIGMAUPSILON Gradient of the function \upsilon(z) with respect
%
%	Description:
%	to \sigma.
%
%	G = LFMGRADIENTSIGMAUPSILON(GAMMA, SIGMA2, TT1, TT2) Computes the
%	gradient of the function \upsilon(z) with respect to the
%	length-scale of the input "force", \sigma.
%	 Returns:
%	  G - Gradient of the kernel with respect to the desired parameter.
%	 Arguments:
%	  GAMMA - Gamma value of the system.
%	  SIGMA2 - length scale of latent process.
%	  TT1 - first time input (number of time points 1 x number of time
%	   points 2).
%	  TT2 - second time input (number of time points 1 x number of time
%	   points 2).
%	
%
%	See also
%	LFMKERNGRADIENT, LFMXLFMKERNGRADIENT, LFMGRADIENTSIGMAH


%	Copyright (c) 2008 David Luengo
% 	lfmGradientSigmaUpsilon.m SVN version 14
% 	last update 2008-06-05T23:43:24.000000Z


%Parameters of the function

sigma = sqrt(sigma2);

% Initialization of vectors and matrices

g = zeros(size(Tt1));

Z1 = (Tt1-Tt2)/sigma - sigma*gamma/2;
Z2 = Tt2/sigma + sigma*gamma/2;

%%% Gradient Evaluation %%%

% Evaluation of the gradient when real(Z1)>=0 and real(Z2)>=0

ind = (real(Z1)>=0) & (real(Z2)>=0);
if any(any(ind))
    g(ind) = sigma*(gamma^2)*exp(sigma2*(gamma^2)/4 ...
            - gamma*(Tt1(ind)-Tt2(ind))) ...
        - 2*exp(-(Tt1(ind)-Tt2(ind)).*(Tt1(ind)-Tt2(ind))/sigma2 ...
            + log((Tt1(ind)-Tt2(ind)).*(Tt1(ind)-Tt2(ind)).*wofz(j*Z1(ind))/(sigma^3) ...
            + ((Tt1(ind)-Tt2(ind))/sigma2+gamma/2) ...
            .* (1/sqrt(pi)-Z1(ind).*wofz(j*Z1(ind))))) ...
        - 2*exp(-Tt2(ind).*Tt2(ind)/sigma2-gamma*Tt1(ind) ...
            + log(Tt2(ind).*Tt2(ind).*wofz(j*Z2(ind))/(sigma^3) ...
            + (Tt2(ind)/sigma2-gamma/2) .* (1/sqrt(pi)-Z2(ind).*wofz(j*Z2(ind)))));
end

% Evaluation of the gradient when real(Z1)<0 and real(Z2)>=0

ind = (real(Z1)<0) & (real(Z2)>=0);
if any(any(ind))
    g(ind) = 2*exp(-(Tt1(ind)-Tt2(ind)).*(Tt1(ind)-Tt2(ind))/sigma2 ...
            + log((Tt1(ind)-Tt2(ind)).*(Tt1(ind)-Tt2(ind)).*wofz(-j*Z1(ind))/(sigma^3) ...
            - ((Tt1(ind)-Tt2(ind))/sigma2+gamma/2) ...
            .* (1/sqrt(pi)+Z1(ind).*wofz(-j*Z1(ind))))) ...
        - 2*exp(-Tt2(ind).*Tt2(ind)/sigma2-gamma*Tt1(ind) ...
            + log(Tt2(ind).*Tt2(ind).*wofz(j*Z2(ind))/(sigma^3) ...
            + (Tt2(ind)/sigma2-gamma/2) .* (1/sqrt(pi)-Z2(ind).*wofz(j*Z2(ind)))));
end

% Evaluation of the rest of the gradient when real(Z1)>=0 and real(Z2)<0

ind = (real(Z1)>=0) & (real(Z2)<0);
if any(any(ind))
    g(ind) = - 2*exp(-(Tt1(ind)-Tt2(ind)).*(Tt1(ind)-Tt2(ind))/sigma2 ...
            + log((Tt1(ind)-Tt2(ind)).*(Tt1(ind)-Tt2(ind)).*wofz(j*Z1(ind))/(sigma^3) ...
            + ((Tt1(ind)-Tt2(ind))/sigma2+gamma/2) ...
            .* (1/sqrt(pi)-Z1(ind).*wofz(j*Z1(ind))))) ...
        + 2*exp(-Tt2(ind).*Tt2(ind)/sigma2-gamma*Tt1(ind) ...
            + log(Tt2(ind).*Tt2(ind).*wofz(-j*Z2(ind))/(sigma^3) ...
            - (Tt2(ind)/sigma2-gamma/2) .* (1/sqrt(pi)+Z2(ind).*wofz(-j*Z2(ind)))));
end

% Evaluation of the rest of the gradient when real(Z1)>=0 and real(Z2)>=0

ind = (real(Z1)<0) & (real(Z2)<0);
if any(any(ind))
    g(ind) = - sigma*(gamma^2)*exp(sigma2*(gamma^2)/4 ...
            - gamma*(Tt1(ind)-Tt2(ind))) ...
        + 2*exp(-(Tt1(ind)-Tt2(ind)).*(Tt1(ind)-Tt2(ind))/sigma2 ...
            + log((Tt1(ind)-Tt2(ind)).*(Tt1(ind)-Tt2(ind)).*wofz(-j*Z1(ind))/(sigma^3) ...
            - ((Tt1(ind)-Tt2(ind))/sigma2+gamma/2) ...
            .* (1/sqrt(pi)+Z1(ind).*wofz(-j*Z1(ind))))) ...
        + 2*exp(-Tt2(ind).*Tt2(ind)/sigma2-gamma*Tt1(ind) ...
            + log(Tt2(ind).*Tt2(ind).*wofz(-j*Z2(ind))/(sigma^3) ...
            - (Tt2(ind)/sigma2-gamma/2) .* (1/sqrt(pi)+Z2(ind).*wofz(-j*Z2(ind)))));
end
