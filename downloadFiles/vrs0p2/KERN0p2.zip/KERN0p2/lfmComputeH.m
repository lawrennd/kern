function  h = lfmComputeH(gamma1, gamma2, sigma2, t1, t2);

% LFMCOMPUTEH Helper function for computing part of the LFM kernel.
%
%	Description:
%
%	H = LFMCOMPUTEH(GAMMA1, GAMMA2, SIGMA2, T1, T2) computes a portion
%	of the LFM kernel.
%	 Returns:
%	  H - result of this subcomponent of the kernel for the given
%	   values.
%	 Arguments:
%	  GAMMA1 - Gamma value for first system.
%	  GAMMA2 - Gamma value for second system.
%	  SIGMA2 - length scale of latent process.
%	  T1 - first time input (number of time points x 1).
%	  T2 - second time input (number of time points x 1).
%	
%	
%
%	See also
%	LFMKERNPARAMINIT, LFMXLFMKERNCOMPUTE


%	Copyright (c) 2007, 2008 David Luengo


%	With modifications by Neil D. Lawrence 2007
% 	lfmComputeH.m SVN version 15
% 	last update 2008-06-06T00:04:52.000000Z

sigma = sqrt(sigma2);

% Creation of the time matrices

Tt1 = repmat(t1, 1, size(t2, 1));
Tt2 = repmat(t2', size(t1, 1), 1);

% Evaluation of h

h = (lfmComputeUpsilon(gamma1,sigma2,Tt2,Tt1) - exp(-gamma2*Tt1) ...
    .* lfmComputeUpsilon(gamma1,sigma2,Tt2,zeros(size(Tt1))))/(gamma1+gamma2+eps);
