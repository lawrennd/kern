% KERN toolbox
% Version 0.2		06-Jun-2008
% Copyright (c) 2008, Neil D. Lawrence
% 
, Neil D. Lawrence
% GGKERNCOMPUTE Compute the GG kernel given the parameters and X.
% KERNSETINDEX Set the indices on a compound kernel.
% ARDKERNEXPANDPARAM Create kernel structure from ARD kernel's parameters.
% GAUSSIANKERNEXTRACTPARAM Extract parameters from the gaussian kernel structure.
% WHITEFIXEDKERNPARAMINIT WHITEFIXED kernel parameter initialisation.
% KERNPCA performs KPCA.
% LINKERNGRADIENT Gradient of LIN kernel's parameters.
% RATQUADKERNPARAMINIT RATQUAD kernel parameter initialisation.
% RBFPERIODICKERNEXPANDPARAM Create kernel structure from RBFPERIODIC kernel's parameters.
% KERNEXTRACTPARAM Extract parameters from kernel structure.
% GIBBSKERNSETLENGTHSCALEFUNC Set the length scale function of the GIBBS kernel.
% TENSORKERNGRADX Gradient of TENSOR kernel with respect to a point x.
% POLYARDKERNGRADX Gradient of POLYARD kernel with respect to input locations.
% RBFPERIODICKERNGRADIENT Gradient of RBFPERIODIC kernel's parameters.
% RATQUADKERNEXTRACTPARAM Extract parameters from the RATQUAD kernel structure.
% GIBBSKERNCOMPUTE Compute the GIBBS kernel given the parameters and X.
% FILEKERNREAD Read kernel values from file or cache.
% BIASKERNDIAGGRADIENT Compute the gradient of the BIAS kernel's diagonal wrt parameters.
% DISIMXDISIMKERNCOMPUTE Compute a cross kernel between two DISIM kernels.
% MATERN52KERNDIAGCOMPUTE Compute diagonal of MATERN52 kernel.
% POLYKERNEXPANDPARAM Create kernel structure from POLY kernel's parameters.
% LFMKERNGRADIENT Gradient of LFM kernel's parameters.
% GIBBSPERIODICKERNDISPLAY Display parameters of the GIBBSPERIODIC kernel.
% MULTIKERNGRADIENT Gradient of MULTI kernel's parameters.
% LFMXLFMKERNCOMPUTE Compute a cross kernel between two LFM kernels.
% MLPARDKERNEXTRACTPARAM Extract parameters from the MLPARD kernel structure.
% MLPKERNEXPANDPARAM Create kernel structure from MLP kernel's parameters.
% LFMOPTIONS Creates a set of default options for a LFM model.
% RBFKERNDIAGGRADIENT Compute the gradient of the RBF kernel's diagonal wrt parameters.
% ARDKERNDIAGGRADIENT Compute the gradient of the ARD kernel's diagonal wrt parameters.
% TENSORKERNDIAGGRADIENT Compute the gradient of the TENSOR kernel's diagonal wrt parameters.
% RBFARDKERNGRADX Gradient of RBFARD kernel with respect to input locations.
% SIMKERNDIAGGRADX Gradient of SIM kernel's diagonal with respect to X.
% GIBBSPERIODICKERNCOMPUTE Compute the GIBBSPERIODIC kernel given the parameters and X.
% POLYARDKERNPARAMINIT POLYARD kernel parameter initialisation.
% LFMKERNDIAGGRADIENT Compute the gradient of the LFM kernel's diagonal wrt parameters.
% TRANSLATEKERNGRADIENT Gradient of TRANSLATE kernel's parameters.
% RBFPERIODICKERNGRADX Gradient of RBFPERIODIC kernel with respect to a point x.
% LFMEXTRACTPARAM Extract the parameters of an LFM model.
% GAUSSIANKERNGRADX Gradient of gaussian kernel with respect to input locations.
% GAUSSIANKERNPARAMINIT Gaussian kernel parameter initialisation.
% LFMKERNEXPANDPARAM Create kernel structure from LFM kernel's parameters.
% BIASKERNDISPLAY Display parameters of the BIASkernel.
% ARDKERNEXTRACTPARAM Extract parameters from the ARD kernel structure.
% KERNCOMPUTE Compute the kernel given the parameters and X.
% WHITEKERNDIAGCOMPUTE Compute diagonal of WHITE kernel.
% RBFKERNEXTRACTPARAM Extract parameters from the RBF kernel structure.
% SQEXPKERNEXPANDPARAM Create kernel structure from SQEXP kernel's parameters.
% GIBBSPERIODICKERNEXTRACTPARAM Extract parameters from the GIBBSPERIODIC kernel structure.
% DISIMXRBFKERNCOMPUTE Compute a cross kernel between the DISIM and RBF kernels.
% DISIMKERNDIAGGRADIENT Compute the gradient of the DISIM kernel's diagonal wrt parameters.
% KERNCREATE Initialise a kernel structure.
% WHITEFIXEDKERNDIAGCOMPUTE Compute diagonal of WHITEFIXED kernel.
% WHITEKERNDIAGGRADX Gradient of WHITE kernel's diagonal with respect to X.
% SPARSEKERNDISPLAY Display parameters of the SPARSE kernel.
% GIBBSKERNEXTRACTPARAM Extract parameters from the GIBBS kernel structure.
% FILEKERNGRADIENT Gradient of FILE kernel's parameters.
% EXPKERNPARAMINIT EXP kernel parameter initialisation.
% EXPKERNGRADIENT Gradient of EXP kernel's parameters.
% GGXGGKERNCOMPUTE Compute a cross kernel between two GG kernels.
% MATERN32KERNDIAGCOMPUTE Compute diagonal of MATERN32 kernel.
% CMPNDKERNDIAGCOMPUTE Compute diagonal of CMPND kernel.
% BIASKERNPARAMINIT BIAS kernel parameter initialisation.
% GIBBSPERIODICKERNDIAGCOMPUTE Compute diagonal of GIBBSPERIODIC kernel.
% CMPNDKERNEXTRACTPARAM Extract parameters from the CMPND kernel structure.
% SIMXRBFKERNCOMPUTE Compute a cross kernel between the SIM and RBF kernels.
% GGXGAUSSIANKERNGRADX Compute gradient between the GG and GAUSSIAN
% LINARDKERNDISPLAY Display parameters of the LINARD kernel.
% MULTIKERNDIAGGRADX Gradient of MULTI kernel's diagonal with respect to X.
% POLYKERNDIAGGRADX Gradient of POLY kernel's diagonal with respect to X.
% LINARDKERNPARAMINIT LINARD kernel parameter initialisation.
% KERNGETVARIANCE Get the signal associated with a the kernel.
% MULTIKERNTEST Run some tests on the multiple output block kernel.
% COMPONENTKERNWRITEPARAMSTOFID Write a component based kernel to a stream.
% RBFARDKERNDISPLAY Display parameters of the RBFARD kernel.
% POLYKERNCOMPUTE Compute the POLY kernel given the parameters and X.
% SIMKERNPARAMINIT SIM kernel parameter initialisation.
% LINKERNDIAGCOMPUTE Compute diagonal of LIN kernel.
% PSKERNELGRADIENT Gradient on likelihood approximation for point set IVM.
% MULTIKERNDIAGCOMPUTE Compute diagonal of MULTI kernel.
% WHITEXWHITEKERNGRADIENT Compute a cross gradient between two WHITE kernels.
% KERNPRIORGRADIENT Compute gradient terms associated with kernel priors.
% SIMCOMPUTETEST Test the file simComputeH.
% DISIMKERNEXTRACTPARAM Extract parameters from the DISIM kernel structure.
% DISIMKERNGRADX Gradient of DISIM kernel with respect to a point x.
% LINKERNDIAGGRADX Gradient of LIN kernel's diagonal with respect to X.
% DISIMCOMPUTEH Helper function for comptuing part of the DISIM kernel.
% BIASKERNDIAGGRADX Gradient of BIAS kernel's diagonal with respect to X.
% KERNGRADIENT Compute the gradient wrt the kernel's parameters.
% CMPNDKERNSETINDEX Set the indices in the compound kernel.
% KERNTEST Run some tests on the specified kernel.
% GGXGAUSSIANKERNCOMPUTE Compute a cross kernel between the GG and GAUSSIAN kernels.
% SIMKERNDIAGGRADIENT Compute the gradient of the SIM kernel's diagonal wrt parameters.
% MLPKERNCOMPUTE Compute the MLP kernel given the parameters and X.
% SIMKERNEXTRACTPARAM Extract parameters from the SIM kernel structure.
% SQEXPKERNCOMPUTE Compute the SQEXP kernel given the parameters and X.
% MLPARDKERNPARAMINIT MLPARD kernel parameter initialisation.
% RATQUADKERNDISPLAY Display parameters of the RATQUAD kernel.
% LINKERNGRADX Gradient of LIN kernel with respect to input locations.
% GIBBSKERNDIAGGRADX Gradient of GIBBS kernel's diagonal with respect to X.
% MLPARDKERNEXPANDPARAM Create kernel structure from MLPARD kernel's parameters.
% DISIMXSIMKERNGRADIENT Compute gradient between the DISIM and SIM kernels.
% POLYKERNGRADX Gradient of POLY kernel with respect to input locations.
% SIMXSIMKERNCOMPUTE Compute a cross kernel between two SIM kernels.
% SQEXPKERNEXTRACTPARAM Extract parameters from the SQEXP kernel structure.
% GAUSSIANKERNCOMPUTE Compute the Gaussian kernel given the parameters and X.
% MLPARDKERNCOMPUTE Compute the MLPARD kernel given the parameters and X.
% MLPKERNGRADX Gradient of MLP kernel with respect to input locations.
% CMPNDKERNDISPLAY Display parameters of the CMPND kernel.
% LINARDKERNCOMPUTE Compute the LINARD kernel given the parameters and X.
% EXPKERNDIAGGRADX Gradient of EXP kernel's diagonal with respect to X.
% POLYKERNDIAGCOMPUTE Compute diagonal of POLY kernel.
% WHITEFIXEDKERNEXTRACTPARAM Extract parameters from the WHITEFIXED kernel structure.
% MATERN32KERNGRADIENT Gradient of MATERN32 kernel's parameters.
% GGKERNPARAMINIT GG kernel parameter initialisation.
% DISIMKERNEXPANDPARAM Create kernel structure from DISIM kernel's parameters.
% LFMXRBFKERNCOMPUTE Compute a cross kernel between the LFM and RBF kernels.
% WHITEFIXEDKERNEXPANDPARAM Create kernel structure from WHITEFIXED kernel's parameters.
% KERNGRADX Compute the gradient of the kernel wrt X.
% MATERN52KERNGRADIENT Gradient of MATERN52 kernel's parameters.
% CMPNDKERNEXPANDPARAM Create kernel structure from CMPND kernel's parameters.
% MLPKERNDIAGCOMPUTE Compute diagonal of MLP kernel.
% MULTIKERNGRADIENTBLOCK
% TENSORKERNDIAGGRADX Gradient of TENSOR kernel's diagonal with respect to X.
% DISIMCOMPUTEHPRIME Helper function for comptuing part of the DISIM kernel.
% RBFPERIODICKERNDIAGCOMPUTE Compute diagonal of RBFPERIODIC kernel.
% GAUSSIANKERNDIAGGRADIENT Compute the gradient of the gaussian kernel's diagonal wrt parameters.
% WHITEFIXEDKERNGRADX Gradient of WHITEFIXED kernel with respect to a point x.
% RATQUADKERNCOMPUTE Compute the RATQUAD kernel given the parameters and X.
% LINKERNDISPLAY Display parameters of the LIN kernel.
% FILEKERNEXPANDPARAM Create kernel structure from FILE kernel's parameters.
% RBFARDKERNDIAGGRADIENT Compute the gradient of the RBFARD kernel's diagonal wrt parameters.
% LFMKERNDIAGCOMPUTE Compute diagonal of LFM kernel.
% LINARDKERNEXPANDPARAM Create kernel structure from LINARD kernel's parameters.
% GGXGAUSSIANKERNGRADIENT Compute gradient between the GG and GAUSSIAN kernels.
% KERNPRIORLOGPROB Compute penalty terms associated with kernel priors.
% LINARDKERNGRADX Gradient of LINARD kernel with respect to input locations.
% EXPKERNDISPLAY Display parameters of the EXP kernel.
% GIBBSKERNDISPLAY Display parameters of the GIBBS kernel.
% POLYKERNEXTRACTPARAM Extract parameters from the POLY kernel structure.
% RBFKERNDIAGGRADX Gradient of RBF kernel's diagonal with respect to X.
% LINARDKERNDIAGCOMPUTE Compute diagonal of LINARD kernel.
% GGKERNGRADIENT Gradient of GG kernel's parameters.
% SQEXPKERNDISPLAY Display parameters of the SQEXP kernel.
% POLYARDKERNEXPANDPARAM Create kernel structure from POLYARD kernel's parameters.
% KERNREADFROMFID Load from an FID written by the C++ implementation.
% RBFKERNDIAGCOMPUTE Compute diagonal of RBF kernel.
% COMPONENTKERNREADPARAMSFROMFID Read a component based kernel from a C++ file.
% LFMGRADIENTUPSILON Gradient of the function \upsilon(z) with respect to
% TRANSLATEKERNPARAMINIT TRANSLATE kernel parameter initialisation.
% RBFARDKERNCOMPUTE Compute the RBFARD kernel given the parameters and X.
% MULTIKERNDISPLAY Display parameters of the MULTI kernel.
% TRANSLATEKERNCOMPUTE Compute the TRANSLATE kernel given the parameters and X.
% RBFARDKERNEXTRACTPARAM Extract parameters from the RBFARD kernel structure.
% LFMCOMPUTEH Helper function for computing part of the LFM kernel.
% WHITEFIXEDKERNCOMPUTE Compute the WHITEFIXED kernel given the parameters and X.
% GIBBSPERIODICKERNEXPANDPARAM Create kernel structure from GIBBSPERIODIC kernel's parameters.
% DISIMKERNDIAGCOMPUTE Compute diagonal of DISIM kernel.
% LINARDKERNGRADIENT Gradient of LINARD kernel's parameters.
% GIBBSPERIODICKERNPARAMINIT GIBBSPERIODIC kernel parameter initialisation.
% MLPKERNPARAMINIT MLP kernel parameter initialisation.
% CMPNDKERNPARAMINIT CMPND kernel parameter initialisation.
% LFMLOGLIKELIHOOD Compute the log likelihood of a LFM model.
% EXPKERNEXTRACTPARAM Extract parameters from the EXP kernel structure.
% CMPNDKERNDIAGGRADX Gradient of CMPND kernel's diagonal with respect to X.
% WHITEKERNEXTRACTPARAM Extract parameters from the WHITE kernel structure.
% SIMKERNGRADIENT Gradient of SIM kernel's parameters.
% RATQUADKERNDIAGGRADX Gradient of RATQUAD kernel's diagonal with respect to X.
% WHITEKERNDIAGGRADIENT Compute the gradient of the WHITE kernel's diagonal wrt parameters.
% EXPKERNEXPANDPARAM Create kernel structure from EXP kernel's parameters.
% RBFPERIODICKERNDIAGGRADIENT Compute the gradient of the RBFPERIODIC kernel's diagonal wrt parameters.
% DISIMXSIMKERNCOMPUTE Compute a cross kernel between DISIM and SIM kernels.
% RBFARDKERNDIAGGRADX Gradient of RBFARD kernel's diagonal with respect to X.
% SQEXPKERNGRADIENT Gradient of SQEXP kernel's parameters.
% KERNTOOLBOXES Load in the relevant toolboxes for kern.
% EXPKERNCOMPUTE Compute the EXP kernel given the parameters and X.
% POLYARDKERNDIAGCOMPUTE Compute diagonal of POLYARD kernel.
% EXPKERNGRADX Gradient of EXP kernel with respect to a point x.
% GGKERNEXPANDPARAM Create kernel structure from GG kernel's parameters.
% LINKERNEXPANDPARAM Create kernel structure from LIN kernel's parameters.
% DISIMKERNDIAGGRADX Gradient of DISIM kernel's diagonal with respect to X.
% RATQUADKERNDIAGCOMPUTE Compute diagonal of RATQUAD kernel.
% MLPARDKERNDISPLAY Display parameters of the MLPARD kernel.
% KERNCORRELATION Compute the correlation matrix kernel given the parameters and X.
% GIBBSPERIODICKERNDIAGGRADIENT Compute the gradient of the GIBBSPERIODIC kernel's diagonal wrt parameters.
% POLYARDKERNDISPLAY Display parameters of the POLYARD kernel.
% LINKERNCOMPUTE Compute the LIN kernel given the parameters and X.
% RBFPERIODICKERNPARAMINIT RBFPERIODIC kernel parameter initialisation.
% GIBBSKERNDIAGGRADIENT Compute the gradient of the GIBBS kernel's diagonal wrt parameters.
% TRANSLATEKERNDIAGCOMPUTE Compute diagonal of TRANSLATE kernel.
% BIASKERNCOMPUTE Compute the BIAS kernel given the parameters and X.
% MULTIKERNDIAGGRADIENT Compute the gradient of the MULTI kernel's diagonal wrt parameters.
% MULTIKERNCOMPUTE Compute the MULTI kernel given the parameters and X.
% RBFKERNCOMPUTE Compute the RBF kernel given the parameters and X.
% LFMXRBFKERNGRADIENT Compute gradient between the LFM and RBF kernels.
% MATERN32KERNPARAMINIT MATERN32 kernel parameter initialisation.
% ARDKERNPARAMINIT ARD kernel parameter initialisation.
% MATERN32KERNDISPLAY Display parameters of the MATERN32 kernel.
% RBFKERNPARAMINIT RBF kernel parameter initialisation.
% MATERN52KERNPARAMINIT MATERN52 kernel parameter initialisation.
% POLYARDKERNGRADIENT Gradient of POLYARD kernel's parameters.
% LFMKERNPARAMINIT LFM kernel parameter initialisation.
% KERNDISPLAY Display the parameters of the kernel.
% FILEKERNPARAMINIT FILE kernel parameter initialisation.
% DISIMKERNCOMPUTE Compute the DISIM kernel given the parameters and X.
% LFMGRADIENTSIGMAH Gradient of the function h_i(z) with respect \sigma.
% TENSORKERNSLASH Tensor kernel created by removing ith component.
% KERNDIAGCOMPUTE Compute the kernel given the parameters and X.
% CMPNDKERNGRADIENT Gradient of CMPND kernel's parameters.
% RATQUADKERNEXPANDPARAM Create kernel structure from RATQUAD kernel's parameters.
% MATERN32KERNDIAGGRADIENT Compute the gradient of the MATERN32 kernel's diagonal wrt parameters.
% TRANSLATEKERNEXPANDPARAM Create kernel structure from TRANSLATE kernel's parameters.
% TENSORKERNSETINDEX Set the indices in the tensor kernel.
% MATERN32KERNGRADX Gradient of MATERN32 kernel with respect to input locations.
% SQEXPKERNDIAGCOMPUTE Compute diagonal of SQEXP kernel.
% KERNDIAGGRADX Compute the gradient of the  kernel wrt X.
% GIBBSPERIODICKERNDIAGGRADX Gradient of GIBBSPERIODIC kernel's diagonal with respect to X.
% MATERN52KERNEXPANDPARAM Create kernel structure from MATERN52 kernel's parameters.
% BIASKERNEXTRACTPARAM Extract parameters from the BIAS kernel structure.
% GGKERNDIAGCOMPUTE Compute diagonal of GG kernel.
% RBFARDKERNGRADIENT Gradient of RBFARD kernel's parameters.
% MATERN52KERNDIAGGRADX Gradient of MATERN52 kernel's diagonal with respect to X.
% ARDKERNDISPLAY Display parameters of the ARD kernel.
% LFMKERNGRADX Gradient of LFM kernel with respect to a point x.
% MATERN32KERNDIAGGRADX Gradient of MATERN32 kernel's diagonal with respect to X.
% MLPARDKERNDIAGCOMPUTE Compute diagonal of MLPARD kernel.
% RBFPERIODICKERNDISPLAY Display parameters of the RBFPERIODIC kernel.
% POLYARDKERNEXTRACTPARAM Extract parameters from the POLYARD kernel structure.
% TRANSLATEKERNDISPLAY Display parameters of the TRANSLATE kernel.
% LFMXLFMKERNGRADIENT Compute a cross gradient between two LFM kernels.
% SQEXPKERNGRADX Gradient of SQEXP kernel with respect to a point x.
% WHITEKERNDISPLAY Display parameters of the WHITEkernel.
% KERNEXPANDPARAM Expand parameters to form a kernel structure.
% GIBBSPERIODICKERNGRADX Gradient of GIBBSPERIODIC kernel with respect to a point x.
% LFMCOMPUTETEST Test the file lfmComputeH.
% KERNREADPARAMSFROMFID Read the kernel parameters from C++ file FID.
% ARDKERNGRADIENT Gradient of ARD kernel's parameters.
% TENSORKERNGRADIENT Gradient of TENSOR kernel's parameters.
% RBFKERNDISPLAY Display parameters of the RBF kernel.
% MATERN52KERNDISPLAY Display parameters of the MATERN52 kernel.
% SIMCOMPUTEH Helper function for comptuing part of the SIM kernel.
% ARDKERNDIAGGRADX Gradient of ARD kernel's diagonal with respect to X.
% MATERN52KERNCOMPUTE Compute the MATERN52 kernel given the parameters and X.
% ARDKERNDIAGCOMPUTE Compute diagonal of ARD kernel.
% GIBBSKERNPARAMINIT GIBBS kernel parameter initialisation.
% LFMKERNDIAGGRADX Gradient of LFM kernel's diagonal with respect to X.
% RBFARDKERNPARAMINIT RBFARD kernel parameter initialisation.
% SQEXPKERNDIAGGRADIENT Compute the gradient of the SQEXP kernel's diagonal wrt parameters.
% MATERN32KERNEXTRACTPARAM Extract parameters from the MATERN32 kernel structure.
% BIASKERNDIAGCOMPUTE Compute diagonal of BIAS kernel.
% RBFPERIODICKERNDIAGGRADX Gradient of RBFPERIODIC kernel's diagonal with respect to X.
% MLPKERNEXTRACTPARAM Extract parameters from the MLP kernel structure.
% SIMKERNCOMPUTE Compute the SIM kernel given the parameters and X.
% MATERN32KERNCOMPUTE Compute the MATERN32 kernel given the parameters and X.
% LFMGRADIENTSIGMAUPSILON Gradient of the function \upsilon(z) with respect
% MULTIKERNEXTRACTPARAM Extract parameters from the MULTI kernel structure.
% GGKERNEXTRACTPARAM Extract parameters from the GG kernel structure.
% RBFPERIODICKERNCOMPUTE Compute the RBFPERIODIC kernel given the parameters and X.
% DISIMXRBFKERNGRADIENT Compute gradient between the DISIM and RBF kernels.
% GIBBSKERNEXPANDPARAM Create kernel structure from GIBBS kernel's parameters.
% KERNDIAGGRADIENT Compute the gradient of the kernel's parameters for the diagonal.
% TENSORKERNPARAMINIT TENSOR kernel parameter initialisation.
% POLYARDKERNDIAGGRADX Gradient of POLYARD kernel's diagonal with respect to X.
% RATQUADKERNGRADIENT Gradient of RATQUAD kernel's parameters.
% DISIMKERNDISPLAY Display parameters of the DISIM kernel.
% SIMKERNDISPLAY Display parameters of the SIM kernel.
% WHITEFIXEDXWHITEFIXEDKERNGRADIENT Compute a cross gradient between two WHITEFIXED kernels.
% MLPARDKERNDIAGGRADX Gradient of MLPARD kernel's diagonal with respect to X.
% GGXGGKERNGRADIENT Compute a cross gradient between two GG kernels.
% GAUSSIANKERNDISPLAY Display parameters of the GAUSSIAN kernel.
% LFMGRADIENTH Gradient of the function h_i(z) with respect to some of the
% WHITEFIXEDKERNDIAGGRADX Gradient of WHITEFIXED kernel's diagonal with respect to X.
% WHITEFIXEDXWHITEFIXEDKERNCOMPUTE Compute a cross kernel between two WHITEFIXED kernels.
% RATQUADKERNGRADX Gradient of RATQUAD kernel with respect to input locations.
% KERNWRITETOFID Load from an FID written by the C++ implementation.
% GIBBSKERNGRADX Gradient of GIBBS kernel with respect to input locations.
% WHITEKERNEXPANDPARAM Create kernel structure from WHITE kernel's parameters.
% BIASKERNGRADX Gradient of BIAS kernel with respect to input locations.
% MLPKERNGRADIENT Gradient of MLP kernel's parameters.
% FILEKERNGRADX Gradient of FILE kernel with respect to a point x.
% SQEXPKERNDIAGGRADX Gradient of SQEXP kernel's diagonal with respect to X.
% LFMUPDATEKERNELS Updates the kernel representations in the LFM structure.
% EXPKERNDIAGCOMPUTE Compute diagonal of EXP kernel.
% LINKERNEXTRACTPARAM Extract parameters from the LIN kernel structure.
% GAUSSIANKERNDIAGCOMPUTE Compute diagonal of gaussian kernel.
% MULTIKERNPARAMINIT MULTI kernel parameter initialisation.
% TENSORKERNEXTRACTPARAM Extract parameters from the TENSOR kernel structure.
% LINARDKERNEXTRACTPARAM Extract parameters from the LINARD kernel structure.
% GAUSSIANKERNGRADIENT Gradient of gaussian kernel's parameters.
% LFMCREATE Create a LFM model.
% LFMCOMPUTEUPSILON Helper function for comptuing part of the LFM kernel.
% BIASKERNEXPANDPARAM Create kernel structure from BIAS kernel's parameters.
% FILEKERNDIAGCOMPUTE Compute diagonal of FILE kernel.
% GIBBSKERNGRADIENT Gradient of GIBBS kernel's parameters.
% GGKERNDISPLAY Display parameters of the GG kernel.
% LFMTEST Test the gradients of the LFM model.
% TENSORKERNDISPLAY Display parameters of the TENSOR kernel.
% WHITEXWHITEKERNCOMPUTE Compute a cross kernel between two WHITE kernels.
% WHITEFIXEDKERNGRADIENT Gradient of WHITEFIXED kernel's parameters.
% CMPNDKERNDIAGGRADIENT Compute the gradient of the CMPND kernel's diagonal wrt parameters.
% MULTIKERNEXPANDPARAM Create kernel structure from MULTI kernel's parameters.
% RBFARDKERNDIAGCOMPUTE Compute diagonal of RBFARD kernel.
% FILEKERNDISPLAY Display parameters of the FILE kernel.
% SIMKERNEXPANDPARAM Create kernel structure from SIM kernel's parameters.
% MULTIKERNGRADX Gradient of MULTI kernel with respect to a point x.
% ARDKERNCOMPUTE Compute the ARD kernel given the parameters and X.
% BIASKERNGRADIENT Gradient of BIAS kernel's parameters.
% WHITEKERNCOMPUTE Compute the WHITE kernel given the parameters and X.
% SIMKERNGRADX Gradient of SIM kernel with respect to a point x.
% POLYKERNDISPLAY Display parameters of the POLY kernel.
% COMPUTEKERNEL Compute the kernel given the parameters and X.
% WHITEKERNGRADIENT Gradient of WHITE kernel's parameters.
% SIMKERNDIAGCOMPUTE Compute diagonal of SIM kernel.
% MLPKERNDIAGGRADX Gradient of MLP kernel's diagonal with respect to X.
% LFMKERNCOMPUTE Compute the LFM kernel given the parameters and X.
% GIBBSPERIODICKERNGRADIENT Gradient of GIBBSPERIODIC kernel's parameters.
% SQEXPKERNPARAMINIT SQEXP kernel parameter initialisation.
% WHITEFIXEDKERNDISPLAY Display parameters of the WHITEFIXED kernel.
% WHITEFIXEDKERNDIAGGRADIENT Compute the gradient of the WHITEFIXED kernel's diagonal wrt parameters.
% SIMXRBFKERNGRADIENT Compute gradient between the SIM and RBF kernels.
% DISIMKERNGRADIENT Gradient of DISIM kernel's parameters.
% POLYKERNGRADIENT Gradient of POLY kernel's parameters.
% MATERN52KERNEXTRACTPARAM Extract parameters from the MATERN52 kernel structure.
% MATERN52KERNGRADX Gradient of MATERN52 kernel with respect to input locations.
% TRANSLATEKERNGRADX Gradient of TRANSLATE kernel with respect to a point x.
% GAUSSIANKERNEXPANDPARAM Create kernel structure from gaussian kernel's parameters.
% LFMLOGLIKEGRADIENTS Compute the gradients of the log likelihood of a LFM model.
% TENSORKERNEXPANDPARAM Create kernel structure from TENSOR kernel's parameters.
% POLYKERNPARAMINIT POLY kernel parameter initialisation.
% MULTIKERNCOMPUTEBLOCK
% CMPNDKERNGRADX Gradient of CMPND kernel with respect to a point x.
% LFMKERNDISPLAY Display parameters of the LFM kernel.
% LFMEXPANDPARAM Expand the given parameters into a LFM structure.
% WHITEKERNGRADX Gradient of WHITE kernel with respect to input locations.
% KERNWRITEPARAMSTOFID Write the kernel parameters to a stream.
% TRANSLATEKERNDIAGGRADX Gradient of TRANSLATE kernel's diagonal with respect to X.
% MATERN32KERNEXPANDPARAM Create kernel structure from MATERN32 kernel's parameters.
% FILEKERNEXTRACTPARAM Extract parameters from the FILE kernel structure.
% MATERN52KERNDIAGGRADIENT Compute the gradient of the MATERN52 kernel's diagonal wrt parameters.
% TENSORKERNCOMPUTE Compute the TENSOR kernel given the parameters and X.
% KERNSETWHITE Helper function to set the white noise in a kernel if it exists.
% DISIMKERNPARAMINIT DISIM kernel parameter initialisation.
% DISIMXDISIMKERNGRADIENT Compute a cross gradient between two DISIM kernels.
% LINKERNPARAMINIT LIN kernel parameter initialisation.
% LFMKERNEXTRACTPARAM Extract parameters from the LFM kernel structure.
% TENSORKERNDIAGCOMPUTE Compute diagonal of TENSOR kernel.
% POLYARDKERNCOMPUTE Compute the POLYARD kernel given the parameters and X.
% TRANSLATEKERNEXTRACTPARAM Extract parameters from the TRANSLATE kernel structure.
% MLPARDKERNGRADIENT Gradient of MLPARD kernel's parameters.
% FILEKERNCOMPUTE Compute the FILE kernel given the parameters and X.
% LFMSAMPLE Sample from LFM kernel
% RBFARDKERNEXPANDPARAM Create kernel structure from RBFARD kernel's parameters.
% WHITEKERNPARAMINIT WHITE kernel parameter initialisation.
% RBFKERNGRADX Gradient of RBF kernel with respect to input locations.
% GAUSSIANKERNDIAGGRADX Gradient of gaussian kernel's diagonal with respect to X.
% MLPARDKERNGRADX Gradient of MLPARD kernel with respect to input locations.
% CMPNDKERNCOMPUTE Compute the CMPND kernel given the parameters and X.
% KERNPARAMINIT Kernel parameter initialisation.
% RBFPERIODICKERNEXTRACTPARAM Extract parameters from the RBFPERIODIC kernel structure.
% RATQUADKERNDIAGGRADIENT Compute the gradient of the RATQUAD kernel's diagonal wrt parameters.
% RBFKERNGRADIENT Gradient of RBF kernel's parameters.
% KERNFACTORS Extract factors associated with transformed optimisation space.
% MLPKERNDISPLAY Display parameters of the MLP kernel.
% SIMXSIMKERNGRADIENT Compute a cross gradient between two SIM kernels.
% GIBBSKERNDIAGCOMPUTE Compute diagonal of GIBBS kernel.
% RBFKERNEXPANDPARAM Create kernel structure from RBF kernel's parameters.
% ARDKERNGRADX Gradient of ARD kernel with respect to a point x.
% PSKERNELOBJECTIVE Likelihood approximation for point set IVM.
% LINARDKERNDIAGGRADX Gradient of LINARD kernel's diagonal with respect to X.
