
% KERNTOOLBOXES Load in the relevant toolboxes for kern.
%
%	Description:
%	% 	kernToolboxes.m version 1.2

importLatest('optimi');
importLatest('ndlutil');
importLatest('netlab');
