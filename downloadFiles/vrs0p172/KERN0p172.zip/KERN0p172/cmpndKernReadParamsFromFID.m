function kern = cmpndKernReadParamsFromFID(kern, FID)

% CMPNDKERNREADPARAMSFROMFID Read a compound kernel from a C++ file.
%
%	Description:
%	kern = cmpndKernReadParamsFromFID(kern, FID)
%% 	cmpndKernReadParamsFromFID.m version 1.2


kern = componentKernReadParamsFromFID(kern, FID);
