function params = linardKernExtractParam(kern)

% LINARDKERNEXTRACTPARAM Extract parameters from linear ARD kernel structure.
%
% params = linardKernExtractParam(kern)
%

% Copyright (c) 2005 Neil D. Lawrence
% linardKernExtractParam.m version 1.3



params = [kern.variance kern.inputScales];
