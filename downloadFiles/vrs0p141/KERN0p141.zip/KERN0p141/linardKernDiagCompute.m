function k = linardKernDiagCompute(kern, x)

% LINARDKERNDIAGCOMPUTE Compute diagonal of linear ARD kernel.
%
% k = linardKernDiagCompute(kern, x)
%

% Copyright (c) 2005 Neil D. Lawrence
% linardKernDiagCompute.m version 1.3



scales = sparse(diag(sqrt(kern.inputScales)));
x = x*scales;

k = sum(x.*x, 2)*kern.variance;
