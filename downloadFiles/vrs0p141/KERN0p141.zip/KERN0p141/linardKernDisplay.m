function linardKernDisplay(kern)

% LINARDKERNDISPLAY Display parameters of linear ARD kernel.
%
% linardKernDisplay(kern)
%

% Copyright (c) 2005 Neil D. Lawrence
% linardKernDisplay.m version 1.3



fprintf('Linear ARD kernel Variance: %2.4f\n', kern.variance)
for i = 1:kern.inputDimension
  fprintf('Linear ARD Input %d scale: %2.4f\n', i, kern.inputScales(i))
end
