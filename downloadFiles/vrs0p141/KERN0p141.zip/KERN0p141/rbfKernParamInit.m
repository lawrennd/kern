function kern = rbfKernParamInit(kern)

% RBFKERNPARAMINIT RBF kernel parameter initialisation.
%
% kern = rbfKernParamInit(kern)
%

% Copyright (c) 2005 Neil D. Lawrence
% rbfKernParamInit.m version 1.3



kern.inverseWidth = 1;
kern.variance = 1;
kern.nParams = 2;

kern.transforms.index = [1 2];
kern.transforms.type = 'negLogLogit';
