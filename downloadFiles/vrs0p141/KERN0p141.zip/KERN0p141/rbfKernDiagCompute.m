function k = rbfKernDiagCompute(kern, x)

% RBFKERNDIAGCOMPUTE Compute diagonal of rbf kernel.
%
% k = rbfKernDiagCompute(kern, x)
%

% Copyright (c) 2005 Neil D. Lawrence
% rbfKernDiagCompute.m version 1.3



k = repmat(kern.variance, size(x, 1), 1);
