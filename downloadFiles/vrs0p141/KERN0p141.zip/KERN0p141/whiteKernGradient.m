function g = whiteKernGradient(kern, x, varargin)

% WHITEKERNGRADIENT Gradient of white noise kernel's parameters.
%
% g = whiteKernGradient(kern, x, varargin)
%

% Copyright (c) 2005 Neil D. Lawrence
% whiteKernGradient.m version 1.4



if nargin < 4
  g = trace(varargin{end});
else
  g = 0;
end
