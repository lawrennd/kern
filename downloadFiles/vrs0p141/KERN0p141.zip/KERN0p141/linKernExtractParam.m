function params = linKernExtractParam(kern)

% LINKERNEXTRACTPARAM Extract parameters from linear kernel structure.
%
% params = linKernExtractParam(kern)
%

% Copyright (c) 2005 Neil D. Lawrence
% linKernExtractParam.m version 1.3



params = kern.variance;
