function kern = whiteKernExpandParam(kern, params)

% WHITEKERNEXPANDPARAM Create kernel structure from white noise's parameters.
%
% kern = whiteKernExpandParam(kern, params)
%

% Copyright (c) 2005 Neil D. Lawrence
% whiteKernExpandParam.m version 1.3



kern.variance = params(1);