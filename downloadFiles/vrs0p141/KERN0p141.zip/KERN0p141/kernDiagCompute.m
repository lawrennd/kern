function k = kernDiagCompute(kern, x)

% KERNELCOMPUTE Compute the kernel given the parameters and X.
%
% k = kernDiagCompute(kern, x)
%

% Copyright (c) 2005 Neil D. Lawrence
% kernDiagCompute.m version 1.4



fhandle = str2func([kern.type 'KernDiagCompute']);
k = fhandle(kern, x);
