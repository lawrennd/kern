function [u, v] = kernPca(kern, X, numEig)

% KERNPCA Kernel PCA.
%
% [u, v] = kernPca(kern, X, numEig)
%

% Copyright (c) 2005 Neil D. Lawrence
% kernPca.m version 



K = kernCompute(kern, X);
[u, v] = eigs(K, numEig);