function cmpndKernDisplay(kern)

% CMPNDKERNDISPLAY Display the parameters of the compound kernel.
%
% cmpndKernDisplay(kern)
%

% Copyright (c) 2005 Neil D. Lawrence
% cmpndKernDisplay.m version 1.2





for i = 1:length(kern.comp)
  kernDisplay(kern.comp{i});
end