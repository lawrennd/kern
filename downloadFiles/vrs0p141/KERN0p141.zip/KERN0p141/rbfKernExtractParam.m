function params = rbfKernExtractParam(kern)

% RBFKERNEXTRACTPARAM Extract parameters from rbf kernel structure.
%
% params = rbfKernExtractParam(kern)
%

% Copyright (c) 2005 Neil D. Lawrence
% rbfKernExtractParam.m version 1.2





params = [kern.inverseWidth kern.variance];
