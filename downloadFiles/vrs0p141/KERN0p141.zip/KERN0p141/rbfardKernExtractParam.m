function params = rbfardKernExtractParam(kern)

% RBFARDKERNEXTRACTPARAM Extract parameters from radial basis function ARD kernel structure.
%
% params = rbfardKernExtractParam(kern)
%

% Copyright (c) 2005 Neil D. Lawrence
% rbfardKernExtractParam.m version 1.3



params = [kern.inverseWidth kern.variance kern.inputScales];
