function kern = kernParamInit(kern)

% KERNPARAMINIT Kernel parameter initialisation.
%
% kern = kernParamInit(kern)
%

% Copyright (c) 2005 Neil D. Lawrence
% kernParamInit.m version 1.4



fhandle = str2func([kern.type 'KernParamInit']);
% By default don't transform kernel parameters.
kern.transforms = [];
kern = fhandle(kern);
