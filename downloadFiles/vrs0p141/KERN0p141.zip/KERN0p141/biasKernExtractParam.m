function params = biasKernExtractParam(kern)

% BIASKERNEXTRACTPARAM Extract parameters from bias kernel structure.
%
% params = biasKernExtractParam(kern)
%

% Copyright (c) 2005 Neil D. Lawrence
% biasKernExtractParam.m version 1.2





params = kern.variance;
