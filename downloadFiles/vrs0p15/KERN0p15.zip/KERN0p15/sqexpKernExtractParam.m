function [params, transform] = sqexpKernExtractParam(kern)

% SQEXPKERNEXTRACTPARAM Extract parameters from squared exponential kernel structure.
%
% [params, transform] = sqexpKernExtractParam(kern)
%

% Copyright (c) 2006 Neil D. Lawrence and Nathaniel J. King
% sqexpKernExtractParam.m version 1.2





params = [kern.inverseWidth kern.rbfVariance kern.biasVariance ...
          kern.whiteVariance];

