function g = whitefixedKernGradient(kern, x, varargin)

% WHITEFIXEDKERNGRADIENT Gradient of white fixed noise kernel's parameters.
%
% g = whitefixedKernGradient(kern, x, varargin)
%

% Copyright (c) 2006 Neil D. Lawrence and Nathaniel J. King
% whitefixedKernGradient.m version 1.1



g = [];
% if nargin < 4
%   g = trace(varargin{end});
% else
%   g = 0;
% end
