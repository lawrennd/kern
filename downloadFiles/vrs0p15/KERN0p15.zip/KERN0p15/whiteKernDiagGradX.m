function gX = whiteKernDiagGradX(kern, X)

% WHITEKERNDIAGGRADX Gradient of white noise kernel's diagonal with respect to a X.
%
% gX = whiteKernDiagGradX(kern, X)
%

% Copyright (c) 2006 Neil D. Lawrence and Nathaniel J. King
% whiteKernDiagGradX.m version 1.3



gX = zeros(size(X));