function whitefixedKernDisplay(kern, spacing)

% WHITEFIXEDKERNDISPLAY Display parameters of white fixed noise kernel.
%
% whitefixedKernDisplay(kern, spacing)
%

% Copyright (c) 2006 Neil D. Lawrence and Nathaniel J. King
% whitefixedKernDisplay.m version 1.1



if nargin > 1
  spacing = repmat(32, 1, spacing);
else
  spacing = [];
end
spacing = char(spacing);
fprintf(spacing);
fprintf('White Fixed Noise Variance: %2.4f\n', kern.variance)