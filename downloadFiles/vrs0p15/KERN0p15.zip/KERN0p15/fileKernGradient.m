function g = fileKernGradient(kern, x, varargin)

% FILEKERNGRADIENT Gradient of file stored kernel's parameters.
%
% g = fileKernGradient(kern, x, varargin)
%

% Copyright (c) 2006 Neil D. Lawrence and Nathaniel J. King
% fileKernGradient.m version 1.1



% The last argument is covGrad
if nargin < 4
  k = fileKernCompute(kern, x);
else
  k = fileKernCompute(kern, x, varargin{1});
end
g(1) =  sum(sum(varargin{end}.*k))/kern.variance;
