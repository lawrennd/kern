function k = kernCompute(kern, x, x2)

% KERNCOMPUTE Compute the kernel given the parameters and X.
%
% k = kernCompute(kern, x, x2)
%

% Copyright (c) 2006 Neil D. Lawrence and Nathaniel J. King
% kernCompute.m version 1.3



fhandle = str2func([kern.type 'KernCompute']);
if nargin < 3
  k = fhandle(kern, x);
else
  k = fhandle(kern, x, x2);
end
