% KERN toolbox
% Version 0.15		Saturday 18 Feb 2006 at 21:40
% Copyright (c) 2006 Neil D. Lawrence and Nathaniel J. King
% 
% ARDKERNCOMPUTE Compute the kernel given the parameters and X.
% ARDKERNDIAGCOMPUTE Compute diagonal of ard kernel.
% ARDKERNDIAGGRADX Gradient of ARD kernel's diagonal with respect to X.
% ARDKERNDISPLAY Display parameters of ARD kernel.
% ARDKERNEXPANDPARAM Create kernel structure from ARD parameters.
% ARDKERNEXTRACTPARAM Extract parameters from ard kernel structure.
% ARDKERNGRADIENT Gradient of ard kernel's parameters.
% ARDKERNGRADX Gradient of ARD kernel with respect to X.
% ARDKERNPARAMINIT ARD kernel parameter initialisation.
% BIASKERNCOMPUTE Compute the bias kernel given the parameters and X.
% BIASKERNDIAGCOMPUTE Compute diagonal of bias kernel.
% BIASKERNDIAGGRADX Gradient of bias kernel's diagonal with respect to a point X.
% BIASKERNDISPLAY Display parameters of bias kernel.
% BIASKERNEXPANDPARAM Create kernel structure from bias's parameters.
% BIASKERNEXTRACTPARAM Extract parameters from bias kernel structure.
% BIASKERNGRADIENT Gradient of bias kernel's parameters.
% BIASKERNGRADX Gradient of bias kernel with respect to a point x.
% BIASKERNPARAMINIT bias kernel parameter initialisation.
% CMPNDKERNCOMPUTE Compute the kernel given the parameters and X.
% CMPNDKERNDIAGCOMPUTE Compute diagonal of compound kernel.
% CMPNDKERNDIAGGRADX Gradient of compound kernel's diagonal with respect to X.
% CMPNDKERNDISPLAY Display the parameters of the compound kernel.
% CMPNDKERNEXPANDPARAM Create kernel structure from parameters.
% CMPNDKERNEXTRACTPARAM Extract parameters from compound kernel structure.
% CMPNDKERNGRADIENT Gradient of compound kernel's parameters.
% CMPNDKERNGRADX Gradient of compound kernel with respect to a point X.
% CMPNDKERNPARAMINIT Compound kernel parameter initialisation.
% CMPNDKERNREADPARAMSFROMFID Read a compound kernel from a C++ file.
% CMPNDKERNSETINDEX Set the indices in the compound kernel.
% COMPUTEKERNEL Compute the kernel given the parameters and X.
% FILEKERNCOMPUTE Compute the kernel given the parameters and indices.
% FILEKERNDIAGCOMPUTE Load the diagonal of a kernel stored in a file.
% FILEKERNDISPLAY Display variance of kernel stored in a file.
% FILEKERNEXPANDPARAM Create kernel structure from parameter.
% FILEKERNEXTRACTPARAM Extract parameter from kernel stored in a file.
% FILEKERNGRADIENT Gradient of file stored kernel's parameters.
% FILEKERNGRADX Gradient of file stored kernel with respect to X (zeros).
% FILEKERNPARAMINIT File stored kernel parameter initialisation.
% FILEKERNREAD Read kernel values from file or cache.
% KERNCOMPUTE Compute the kernel given the parameters and X.
% KERNCREATE Initialise a kernel structure.
% KERNELCOMPUTE Compute the kernel given the parameters and X.
% KERNDIAGGRADX Compute the gradient of the  kernel wrt X.
% KERNDISPLAY Display the parameters of the kernel.
% KERNEXPANDPARAM Expand parameters to form a kernel structure.
% KERNEXTRACTPARAM Extract parameters from kernel structure.
% KERNFACTORS Extract factors associated with transformed optimisation space.
% KERNGETVARIANCE Get the signal associated with a the kernel.
% KERNGRADIENT Compute the gradient of the kernel's parameters.
% KERNGRADIENTK Compute the gradient of the kernel wrt its parameters.
% KERNGRADX Compute the gradient of the  kernel wrt X.
% KERNPARAMINIT Kernel parameter initialisation.
% KERNPCA Kernel PCA.
% KERNPRIORGRADIENT Compute gradient terms associated with kernel priors.
% KERNPRIORLOGPROB Compute penalty terms associated with kernel priors.
% KERNREADFROMFID Load from an FID written by the C++ implementation.
% KERNREADPARAMSFROMFID Read the kernel parameters from C++ file FID.
% KERNSETINDEX Set the indices on a compound kernel.
% KERNSETWHITE Helper function to set the white noise in a kernel if it exists.
% KERNTEST Run some tests on the specified kernel.
% LINARDKERNCOMPUTE Compute the linear ARD kernel given the parameters and X.
% LINARDKERNDIAGCOMPUTE Compute diagonal of linear ARD kernel.
% LINARDKERNDIAGGRADX Gradient of linear ARD kernel's diagonal with respect to X.
% LINARDKERNDISPLAY Display parameters of linear ARD kernel.
% LINARDKERNEXPANDPARAM Create kernel structure from linear ARD's parameters.
% LINARDKERNEXTRACTPARAM Extract parameters from linear ARD kernel structure.
% LINARDKERNGRADIENT Gradient of linear ARD kernel's parameters.
% LINARDKERNGRADX Gradient of linear ARD kernel with respect to X.
% LINARDKERNPARAMINIT linear ARD kernel parameter initialisation.
% LINEARKERNPARAMINIT Linear kernel parameter initialisation.
% LINKERNCOMPUTE Compute the kernel given the parameters and X.
% LINKERNDIAGCOMPUTE Compute diagonal of linear kernel.
% LINKERNDIAGGRADX Gradient of linear kernel's diagonal with respect to X.
% LINKERNDISPLAY Display parameters of linear kernel.
% LINKERNEXPANDPARAM Create kernel structure from linear kernel parameters.
% LINKERNEXTRACTPARAM Extract parameters from linear kernel structure.
% LINKERNGRADIENT Gradient of lin kernel's parameters.
% LINKERNGRADX Gradient of linear kernel with respect to X.
% LINKERNPARAMINIT Linear kernel parameter initialisation.
% MLPARDKERNCOMPUTE Compute the multi-layer perceptron ARD kernel given the parameters and X.
% MLPARDKERNDIAGCOMPUTE Compute diagonal of multi-layer perceptron ARD kernel.
% MLPARDKERNDIAGGRADX Gradient of multi-layer perceptron ARD kernel's diagonal with respect to X.
% MLPARDKERNDISPLAY Display parameters of multi-layer perceptron ARD kernel.
% MLPARDKERNEXPANDPARAM Create kernel structure from multi-layer perceptron ARD's parameters.
% MLPARDKERNEXTRACTPARAM Extract parameters from multi-layer perceptron ARD kernel structure.
% MLPARDKERNGRADIENT Gradient of multi-layer perceptron ARD kernel's parameters.
% MLPARDKERNGRADX Gradient of multi-layer perceptron ARD kernel with respect to a X.
% MLPARDKERNPARAMINIT multi-layer perceptron ARD kernel parameter initialisation.
% MLPKERNCOMPUTE Compute the multi-layer perceptron kernel given the parameters and X.
% MLPKERNDIAGCOMPUTE Compute diagonal of multi-layer perceptron kernel.
% MLPKERNDIAGGRADX Gradient of multi-layer perceptron kernel's diagonal with respect to X.
% MLPKERNDISPLAY Display parameters of multi-layer perceptron kernel.
% MLPKERNEXPANDPARAM Create kernel structure from multi-layer perceptron's parameters.
% MLPKERNEXTRACTPARAM Extract parameters from multi-layer perceptron kernel structure.
% MLPKERNGRADIENT Gradient of multi-layer perceptron kernel's parameters.
% MLPKERNGRADX Gradient of multi-layer perceptron kernel with respect to X.
% MLPKERNPARAMINIT multi-layer perceptron kernel parameter initialisation.
% POLYARDKERNCOMPUTE Compute the polynomial ARD kernel given the parameters and X.
% POLYARDKERNDIAGCOMPUTE Compute diagonal of multi-layer perceptron ARD kernel.
% POLYARDKERNDIAGGRADX Gradient of polynomial ARD kernel's diagonal with respect to X.
% POLYARDKERNDISPLAY Display parameters of polynomial ARD kernel.
% POLYARDKERNEXPANDPARAM Create kernel structure from polynomial ARD's parameters.
% POLYARDKERNEXTRACTPARAM Extract parameters from multi-layer perceptron ARD kernel structure.
% POLYARDKERNGRADIENT Gradient of polynomial ARD kernel's parameters.
% POLYARDKERNGRADX Gradient of polynomial ARD kernel with respect to X.
% POLYARDKERNPARAMINIT polynomial ARD kernel parameter initialisation.
% POLYKERNCOMPUTE Compute the polynomial kernel given the parameters and X.
% POLYKERNDIAGCOMPUTE Compute diagonal of polynomial kernel.
% POLYKERNDIAGGRADX Gradient of polynomial kernel's diagonal with respect to X.
% POLYKERNDISPLAY Display parameters of polynomial kernel.
% POLYKERNEXPANDPARAM Create kernel structure from polynomial kernel parameters.
% POLYKERNEXTRACTPARAM Extract parameters from polynomial kernel structure.
% POLYKERNGRADIENT Gradient of polynomial kernel's parameters.
% POLYKERNGRADX Gradient of polynomial kernel with respect to X.
% POLYKERNPARAMINIT Polynomial kernel parameter initialisation.
% PSKERNELGRADIENT Gradient on likelihood approximation for point set IVM.
% PSKERNELOBJECTIVE Likelihood approximation for point set IVM.
% RBFARDKERNCOMPUTE Compute the radial basis function ARD kernel given the parameters and X.
% RBFARDKERNDIAGCOMPUTE Compute diagonal of radial basis function ARD kernel.
% RBFARDKERNDIAGGRADX Gradient of radial basis function ARD kernel's diagonal with respect to X.
% RBFARDKERNDISPLAY Display parameters of radial basis function ARD kernel.
% RBFARDKERNEXPANDPARAM Create kernel structure from radial basis function ARD's parameters.
% RBFARDKERNEXTRACTPARAM Extract parameters from radial basis function ARD kernel structure.
% RBFARDKERNGRADIENT Gradient of radial basis function ARD kernel's parameters.
% RBFARDKERNGRADX Gradient of radial basis function ARD kernel with respect to a X.
% RBFARDKERNPARAMINIT radial basis function ARD kernel parameter initialisation.
% RBFKERNCOMPUTE Compute the kernel given the parameters and X.
% RBFKERNDIAGCOMPUTE Compute diagonal of rbf kernel.
% RBFKERNDIAGGRADX Gradient of Radial basis function kernel's diagonal with respect to X.
% RBFKERNDISPLAY Display parameters of radial basis function kernel.
% RBFKERNEXPANDPARAM Create kernel structure from rbf parameters.
% RBFKERNEXTRACTPARAM Extract parameters from rbf kernel structure.
% RBFKERNGRADIENT Gradient of rbf kernel's parameters.
% RBFKERNGRADX Gradient of Radial basis function kernel with respect to X.
% RBFKERNPARAMINIT RBF kernel parameter initialisation.
% SQEXPKERNCOMPUTE Compute the squared exponential kernel given the parameters and X.
% SQEXPKERNDIAGCOMPUTE Compute diagonal of squared exponential kernel.
% SQEXPKERNDIAGGRADX Gradient of squared exponential kernel's diagonal with respect to a point x.
% SQEXPKERNDISPLAY Display parameters of squared exponential kernel.
% SQEXPKERNEXPANDPARAM Create kernel structure from squared exponential's parameters.
% SQEXPKERNEXTRACTPARAM Extract parameters from squared exponential kernel structure.
% SQEXPKERNGRADIENT Gradient of squared exponential kernel's parameters.
% SQEXPKERNGRADX Gradient of squared exponential kernel with respect to X.
% SQEXPKERNPARAMINIT squared exponential kernel parameter initialisation.
% TENSORKERNCOMPUTE Compute the tensor kernel given the parameters and X.
% TENSORKERNDIAGCOMPUTE Compute diagonal of tensor kernel.
% TENSORKERNDIAGGRADX Gradient of tensor kernel's diagonal with respect to X.
% TENSORKERNDISPLAY Display the parameters of the compound kernel.
% TENSORKERNEXPANDPARAM Create kernel structure from parameters.
% TENSORKERNEXTRACTPARAM Extract parameters from compound kernel structure.
% TENSORKERNGRADIENT Gradient of compound kernel's parameters.
% CMPNDKERNGRADX Gradient of compound kernel with respect to a point X.
% TENSORKERNPARAMINIT Tensor kernel parameter initialisation.
% TENSORKERNSETINDEX Set the indices in the tensor kernel.
% TENSORKERNSLASH Tensor kernel created by removing ith component.
% WHITEFIXEDKERNCOMPUTE Compute the white fixed noise kernel given the parameters and X.
% WHITEFIXEDKERNDIAGCOMPUTE Compute diagonal of white fixed noise kernel.
% WHITEFIXEDKERNDIAGGRADX Gradient of white fixed noise kernel's diagonal with respect to a X.
% WHITEFIXEDKERNDISPLAY Display parameters of white fixed noise kernel.
% WHITEFIXEDKERNEXPANDPARAM Create kernel structure from white fixed noise's parameters.
% WHITEFIXEDKERNEXTRACTPARAM Extract parameters from white fixed noise kernel structure.
% WHITEFIXEDKERNGRADIENT Gradient of white fixed noise kernel's parameters.
% WHITEFIXEDKERNGRADX Gradient of white fixed noise kernel with respect to a point x.
% WHITEFIXEDKERNPARAMINIT white noise kernel parameter initialisation.
% WHITEKERNCOMPUTE Compute the white noise kernel given the parameters and X.
% WHITEKERNDIAGCOMPUTE Compute diagonal of white noise kernel.
% WHITEKERNDIAGGRADX Gradient of white noise kernel's diagonal with respect to a X.
% WHITEKERNDISPLAY Display parameters of white noise kernel.
% WHITEKERNEXPANDPARAM Create kernel structure from white noise's parameters.
% WHITEKERNEXTRACTPARAM Extract parameters from white noise kernel structure.
% WHITEKERNGRADIENT Gradient of white noise kernel's parameters.
% WHITEKERNGRADX Gradient of white noise kernel with respect to a point x.
% WHITEKERNPARAMINIT white noise kernel parameter initialisation.
