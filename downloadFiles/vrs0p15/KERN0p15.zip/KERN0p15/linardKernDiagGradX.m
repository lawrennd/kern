function gX = linardKernDiagGradX(kern, X)

% LINARDKERNDIAGGRADX Gradient of linear ARD kernel's diagonal with respect to X.
%
% gX = linardKernDiagGradX(kern, X)
%

% Copyright (c) 2006 Neil D. Lawrence and Nathaniel J. King
% linardKernDiagGradX.m version 1.3



gX = 2*kern.variance*X.*repmat(kern.inputScales, [size(X, 1), 1]);
