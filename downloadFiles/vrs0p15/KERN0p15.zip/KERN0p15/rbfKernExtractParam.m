function params = rbfKernExtractParam(kern)

% RBFKERNEXTRACTPARAM Extract parameters from rbf kernel structure.
%
% params = rbfKernExtractParam(kern)
%

% Copyright (c) 2006 Neil D. Lawrence and Nathaniel J. King
% rbfKernExtractParam.m version 1.3



params = [kern.inverseWidth kern.variance];
