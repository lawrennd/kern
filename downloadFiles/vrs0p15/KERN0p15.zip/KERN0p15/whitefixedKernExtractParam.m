function params = whitefixedKernExtractParam(kern)

% WHITEFIXEDKERNEXTRACTPARAM Extract parameters from white fixed noise kernel structure.
%
% params = whitefixedKernExtractParam(kern)
%

% Copyright (c) 2006 Neil D. Lawrence and Nathaniel J. King
% whitefixedKernExtractParam.m version 1.1




params = [];