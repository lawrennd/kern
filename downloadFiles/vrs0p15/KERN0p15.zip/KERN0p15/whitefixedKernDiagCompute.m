function k = whitefixedKernDiagCompute(kern, x)

% WHITEFIXEDKERNDIAGCOMPUTE Compute diagonal of white fixed noise kernel.
%
% k = whitefixedKernDiagCompute(kern, x)
%

% Copyright (c) 2006 Neil D. Lawrence and Nathaniel J. King
% whitefixedKernDiagCompute.m version 1.2



k = whiteKernDiagCompute(kern, x);