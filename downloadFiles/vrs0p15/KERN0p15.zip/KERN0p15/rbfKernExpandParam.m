function kern = rbfKernExpandParam(kern, params)

% RBFKERNEXPANDPARAM Create kernel structure from rbf parameters.
%
% kern = rbfKernExpandParam(kern, params)
%

% Copyright (c) 2006 Neil D. Lawrence and Nathaniel J. King
% rbfKernExpandParam.m version 1.3



kern.inverseWidth = params(1);
kern.variance = params(2);
