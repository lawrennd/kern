function gX = biasKernDiagGradX(kern, X)

% BIASKERNDIAGGRADX Gradient of bias kernel's diagonal with respect to a point X.
%
% gX = biasKernDiagGradX(kern, X)
%

% Copyright (c) 2006 Neil D. Lawrence and Nathaniel J. King
% biasKernDiagGradX.m version 1.3



gX = zeros(size(X));