function params = biasKernExtractParam(kern)

% BIASKERNEXTRACTPARAM Extract parameters from bias kernel structure.
%
% params = biasKernExtractParam(kern)
%

% Copyright (c) 2006 Neil D. Lawrence and Nathaniel J. King
% biasKernExtractParam.m version 1.2





params = kern.variance;
