function params = polyKernExtractParam(kern)

% POLYKERNEXTRACTPARAM Extract parameters from polynomial kernel structure.
%
% params = polyKernExtractParam(kern)
%

% Copyright (c) 2006 Neil D. Lawrence and Nathaniel J. King
% polyKernExtractParam.m version 1.1



params = [kern.weightVariance kern.biasVariance kern.variance];

