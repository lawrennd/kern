function kern = whitefixedKernExpandParam(kern, params)

% WHITEFIXEDKERNEXPANDPARAM Create kernel structure from white fixed noise's parameters.
%
% kern = whitefixedKernExpandParam(kern, params)
%

% Copyright (c) 2006 Neil D. Lawrence and Nathaniel J. King
% whitefixedKernExpandParam.m version 1.1



kern = kern;