function params = linardKernExtractParam(kern)

% LINARDKERNEXTRACTPARAM Extract parameters from linear ARD kernel structure.
%
% params = linardKernExtractParam(kern)
%

% Copyright (c) 2006 Neil D. Lawrence and Nathaniel J. King
% linardKernExtractParam.m version 1.3



params = [kern.variance kern.inputScales];
