function linKernDisplay(kern, spacing)

% LINKERNDISPLAY Display parameters of linear kernel.
%
% linKernDisplay(kern, spacing)
%

% Copyright (c) 2006 Neil D. Lawrence and Nathaniel J. King
% linKernDisplay.m version 1.3



if nargin > 1
  spacing = repmat(32, 1, spacing);
else
  spacing = [];
end
spacing = char(spacing);
fprintf(spacing)
fprintf('Linear kernel Variance: %2.4f\n', kern.variance)
