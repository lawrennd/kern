function biasKernDisplay(kern, spacing)

% BIASKERNDISPLAY Display parameters of bias kernel.
%
% biasKernDisplay(kern, spacing)
%

% Copyright (c) 2006 Neil D. Lawrence and Nathaniel J. King
% biasKernDisplay.m version 1.3



if nargin > 1
  spacing = repmat(32, 1, spacing);
else
  spacing = [];
end
spacing = char(spacing);
fprintf(spacing);
fprintf('Bias Variance: %2.4f\n', kern.variance)
