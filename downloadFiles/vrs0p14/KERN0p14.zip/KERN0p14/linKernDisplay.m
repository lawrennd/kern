function linKernDisplay(kern)

% LINKERNDISPLAY Display parameters of linear kernel.
%
% linKernDisplay(kern)
%

% Copyright (c) 2005 Neil D. Lawrence
% linKernDisplay.m version 1.2





fprintf('Linear kernel Variance: %2.4f\n', kern.variance)
