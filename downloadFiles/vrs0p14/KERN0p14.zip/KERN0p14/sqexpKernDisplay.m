function sqexpKernDisplay(kern)

% SQEXPKERNDISPLAY Display parameters of squared exponential kernel.
%
% sqexpKernDisplay(kern)
%

% Copyright (c) 2005 Neil D. Lawrence
% sqexpKernDisplay.m version 1.2





fprintf('RBF Variance: %2.4f\n', kern.rbfVariance)
fprintf('RBF inverse width: %2.4f\n', kern.inverseWidth)
fprintf('White noise Variance: %2.4f\n', kern.whiteVariance)
fprintf('Bias Kernel Variance: %2.4f\n', kern.biasVariance)
