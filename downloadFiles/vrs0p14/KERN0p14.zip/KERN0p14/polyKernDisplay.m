function polyKernDisplay(kern)

% POLYKERNDISPLAY Display parameters of polynomial kernel.
%
% polyKernDisplay(kern)
%

% Copyright (c) 2005 Neil D. Lawrence
% polyKernDisplay.m version 1.1



fprintf('Polynomial kernel Variance: %2.4f\n', kern.variance)
fprintf('Polynomial weight variance: %2.4f\n', kern.weightVariance)
fprintf('Polynomial bias variance: %2.4f\n', kern.biasVariance)