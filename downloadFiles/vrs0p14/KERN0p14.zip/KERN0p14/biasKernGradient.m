function g = biasKernGradient(kern, x, varargin)

% BIASKERNGRADIENT Gradient of bias kernel's parameters.
%
% g = biasKernGradient(kern, x, varargin)
%

% Copyright (c) 2005 Neil D. Lawrence
% biasKernGradient.m version 1.4



g = sum(sum(varargin{end}));
