function whiteKernDisplay(kern)

% WHITEKERNDISPLAY Display parameters of white noise kernel.
%
% whiteKernDisplay(kern)
%

% Copyright (c) 2005 Neil D. Lawrence
% whiteKernDisplay.m version 1.3



fprintf('White Noise Variance: %2.4f\n', kern.variance)
