function rbfKernDisplay(kern)

% RBFKERNDISPLAY Display parameters of radial basis function kernel.
%
% rbfKernDisplay(kern)
%

% Copyright (c) 2005 Neil D. Lawrence
% rbfKernDisplay.m version 1.3




fprintf('RBF Variance: %2.4f\n', kern.variance)
fprintf('RBF inverse width: %2.4f\n', kern.inverseWidth)
