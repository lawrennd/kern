function g = kernGradient(kern, x, varargin)

% KERNGRADIENT Compute the gradient of the kernel's parameters.
%
% g = kernGradient(kern, x, varargin)
%

% Copyright (c) 2005 Neil D. Lawrence
% kernGradient.m version 1.5



fhandle = str2func([kern.type 'KernGradient']);
g = fhandle(kern, x, varargin{:});

% Check if parameters are being optimised in a transformed space.
factors = kernFactors(kern, 'gradfact');
g(factors.index) = g(factors.index).*factors.val;

  
