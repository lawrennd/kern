function gX = ardKernDiagGradX(kern, X)

% ARDKERNDIAGGRADX Gradient of ARD kernel's diagonal with respect to X.
%
% gX = ardKernDiagGradX(kern, X)
%

% Copyright (c) 2005 Neil D. Lawrence
% ardKernDiagGradX.m version 1.3



gX = 2*kern.linearVariance*X.*repmat(kern.inputScales, [size(X, 1) 1]);

