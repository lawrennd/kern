function k = whiteKernDiagCompute(kern, x)

% WHITEKERNDIAGCOMPUTE Compute diagonal of white noise kernel.
%
% k = whiteKernDiagCompute(kern, x)
%

% Copyright (c) 2005 Neil D. Lawrence
% whiteKernDiagCompute.m version 1.3




k = repmat(kern.variance, size(x, 1), 1);