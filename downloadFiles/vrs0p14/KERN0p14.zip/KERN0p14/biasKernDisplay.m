function biasKernDisplay(kern)

% BIASKERNDISPLAY Display parameters of bias kernel.
%
% biasKernDisplay(kern)
%

% Copyright (c) 2005 Neil D. Lawrence
% biasKernDisplay.m version 1.2





fprintf('Bias Variance: %2.4f\n', kern.variance)
