function G = kernGradientK(kern, x)

% KERNGRADIENTK Compute the gradient of the kernel wrt its parameters.
%
% G = kernGradientK(kern, x)
%

% Copyright (c) 2005 Neil D. Lawrence
% kernGradientK.m version 



fhandle = str2func([kern.type 'KernGradientK']);
G = fhandle(kern, x);
