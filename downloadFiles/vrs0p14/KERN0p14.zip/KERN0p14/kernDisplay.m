function kernDisplay(kern)

% KERNDISPLAY Display the parameters of the kernel.
%
% kernDisplay(kern)
%

% Copyright (c) 2005 Neil D. Lawrence
% kernDisplay.m version 1.4



fhandle = str2func([kern.type 'KernDisplay']);
fhandle(kern);