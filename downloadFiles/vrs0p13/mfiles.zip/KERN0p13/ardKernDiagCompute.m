function k = ardKernDiagCompute(kern, x)

% ARDKERNDIAGCOMPUTE Compute diagonal of ard kernel.
%
% k = ardKernDiagCompute(kern, x)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 14:29:05 2004
% KERN toolbox version 0.13





scales = sparse(diag(sqrt(kern.inputScales)));
x = x*scales;

rbfPart = ones(size(x, 1), 1);
linearPart = sum(x.*x, 2)*kern.linearVariance;
k = rbfPart*(kern.rbfVariance + kern.whiteVariance) + kern.biasVariance +linearPart;
