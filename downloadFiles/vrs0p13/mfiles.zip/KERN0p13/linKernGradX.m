function gX = linKernGradX(kern, x, X2)

% LINKERNGRADX Gradient of linear kernel with respect to a point X.
%
% gX = linKernGradX(kern, x, X2)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 14:29:05 2004
% KERN toolbox version 0.13





gX = kern.variance.*X2;