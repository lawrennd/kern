function kern = mlpKernParamInit(kern)

% MLPKERNPARAMINIT multi-layer perceptron kernel parameter initialisation.
%
% kern = mlpKernParamInit(kern)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.3, Thu Jun 17 09:27:40 2004
% KERN toolbox version 0.13



kern.weightVariance = 10;
kern.biasVariance = 10;
kern.variance = 1;
kern.nParams = 3;

kern.transforms.index = [1 2 3];
kern.transforms.type = 'negLogLogit';
