function kern = kernParamInit(kern)

% KERNPARAMINIT Kernel parameter initialisation.
%
% kern = kernParamInit(kern)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.3, Mon Jun 21 13:35:44 2004
% KERN toolbox version 0.13



kern = feval([kern.type 'KernParamInit'], kern);
