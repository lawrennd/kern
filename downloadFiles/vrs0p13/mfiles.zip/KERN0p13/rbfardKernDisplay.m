function rbfardKernDisplay(kern)

% RBFARDKERNDISPLAY Display parameters of radial basis function ARD kernel.
%
% rbfardKernDisplay(kern)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 14:29:05 2004
% KERN toolbox version 0.13





fprintf('RBF ARD Variance: %2.4f\n', kern.variance)
fprintf('RBF ARD inverse width: %2.4f\n', kern.inverseWidth)
for i = 1:kern.inputDimension
  fprintf('RBF ARD Input %d scale: %2.4f\n', i, kern.inputScales(i))
end
