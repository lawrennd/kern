function linardKernDisplay(kern)

% LINARDKERNDISPLAY Display parameters of linear ARD kernel.
%
% linardKernDisplay(kern)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 14:29:05 2004
% KERN toolbox version 0.13





fprintf('Linear ARD kernel Variance: %2.4f\n', kern.variance)
for i = 1:kern.inputDimension
  fprintf('Linear ARD Input %d scale: %2.4f\n', i, kern.inputScales(i))
end
