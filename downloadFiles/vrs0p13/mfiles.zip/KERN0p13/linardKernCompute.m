function k = linardKernCompute(kern, x, x2)

% LINARDKERNCOMPUTE Compute the linear ARD kernel given the parameters and X.
%
% k = linardKernCompute(kern, x, x2)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.3, Thu Jun 17 10:38:41 2004
% KERN toolbox version 0.13



scales = sparse(diag(sqrt(kern.inputScales)));
x = x*scales;
    
if nargin < 3
  k = x*x'*kern.variance;
else
  x2 = x2*scales;
  k = x*x2'*kern.variance;
end
