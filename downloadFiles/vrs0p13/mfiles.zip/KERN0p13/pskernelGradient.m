function g = pskernelGradient(lntheta, models, prior)

% PSKERNELGRADIENT Gradient on likelihood approximation for point set IVM.
%
% g = pskernelGradient(lntheta, models, prior)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 14:29:05 2004
% KERN toolbox version 0.13




% PSIVM

if nargin < 3
  prior = 1;
end

g = zeros(size(lntheta));
numTasks = length(models.task);
for taskNo = 1:numTasks
  models.task(taskNo).lntheta = models.lntheta;
  g = g + kernelGradient(lntheta, models.task(taskNo), prior);
end
  
