function g = linardKernGradient(kern, x, covGrad)

% LINARDKERNGRADIENT Gradient of linear ARD kernel's parameters.
%
% g = linardKernGradient(kern, x, covGrad)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 14:29:05 2004
% KERN toolbox version 0.13




g = zeros(1, size(x, 2)+1);
k = linardKernCompute(kern, x);
g(1) = sum(sum(covGrad.*k))/kern.variance;
for i = 1:size(x, 2)
  g(1+i) =  x(:, i)'*covGrad*x(:, i)*kern.variance;
end