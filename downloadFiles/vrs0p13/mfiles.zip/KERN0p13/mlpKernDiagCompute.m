function k = mlpKernDiagCompute(kern, x)

% MLPKERNDIAGCOMPUTE Compute diagonal of multi-layer perceptron kernel.
%
% k = mlpKernDiagCompute(kern, x)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.3, Wed Jun 16 11:07:15 2004
% KERN toolbox version 0.13




numer = sum(x.*x, 2)*kern.weightVariance + kern.biasVariance;
denom = numer+1;
k = kern.variance*asin(numer./denom);
