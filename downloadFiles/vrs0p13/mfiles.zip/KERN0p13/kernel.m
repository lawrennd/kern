function kern = kernel(X, kernelType)

% KERNEL Initialise a kernel structure.
%
% kern = kernel(X, kernelType)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.3, Fri Jun 25 11:32:39 2004
% KERN toolbox version 0.13



kern.Kstore = [];
kern.diagK = [];
if iscell(kernelType)
  % compound kernel type
  kern.type = 'cmpnd';
  for i = 1:length(kernelType)
    kern.comp{i}.type = kernelType{i};
    kern.comp{i}.inputDimension = size(X, 2);
  end
else
  kern.type = kernelType;
  kern.inputDimension = size(X, 2);
end
kern = kernParamInit(kern);
