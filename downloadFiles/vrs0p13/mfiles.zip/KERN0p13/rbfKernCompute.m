function [k, n2] = rbfKernCompute(kern, x, x2)

% RBFKERNCOMPUTE Compute the kernel given the parameters and X.
%
% [k, n2] = rbfKernCompute(kern, x, x2)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.3, Thu Jun 17 10:38:59 2004
% KERN toolbox version 0.13



if nargin < 3
  n2 = dist2(x, x);
  wi2 = (.5 .* kern.inverseWidth);
  k = kern.variance*exp(-n2*wi2);
else
  n2 = dist2(x, x2);
  wi2 = (.5 .* kern.inverseWidth);
  k = kern.variance*exp(-n2*wi2);
end
