function kern = cmpndKernExpandParam(kern, params)

% CMPNDKERNEXPANDPARAM Create kernel structure from ARD parameters.
%
% kern = cmpndKernExpandParam(kern, params)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.3, Thu Jun 24 08:56:52 2004
% KERN toolbox version 0.13



params = params*kern.paramGroups';
startVal = 1;
endVal = 0;
kern.whiteVariance = 0;
for i = 1:length(kern.comp)
  endVal = endVal + kern.comp{i}.nParams;
  kern.comp{i} = kernExpandParam(kern.comp{i}, params(1, startVal:endVal));
  startVal = endVal + 1;
  if strcmp(kern.comp{i}.type, 'white')
    kern.whiteVariance = kern.whiteVariance + kern.comp{i}.variance;
  else
    if(isfield(kern.comp{i}, 'whiteVariance'))
      kern.whiteVariance = kern.whiteVariance + ...
          kern.comp{i}.whiteVariance;
    end
  end
end
