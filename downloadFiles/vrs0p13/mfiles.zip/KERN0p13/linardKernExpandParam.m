function kern = linardKernExpandParam(kern, params)

% LINARDKERNEXPANDPARAM Create kernel structure from linear ARD's parameters.
%
% kern = linardKernExpandParam(kern, params)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 14:29:05 2004
% KERN toolbox version 0.13





kern.variance = params(1);
kern.inputScales = params(2:end);
