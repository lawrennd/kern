function k = sqexpKernDiagCompute(kern, x)

% SQEXPKERNDIAGCOMPUTE Compute diagonal of squared exponential kernel.
%
% k = sqexpKernDiagCompute(kern, x)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.3, Mon Jun 14 13:20:51 2004
% KERN toolbox version 0.13



k = repmat(kern.rbfVariance+kern.whiteVariance, size(x, 1), 1)  + kern.biasVariance;
