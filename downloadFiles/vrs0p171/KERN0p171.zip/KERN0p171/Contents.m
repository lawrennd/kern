% KERN toolbox
% Version 0.171		18-Feb-2008
% Copyright (c) 2008, Neil D. Lawrence
% 
, Neil D. Lawrence
% KERNSETINDEX Set the indices on a compound kernel.
% ARDKERNEXPANDPARAM Create kernel structure from ARD kernel's parameters.
% WHITEFIXEDKERNPARAMINIT WHITEFIXED kernel parameter initialisation.
% KERNPCA performs KPCA.
% LINKERNGRADIENT Gradient of LIN kernel's parameters.
% RATQUADKERNPARAMINIT RATQUAD kernel parameter initialisation.
% RBFPERIODICKERNEXPANDPARAM Create kernel structure from RBFPERIODIC kernel's parameters.
% KERNEXTRACTPARAM Extract parameters from kernel structure.
% GIBBSKERNSETLENGTHSCALEFUNC Set the length scale function of the GIBBS kernel.
% TENSORKERNGRADX Gradient of TENSOR kernel with respect to a point x.
% POLYARDKERNGRADX Gradient of POLYARD kernel with respect to input locations.
% RBFPERIODICKERNGRADIENT Gradient of RBFPERIODIC kernel's parameters.
% RATQUADKERNEXTRACTPARAM Extract parameters from the RATQUAD kernel structure.
% GIBBSKERNCOMPUTE Compute the GIBBS kernel given the parameters and X.
% FILEKERNREAD Read kernel values from file or cache.
% BIASKERNDIAGGRADIENT Compute the gradient of the BIAS kernel's diagonal wrt parameters.
% DISIMXDISIMKERNCOMPUTE Compute a cross kernel between two DISIM kernels.
% MATERN52KERNDIAGCOMPUTE Compute diagonal of MATERN52 kernel.
% POLYKERNEXPANDPARAM Create kernel structure from POLY kernel's parameters.
% GIBBSPERIODICKERNDISPLAY Display parameters of the GIBBSPERIODIC kernel.
% MULTIKERNGRADIENT Gradient of MULTI kernel's parameters.
% MLPARDKERNEXTRACTPARAM Extract parameters from the MLPARD kernel structure.
% MLPKERNEXPANDPARAM Create kernel structure from MLP kernel's parameters.
% RBFKERNDIAGGRADIENT Compute the gradient of the RBF kernel's diagonal wrt parameters.
% ARDKERNDIAGGRADIENT Compute the gradient of the ARD kernel's diagonal wrt parameters.
% TENSORKERNDIAGGRADIENT Compute the gradient of the TENSOR kernel's diagonal wrt parameters.
% RBFARDKERNGRADX Gradient of RBFARD kernel with respect to input locations.
% SIMKERNDIAGGRADX Gradient of SIM kernel's diagonal with respect to X.
% GIBBSPERIODICKERNCOMPUTE Compute the GIBBSPERIODIC kernel given the parameters and X.
% POLYARDKERNPARAMINIT POLYARD kernel parameter initialisation.
% TRANSLATEKERNGRADIENT Gradient of TRANSLATE kernel's parameters.
% RBFPERIODICKERNGRADX Gradient of RBFPERIODIC kernel with respect to a point x.
% BIASKERNDISPLAY Display parameters of the BIASkernel.
% ARDKERNEXTRACTPARAM Extract parameters from the ARD kernel structure.
% KERNCOMPUTE Compute the kernel given the parameters and X.
% WHITEKERNDIAGCOMPUTE Compute diagonal of WHITE kernel.
% RBFKERNEXTRACTPARAM Extract parameters from the RBF kernel structure.
% SQEXPKERNEXPANDPARAM Create kernel structure from SQEXP kernel's parameters.
% GIBBSPERIODICKERNEXTRACTPARAM Extract parameters from the GIBBSPERIODIC kernel structure.
% DISIMXRBFKERNCOMPUTE Compute a cross kernel between the DISIM and RBF kernels.
% DISIMKERNDIAGGRADIENT Compute the gradient of the DISIM kernel's diagonal wrt parameters.
% KERNCREATE Initialise a kernel structure.
% WHITEFIXEDKERNDIAGCOMPUTE Compute diagonal of WHITEFIXED kernel.
% WHITEKERNDIAGGRADX Gradient of WHITE kernel's diagonal with respect to X.
% GIBBSKERNEXTRACTPARAM Extract parameters from the GIBBS kernel structure.
% FILEKERNGRADIENT Gradient of FILE kernel's parameters.
% EXPKERNPARAMINIT EXP kernel parameter initialisation.
% EXPKERNGRADIENT Gradient of EXP kernel's parameters.
% MATERN32KERNDIAGCOMPUTE Compute diagonal of MATERN32 kernel.
% CMPNDKERNDIAGCOMPUTE Compute diagonal of CMPND kernel.
% BIASKERNPARAMINIT BIAS kernel parameter initialisation.
% GIBBSPERIODICKERNDIAGCOMPUTE Compute diagonal of GIBBSPERIODIC kernel.
% CMPNDKERNEXTRACTPARAM Extract parameters from the CMPND kernel structure.
% SIMXRBFKERNCOMPUTE Compute a cross kernel between the SIM and RBF kernels.
% LINARDKERNDISPLAY Display parameters of the LINARD kernel.
% MULTIKERNDIAGGRADX Gradient of MULTI kernel's diagonal with respect to X.
% POLYKERNDIAGGRADX Gradient of POLY kernel's diagonal with respect to X.
% LINARDKERNPARAMINIT LINARD kernel parameter initialisation.
% KERNGETVARIANCE Get the signal associated with a the kernel.
% MULTIKERNTEST Run some tests on the multiple output block kernel.
% RBFARDKERNDISPLAY Display parameters of the RBFARD kernel.
% POLYKERNCOMPUTE Compute the POLY kernel given the parameters and X.
% SIMKERNPARAMINIT SIM kernel parameter initialisation.
% LINKERNDIAGCOMPUTE Compute diagonal of LIN kernel.
% PSKERNELGRADIENT Gradient on likelihood approximation for point set IVM.
% MULTIKERNDIAGCOMPUTE Compute diagonal of MULTI kernel.
% WHITEXWHITEKERNGRADIENT Compute a cross gradient between two WHITE kernels.
% KERNPRIORGRADIENT Compute gradient terms associated with kernel priors.
% SIMCOMPUTETEST Test the file simComputeH.
% DISIMKERNEXTRACTPARAM Extract parameters from the DISIM kernel structure.
% DISIMKERNGRADX Gradient of DISIM kernel with respect to a point x.
% LINKERNDIAGGRADX Gradient of LIN kernel's diagonal with respect to X.
% DISIMCOMPUTEH Helper function for comptuing part of the DISIM kernel.
% BIASKERNDIAGGRADX Gradient of BIAS kernel's diagonal with respect to X.
% KERNGRADIENT Compute the gradient wrt the kernel's parameters.
% CMPNDKERNSETINDEX Set the indices in the compound kernel.
% KERNTEST Run some tests on the specified kernel.
% SIMKERNDIAGGRADIENT Compute the gradient of the SIM kernel's diagonal wrt parameters.
% MLPKERNCOMPUTE Compute the MLP kernel given the parameters and X.
% SIMKERNEXTRACTPARAM Extract parameters from the SIM kernel structure.
% SQEXPKERNCOMPUTE Compute the SQEXP kernel given the parameters and X.
% MLPARDKERNPARAMINIT MLPARD kernel parameter initialisation.
% RATQUADKERNDISPLAY Display parameters of the RATQUAD kernel.
% LINKERNGRADX Gradient of LIN kernel with respect to input locations.
% GIBBSKERNDIAGGRADX Gradient of GIBBS kernel's diagonal with respect to X.
% MLPARDKERNEXPANDPARAM Create kernel structure from MLPARD kernel's parameters.
% DISIMXSIMKERNGRADIENT Compute gradient between the DISIM and SIM kernels.
% POLYKERNGRADX Gradient of POLY kernel with respect to input locations.
% SIMXSIMKERNCOMPUTE Compute a cross kernel between two SIM kernels.
% SQEXPKERNEXTRACTPARAM Extract parameters from the SQEXP kernel structure.
% MLPARDKERNCOMPUTE Compute the MLPARD kernel given the parameters and X.
% MLPKERNGRADX Gradient of MLP kernel with respect to input locations.
% CMPNDKERNDISPLAY Display parameters of the CMPND kernel.
% LINARDKERNCOMPUTE Compute the LINARD kernel given the parameters and X.
% EXPKERNDIAGGRADX Gradient of EXP kernel's diagonal with respect to X.
% POLYKERNDIAGCOMPUTE Compute diagonal of POLY kernel.
% WHITEFIXEDKERNEXTRACTPARAM Extract parameters from the WHITEFIXED kernel structure.
% MATERN32KERNGRADIENT Gradient of MATERN32 kernel's parameters.
% DISIMKERNEXPANDPARAM Create kernel structure from DISIM kernel's parameters.
% WHITEFIXEDKERNEXPANDPARAM Create kernel structure from WHITEFIXED kernel's parameters.
% KERNGRADX Compute the gradient of the kernel wrt X.
% MATERN52KERNGRADIENT Gradient of MATERN52 kernel's parameters.
% CMPNDKERNEXPANDPARAM Create kernel structure from CMPND kernel's parameters.
% MLPKERNDIAGCOMPUTE Compute diagonal of MLP kernel.
% MULTIKERNGRADIENTBLOCK
% TENSORKERNDIAGGRADX Gradient of TENSOR kernel's diagonal with respect to X.
% DISIMCOMPUTEHPRIME Helper function for comptuing part of the DISIM kernel.
% RBFPERIODICKERNDIAGCOMPUTE Compute diagonal of RBFPERIODIC kernel.
% WHITEFIXEDKERNGRADX Gradient of WHITEFIXED kernel with respect to a point x.
% RATQUADKERNCOMPUTE Compute the RATQUAD kernel given the parameters and X.
% LINKERNDISPLAY Display parameters of the LIN kernel.
% FILEKERNEXPANDPARAM Create kernel structure from FILE kernel's parameters.
% RBFARDKERNDIAGGRADIENT Compute the gradient of the RBFARD kernel's diagonal wrt parameters.
% LINARDKERNEXPANDPARAM Create kernel structure from LINARD kernel's parameters.
% KERNPRIORLOGPROB Compute penalty terms associated with kernel priors.
% LINARDKERNGRADX Gradient of LINARD kernel with respect to input locations.
% EXPKERNDISPLAY Display parameters of the EXP kernel.
% GIBBSKERNDISPLAY Display parameters of the GIBBS kernel.
% POLYKERNEXTRACTPARAM Extract parameters from the POLY kernel structure.
% RBFKERNDIAGGRADX Gradient of RBF kernel's diagonal with respect to X.
% LINARDKERNDIAGCOMPUTE Compute diagonal of LINARD kernel.
% SQEXPKERNDISPLAY Display parameters of the SQEXP kernel.
% POLYARDKERNEXPANDPARAM Create kernel structure from POLYARD kernel's parameters.
% KERNREADFROMFID Load from an FID written by the C++ implementation.
% RBFKERNDIAGCOMPUTE Compute diagonal of RBF kernel.
% COMPONENTKERNREADPARAMSFROMFID Read a component based kernel from a C++ file.
% TRANSLATEKERNPARAMINIT TRANSLATE kernel parameter initialisation.
% RBFARDKERNCOMPUTE Compute the RBFARD kernel given the parameters and X.
% MULTIKERNDISPLAY Display parameters of the MULTI kernel.
% TRANSLATEKERNCOMPUTE Compute the TRANSLATE kernel given the parameters and X.
% RBFARDKERNEXTRACTPARAM Extract parameters from the RBFARD kernel structure.
% WHITEFIXEDKERNCOMPUTE Compute the WHITEFIXED kernel given the parameters and X.
% GIBBSPERIODICKERNEXPANDPARAM Create kernel structure from GIBBSPERIODIC kernel's parameters.
% DISIMKERNDIAGCOMPUTE Compute diagonal of DISIM kernel.
% LINARDKERNGRADIENT Gradient of LINARD kernel's parameters.
% GIBBSPERIODICKERNPARAMINIT GIBBSPERIODIC kernel parameter initialisation.
% MLPKERNPARAMINIT MLP kernel parameter initialisation.
% CMPNDKERNPARAMINIT CMPND kernel parameter initialisation.
% EXPKERNEXTRACTPARAM Extract parameters from the EXP kernel structure.
% CMPNDKERNDIAGGRADX Gradient of CMPND kernel's diagonal with respect to X.
% WHITEKERNEXTRACTPARAM Extract parameters from the WHITE kernel structure.
% SIMKERNGRADIENT Gradient of SIM kernel's parameters.
% RATQUADKERNDIAGGRADX Gradient of RATQUAD kernel's diagonal with respect to X.
% WHITEKERNDIAGGRADIENT Compute the gradient of the WHITE kernel's diagonal wrt parameters.
% EXPKERNEXPANDPARAM Create kernel structure from EXP kernel's parameters.
% RBFPERIODICKERNDIAGGRADIENT Compute the gradient of the RBFPERIODIC kernel's diagonal wrt parameters.
% DISIMXSIMKERNCOMPUTE Compute a cross kernel between DISIM and SIM kernels.
% RBFARDKERNDIAGGRADX Gradient of RBFARD kernel's diagonal with respect to X.
% SQEXPKERNGRADIENT Gradient of SQEXP kernel's parameters.
% KERNTOOLBOXES Load in the relevant toolboxes for kern.
% EXPKERNCOMPUTE Compute the EXP kernel given the parameters and X.
% POLYARDKERNDIAGCOMPUTE Compute diagonal of POLYARD kernel.
% EXPKERNGRADX Gradient of EXP kernel with respect to a point x.
% LINKERNEXPANDPARAM Create kernel structure from LIN kernel's parameters.
% DISIMKERNDIAGGRADX Gradient of DISIM kernel's diagonal with respect to X.
% RATQUADKERNDIAGCOMPUTE Compute diagonal of RATQUAD kernel.
% MLPARDKERNDISPLAY Display parameters of the MLPARD kernel.
% KERNCORRELATION Compute the correlation matrix kernel given the parameters and X.
% GIBBSPERIODICKERNDIAGGRADIENT Compute the gradient of the GIBBSPERIODIC kernel's diagonal wrt parameters.
% POLYARDKERNDISPLAY Display parameters of the POLYARD kernel.
% LINKERNCOMPUTE Compute the LIN kernel given the parameters and X.
% RBFPERIODICKERNPARAMINIT RBFPERIODIC kernel parameter initialisation.
% GIBBSKERNDIAGGRADIENT Compute the gradient of the GIBBS kernel's diagonal wrt parameters.
% TRANSLATEKERNDIAGCOMPUTE Compute diagonal of TRANSLATE kernel.
% BIASKERNCOMPUTE Compute the BIAS kernel given the parameters and X.
% MULTIKERNDIAGGRADIENT Compute the gradient of the MULTI kernel's diagonal wrt parameters.
% MULTIKERNCOMPUTE Compute the MULTI kernel given the parameters and X.
% RBFKERNCOMPUTE Compute the RBF kernel given the parameters and X.
% MATERN32KERNPARAMINIT MATERN32 kernel parameter initialisation.
% ARDKERNPARAMINIT ARD kernel parameter initialisation.
% MATERN32KERNDISPLAY Display parameters of the MATERN32 kernel.
% RBFKERNPARAMINIT RBF kernel parameter initialisation.
% MATERN52KERNPARAMINIT MATERN52 kernel parameter initialisation.
% POLYARDKERNGRADIENT Gradient of POLYARD kernel's parameters.
% KERNDISPLAY Display the parameters of the kernel.
% FILEKERNPARAMINIT FILE kernel parameter initialisation.
% DISIMKERNCOMPUTE Compute the DISIM kernel given the parameters and X.
% TENSORKERNSLASH Tensor kernel created by removing ith component.
% KERNDIAGCOMPUTE Compute the kernel given the parameters and X.
% CMPNDKERNGRADIENT Gradient of CMPND kernel's parameters.
% RATQUADKERNEXPANDPARAM Create kernel structure from RATQUAD kernel's parameters.
% MATERN32KERNDIAGGRADIENT Compute the gradient of the MATERN32 kernel's diagonal wrt parameters.
% TRANSLATEKERNEXPANDPARAM Create kernel structure from TRANSLATE kernel's parameters.
% TENSORKERNSETINDEX Set the indices in the tensor kernel.
% MATERN32KERNGRADX Gradient of MATERN32 kernel with respect to input locations.
% SQEXPKERNDIAGCOMPUTE Compute diagonal of SQEXP kernel.
% KERNDIAGGRADX Compute the gradient of the  kernel wrt X.
% GIBBSPERIODICKERNDIAGGRADX Gradient of GIBBSPERIODIC kernel's diagonal with respect to X.
% MATERN52KERNEXPANDPARAM Create kernel structure from MATERN52 kernel's parameters.
% BIASKERNEXTRACTPARAM Extract parameters from the BIAS kernel structure.
% RBFARDKERNGRADIENT Gradient of RBFARD kernel's parameters.
% MATERN52KERNDIAGGRADX Gradient of MATERN52 kernel's diagonal with respect to X.
% ARDKERNDISPLAY Display parameters of the ARD kernel.
% MATERN32KERNDIAGGRADX Gradient of MATERN32 kernel's diagonal with respect to X.
% MLPARDKERNDIAGCOMPUTE Compute diagonal of MLPARD kernel.
% RBFPERIODICKERNDISPLAY Display parameters of the RBFPERIODIC kernel.
% POLYARDKERNEXTRACTPARAM Extract parameters from the POLYARD kernel structure.
% TRANSLATEKERNDISPLAY Display parameters of the TRANSLATE kernel.
% SQEXPKERNGRADX Gradient of SQEXP kernel with respect to a point x.
% WHITEKERNDISPLAY Display parameters of the WHITEkernel.
% KERNEXPANDPARAM Expand parameters to form a kernel structure.
% GIBBSPERIODICKERNGRADX Gradient of GIBBSPERIODIC kernel with respect to a point x.
% KERNREADPARAMSFROMFID Read the kernel parameters from C++ file FID.
% ARDKERNGRADIENT Gradient of ARD kernel's parameters.
% TENSORKERNGRADIENT Gradient of TENSOR kernel's parameters.
% RBFKERNDISPLAY Display parameters of the RBF kernel.
% MATERN52KERNDISPLAY Display parameters of the MATERN52 kernel.
% SIMCOMPUTEH Helper function for comptuing part of the SIM kernel.
% ARDKERNDIAGGRADX Gradient of ARD kernel's diagonal with respect to X.
% MATERN52KERNCOMPUTE Compute the MATERN52 kernel given the parameters and X.
% ARDKERNDIAGCOMPUTE Compute diagonal of ARD kernel.
% GIBBSKERNPARAMINIT GIBBS kernel parameter initialisation.
% RBFARDKERNPARAMINIT RBFARD kernel parameter initialisation.
% SQEXPKERNDIAGGRADIENT Compute the gradient of the SQEXP kernel's diagonal wrt parameters.
% MATERN32KERNEXTRACTPARAM Extract parameters from the MATERN32 kernel structure.
% BIASKERNDIAGCOMPUTE Compute diagonal of BIAS kernel.
% RBFPERIODICKERNDIAGGRADX Gradient of RBFPERIODIC kernel's diagonal with respect to X.
% MLPKERNEXTRACTPARAM Extract parameters from the MLP kernel structure.
% SIMKERNCOMPUTE Compute the SIM kernel given the parameters and X.
% MATERN32KERNCOMPUTE Compute the MATERN32 kernel given the parameters and X.
% MULTIKERNEXTRACTPARAM Extract parameters from the MULTI kernel structure.
% RBFPERIODICKERNCOMPUTE Compute the RBFPERIODIC kernel given the parameters and X.
% DISIMXRBFKERNGRADIENT Compute gradient between the DISIM and RBF kernels.
% GIBBSKERNEXPANDPARAM Create kernel structure from GIBBS kernel's parameters.
% KERNDIAGGRADIENT Compute the gradient of the kernel's parameters for the diagonal.
% TENSORKERNPARAMINIT TENSOR kernel parameter initialisation.
% POLYARDKERNDIAGGRADX Gradient of POLYARD kernel's diagonal with respect to X.
% RATQUADKERNGRADIENT Gradient of RATQUAD kernel's parameters.
% DISIMKERNDISPLAY Display parameters of the DISIM kernel.
% SIMKERNDISPLAY Display parameters of the SIM kernel.
% MLPARDKERNDIAGGRADX Gradient of MLPARD kernel's diagonal with respect to X.
% WHITEFIXEDKERNDIAGGRADX Gradient of WHITEFIXED kernel's diagonal with respect to X.
% RATQUADKERNGRADX Gradient of RATQUAD kernel with respect to input locations.
% GIBBSKERNGRADX Gradient of GIBBS kernel with respect to input locations.
% WHITEKERNEXPANDPARAM Create kernel structure from WHITE kernel's parameters.
% BIASKERNGRADX Gradient of BIAS kernel with respect to input locations.
% MLPKERNGRADIENT Gradient of MLP kernel's parameters.
% TENSORKERNREADPARAMSFROMFID Read a tensor kernel from a C++ file.
% FILEKERNGRADX Gradient of FILE kernel with respect to a point x.
% SQEXPKERNDIAGGRADX Gradient of SQEXP kernel's diagonal with respect to X.
% CMPNDKERNREADPARAMSFROMFID Read a compound kernel from a C++ file.
% EXPKERNDIAGCOMPUTE Compute diagonal of EXP kernel.
% LINKERNEXTRACTPARAM Extract parameters from the LIN kernel structure.
% MULTIKERNPARAMINIT MULTI kernel parameter initialisation.
% TENSORKERNEXTRACTPARAM Extract parameters from the TENSOR kernel structure.
% LINARDKERNEXTRACTPARAM Extract parameters from the LINARD kernel structure.
% BIASKERNEXPANDPARAM Create kernel structure from BIAS kernel's parameters.
% FILEKERNDIAGCOMPUTE Compute diagonal of FILE kernel.
% GIBBSKERNGRADIENT Gradient of GIBBS kernel's parameters.
% TENSORKERNDISPLAY Display parameters of the TENSOR kernel.
% WHITEXWHITEKERNCOMPUTE Compute a cross kernel between two WHITE kernels.
% WHITEFIXEDKERNGRADIENT Gradient of WHITEFIXED kernel's parameters.
% CMPNDKERNDIAGGRADIENT Compute the gradient of the CMPND kernel's diagonal wrt parameters.
% MULTIKERNEXPANDPARAM Create kernel structure from MULTI kernel's parameters.
% RBFARDKERNDIAGCOMPUTE Compute diagonal of RBFARD kernel.
% FILEKERNDISPLAY Display parameters of the FILE kernel.
% SIMKERNEXPANDPARAM Create kernel structure from SIM kernel's parameters.
% MULTIKERNGRADX Gradient of MULTI kernel with respect to a point x.
% ARDKERNCOMPUTE Compute the ARD kernel given the parameters and X.
% BIASKERNGRADIENT Gradient of BIAS kernel's parameters.
% WHITEKERNCOMPUTE Compute the WHITE kernel given the parameters and X.
% SIMKERNGRADX Gradient of SIM kernel with respect to a point x.
% POLYKERNDISPLAY Display parameters of the POLY kernel.
% COMPUTEKERNEL Compute the kernel given the parameters and X.
% WHITEKERNGRADIENT Gradient of WHITE kernel's parameters.
% SIMKERNDIAGCOMPUTE Compute diagonal of SIM kernel.
% MLPKERNDIAGGRADX Gradient of MLP kernel's diagonal with respect to X.
% GIBBSPERIODICKERNGRADIENT Gradient of GIBBSPERIODIC kernel's parameters.
% SQEXPKERNPARAMINIT SQEXP kernel parameter initialisation.
% WHITEFIXEDKERNDISPLAY Display parameters of the WHITEFIXED kernel.
% WHITEFIXEDKERNDIAGGRADIENT Compute the gradient of the WHITEFIXED kernel's diagonal wrt parameters.
% SIMXRBFKERNGRADIENT Compute gradient between the SIM and RBF kernels.
% DISIMKERNGRADIENT Gradient of DISIM kernel's parameters.
% POLYKERNGRADIENT Gradient of POLY kernel's parameters.
% MATERN52KERNEXTRACTPARAM Extract parameters from the MATERN52 kernel structure.
% MATERN52KERNGRADX Gradient of MATERN52 kernel with respect to input locations.
% TRANSLATEKERNGRADX Gradient of TRANSLATE kernel with respect to a point x.
% TENSORKERNEXPANDPARAM Create kernel structure from TENSOR kernel's parameters.
% POLYKERNPARAMINIT POLY kernel parameter initialisation.
% MULTIKERNCOMPUTEBLOCK
% CMPNDKERNGRADX Gradient of CMPND kernel with respect to a point x.
% WHITEKERNGRADX Gradient of WHITE kernel with respect to input locations.
% TRANSLATEKERNDIAGGRADX Gradient of TRANSLATE kernel's diagonal with respect to X.
% MATERN32KERNEXPANDPARAM Create kernel structure from MATERN32 kernel's parameters.
% FILEKERNEXTRACTPARAM Extract parameters from the FILE kernel structure.
% MATERN52KERNDIAGGRADIENT Compute the gradient of the MATERN52 kernel's diagonal wrt parameters.
% TENSORKERNCOMPUTE Compute the TENSOR kernel given the parameters and X.
% KERNSETWHITE Helper function to set the white noise in a kernel if it exists.
% DISIMKERNPARAMINIT DISIM kernel parameter initialisation.
% DISIMXDISIMKERNGRADIENT Compute a cross gradient between two DISIM kernels.
% LINKERNPARAMINIT LIN kernel parameter initialisation.
% TENSORKERNDIAGCOMPUTE Compute diagonal of TENSOR kernel.
% POLYARDKERNCOMPUTE Compute the POLYARD kernel given the parameters and X.
% TRANSLATEKERNEXTRACTPARAM Extract parameters from the TRANSLATE kernel structure.
% MLPARDKERNGRADIENT Gradient of MLPARD kernel's parameters.
% FILEKERNCOMPUTE Compute the FILE kernel given the parameters and X.
% RBFARDKERNEXPANDPARAM Create kernel structure from RBFARD kernel's parameters.
% WHITEKERNPARAMINIT WHITE kernel parameter initialisation.
% RBFKERNGRADX Gradient of RBF kernel with respect to input locations.
% MLPARDKERNGRADX Gradient of MLPARD kernel with respect to input locations.
% CMPNDKERNCOMPUTE Compute the CMPND kernel given the parameters and X.
% KERNPARAMINIT Kernel parameter initialisation.
% RBFPERIODICKERNEXTRACTPARAM Extract parameters from the RBFPERIODIC kernel structure.
% RATQUADKERNDIAGGRADIENT Compute the gradient of the RATQUAD kernel's diagonal wrt parameters.
% RBFKERNGRADIENT Gradient of RBF kernel's parameters.
% KERNFACTORS Extract factors associated with transformed optimisation space.
% MLPKERNDISPLAY Display parameters of the MLP kernel.
% SIMXSIMKERNGRADIENT Compute a cross gradient between two SIM kernels.
% GIBBSKERNDIAGCOMPUTE Compute diagonal of GIBBS kernel.
% RBFKERNEXPANDPARAM Create kernel structure from RBF kernel's parameters.
% ARDKERNGRADX Gradient of ARD kernel with respect to a point x.
% PSKERNELOBJECTIVE Likelihood approximation for point set IVM.
% LINARDKERNDIAGGRADX Gradient of LINARD kernel's diagonal with respect to X.
