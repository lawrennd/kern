function kern = tensorKernReadParamsFromFID(kern, FID)

% TENSORKERNREADPARAMSFROMFID Read a tensor kernel from a C++ file.
%
%	Description:
%	kern = tensorKernReadParamsFromFID(kern, FID)
%% 	tensorKernReadParamsFromFID.m version 1.1


kern = componentKernReadParamsFromFID(kern, FID);


